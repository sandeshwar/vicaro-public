var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/background/cdp.ts
var cdp_exports = {};
__export(cdp_exports, {
  PRIMARY_MODIFIER: () => PRIMARY_MODIFIER,
  captureScreenshotCdp: () => captureScreenshotCdp,
  captureScreenshotRegion: () => captureScreenshotRegion,
  detach: () => detach,
  detachAll: () => detachAll,
  dragPath: () => dragPath,
  ensureAttached: () => ensureAttached,
  evaluate: () => evaluate,
  hoverAt: () => hoverAt,
  initCdp: () => initCdp,
  insertText: () => insertText,
  isCdpAttached: () => isCdpAttached,
  modifierBits: () => modifierBits,
  mouseClick: () => mouseClick,
  pressEnter: () => pressEnter,
  pressKey: () => pressKey,
  pressKeyCombo: () => pressKeyCombo,
  selectAll: () => selectAll,
  send: () => send,
  sendSession: () => sendSession,
  setFileInputFiles: () => setFileInputFiles,
  wheel: () => wheel
});
function initCdp() {
  if (listenersReady) return;
  try {
    chrome.debugger.onDetach.addListener((source) => {
      if (source.tabId !== void 0) attached.delete(source.tabId);
    });
    chrome.tabs.onRemoved.addListener((tabId) => {
      attached.delete(tabId);
    });
    listenersReady = true;
  } catch {
  }
}
async function isCdpAttached(tabId) {
  if (attached.has(tabId)) return true;
  try {
    const targets = await chrome.debugger.getTargets();
    return targets.some((t) => t.tabId === tabId && t.attached);
  } catch {
    return false;
  }
}
async function ensureAttached(tabId) {
  if (await isCdpAttached(tabId)) {
    attached.add(tabId);
    return true;
  }
  try {
    await chrome.debugger.attach({ tabId }, PROTOCOL);
    attached.add(tabId);
    return true;
  } catch {
    return false;
  }
}
async function detach(tabId) {
  attached.delete(tabId);
  try {
    await chrome.debugger.detach({ tabId });
  } catch {
  }
}
async function detachAll() {
  const ids = new Set(attached);
  try {
    for (const target of await chrome.debugger.getTargets()) {
      if (target.attached && target.tabId !== void 0) ids.add(target.tabId);
    }
  } catch {
  }
  await Promise.all([...ids].map((tabId) => detach(tabId)));
}
async function send(tabId, method, params, timeoutMs = 1e4) {
  try {
    return await sendOnce(tabId, method, params, timeoutMs);
  } catch (err) {
    const msg = String(err?.message ?? err);
    if (!/not attached|no tab with given id|target closed|detached/i.test(msg)) throw err;
    attached.delete(tabId);
    try {
      await chrome.debugger.detach({ tabId });
    } catch {
    }
    try {
      await chrome.debugger.attach({ tabId }, PROTOCOL);
      attached.add(tabId);
    } catch {
      throw err;
    }
    return await sendOnce(tabId, method, params, timeoutMs);
  }
}
async function sendSession(tabId, sessionId, method, params, timeoutMs = 1e4) {
  if (!sessionId) return send(tabId, method, params, timeoutMs);
  const timeout = new Promise((_, reject) => {
    const t = setTimeout(() => reject(new Error(`CDP ${method} timed out after ${timeoutMs}ms`)), timeoutMs);
    t.unref?.();
  });
  const target = { tabId, sessionId };
  return Promise.race([chrome.debugger.sendCommand(target, method, params), timeout]);
}
function sendOnce(tabId, method, params, timeoutMs = 1e4) {
  const timeout = new Promise((_, reject) => {
    const t = setTimeout(() => reject(new Error(`CDP ${method} timed out after ${timeoutMs}ms`)), timeoutMs);
    t.unref?.();
  });
  return Promise.race([
    chrome.debugger.sendCommand({ tabId }, method, params),
    timeout
  ]);
}
function platform() {
  try {
    const uad = navigator.userAgentData;
    if (typeof uad?.platform === "string" && uad.platform) return uad.platform.toUpperCase();
  } catch {
  }
  try {
    return (navigator.platform ?? "").toUpperCase();
  } catch {
    return "";
  }
}
async function mouseClick(tabId, x, y, opts = {}) {
  const button = opts.button ?? "left";
  const clicks = Math.max(1, Math.min(2, opts.clickCount ?? 1));
  const buttons = button === "right" ? 2 : button === "middle" ? 4 : 1;
  await send(tabId, "Input.dispatchMouseEvent", { type: "mouseMoved", x, y, modifiers: 0 });
  for (let i = 1; i <= clicks; i++) {
    await send(tabId, "Input.dispatchMouseEvent", { type: "mousePressed", x, y, button, buttons, clickCount: i, modifiers: 0 });
    await sleep(30);
    await send(tabId, "Input.dispatchMouseEvent", { type: "mouseReleased", x, y, button, buttons: 0, clickCount: i, modifiers: 0 });
    if (i < clicks) await sleep(40);
  }
}
async function wheel(tabId, x, y, deltaY) {
  await send(tabId, "Input.dispatchMouseEvent", { type: "mouseWheel", x, y, deltaX: 0, deltaY, modifiers: 0 });
}
async function insertText(tabId, text) {
  await send(tabId, "Input.insertText", { text });
}
async function pressKey(tabId, key, code, vk) {
  await send(tabId, "Input.dispatchKeyEvent", { type: "keyDown", key, code, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk });
  await sleep(15);
  await send(tabId, "Input.dispatchKeyEvent", { type: "keyUp", key, code, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk });
}
async function pressEnter(tabId) {
  await pressKey(tabId, "Enter", "Enter", 13);
}
async function selectAll(tabId) {
  const mod = PRIMARY_MODIFIER;
  await send(tabId, "Input.dispatchKeyEvent", { type: "keyDown", key: "a", code: "KeyA", windowsVirtualKeyCode: 65, modifiers: mod });
  await send(tabId, "Input.dispatchKeyEvent", { type: "keyUp", key: "a", code: "KeyA", windowsVirtualKeyCode: 65, modifiers: mod });
}
async function captureScreenshotCdp(tabId) {
  try {
    if (!await ensureAttached(tabId)) return null;
    const res = await send(tabId, "Page.captureScreenshot", { format: "jpeg", quality: 82, fromSurface: true, captureBeyondViewport: false });
    return { base64: res.data };
  } catch {
    return null;
  }
}
async function captureScreenshotRegion(tabId, rect) {
  try {
    if (!await ensureAttached(tabId)) return null;
    const metrics = await send(tabId, "Page.getLayoutMetrics").catch(() => null);
    const vw = Math.max(1, Math.round(metrics?.cssLayoutViewport?.clientWidth ?? 0)) || 1280;
    const vh = Math.max(1, Math.round(metrics?.cssLayoutViewport?.clientHeight ?? 0)) || 800;
    let clip = { x: 0, y: 0, width: vw, height: vh, scale: 1 };
    if (rect) {
      const x = Math.max(0, Math.min(vw - 1, Math.round(rect.x)));
      const y = Math.max(0, Math.min(vh - 1, Math.round(rect.y)));
      const width = Math.max(8, Math.min(vw - x, Math.round(rect.w)));
      const height = Math.max(8, Math.min(vh - y, Math.round(rect.h)));
      clip = { x, y, width, height, scale: 1 };
    }
    const res = await send(tabId, "Page.captureScreenshot", {
      format: "jpeg",
      quality: 82,
      fromSurface: true,
      captureBeyondViewport: false,
      clip
    });
    return { base64: res.data, cssWidth: clip.width, cssHeight: clip.height };
  } catch {
    return null;
  }
}
function modifierBits(modifiers = []) {
  let bits = 0;
  for (const m of modifiers) bits |= MOD_BITS[m] ?? 0;
  return bits;
}
async function pressKeyCombo(tabId, rawKey, modifiers = []) {
  const bits = modifierBits(modifiers);
  const lower = rawKey.toLowerCase();
  const named = KEY_TABLE[lower];
  let key, code, vk;
  if (named) {
    ({ key, code, vk } = named);
  } else if (rawKey.length === 1) {
    const upper = rawKey.toUpperCase();
    key = bits & 8 ? upper : rawKey;
    code = /[a-z]/i.test(rawKey) ? `Key${upper}` : /[0-9]/.test(rawKey) ? `Digit${rawKey}` : rawKey;
    vk = upper.charCodeAt(0);
  } else {
    key = rawKey;
    code = rawKey;
    vk = 0;
  }
  const isChord = (bits & (MOD_BITS.ctrl | MOD_BITS.meta)) !== 0;
  await send(tabId, "Input.dispatchKeyEvent", {
    type: isChord ? "rawKeyDown" : "keyDown",
    key,
    code,
    windowsVirtualKeyCode: vk,
    nativeVirtualKeyCode: vk,
    modifiers: bits
  });
  await sleep(20);
  await send(tabId, "Input.dispatchKeyEvent", {
    type: "keyUp",
    key,
    code,
    windowsVirtualKeyCode: vk,
    nativeVirtualKeyCode: vk,
    modifiers: bits
  });
  return { key, bits };
}
async function hoverAt(tabId, x, y) {
  await send(tabId, "Input.dispatchMouseEvent", { type: "mouseMoved", x, y, modifiers: 0 });
}
async function dragPath(tabId, from, to, steps = 8) {
  await send(tabId, "Input.dispatchMouseEvent", { type: "mouseMoved", x: from.x, y: from.y, modifiers: 0 });
  await send(tabId, "Input.dispatchMouseEvent", { type: "mousePressed", x: from.x, y: from.y, button: "left", buttons: 1, clickCount: 1, modifiers: 0 });
  await sleep(60);
  for (let i = 1; i <= steps; i++) {
    const x = Math.round(from.x + (to.x - from.x) * i / steps);
    const y = Math.round(from.y + (to.y - from.y) * i / steps);
    await send(tabId, "Input.dispatchMouseEvent", { type: "mouseMoved", x, y, button: "left", buttons: 1, modifiers: 0 });
    await sleep(25);
  }
  await sleep(60);
  await send(tabId, "Input.dispatchMouseEvent", { type: "mouseReleased", x: to.x, y: to.y, button: "left", buttons: 0, clickCount: 1, modifiers: 0 });
}
async function evaluate(tabId, expression, opts = {}) {
  const res = await send(
    tabId,
    "Runtime.evaluate",
    { expression, returnByValue: true, awaitPromise: opts.awaitPromise !== false, userGesture: !!opts.userGesture }
  );
  if (res.exceptionDetails) {
    throw new Error(res.exceptionDetails.exception?.description ?? res.exceptionDetails.text ?? "evaluate threw");
  }
  return res.result?.value;
}
async function setFileInputFiles(tabId, marker, files) {
  const doc = await send(tabId, "DOM.getDocument", { depth: 0 });
  const found = await send(tabId, "DOM.querySelector", { nodeId: doc.root.nodeId, selector: `[data-cu-mark="${marker}"]` });
  if (!found?.nodeId) throw new Error("file input marker vanished (page re-rendered?)");
  await send(tabId, "DOM.setFileInputFiles", { files, nodeId: found.nodeId });
  return found.nodeId;
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
var PROTOCOL, attached, listenersReady, IS_MAC, PRIMARY_MODIFIER, KEY_TABLE, MOD_BITS;
var init_cdp = __esm({
  "src/background/cdp.ts"() {
    "use strict";
    PROTOCOL = "1.3";
    attached = /* @__PURE__ */ new Set();
    listenersReady = false;
    IS_MAC = /* @__PURE__ */ platform().includes("MAC");
    PRIMARY_MODIFIER = IS_MAC ? 4 : 2;
    KEY_TABLE = {
      enter: { key: "Enter", code: "Enter", vk: 13 },
      tab: { key: "Tab", code: "Tab", vk: 9 },
      escape: { key: "Escape", code: "Escape", vk: 27 },
      esc: { key: "Escape", code: "Escape", vk: 27 },
      backspace: { key: "Backspace", code: "Backspace", vk: 8 },
      delete: { key: "Delete", code: "Delete", vk: 46 },
      space: { key: " ", code: "Space", vk: 32 },
      arrowup: { key: "ArrowUp", code: "ArrowUp", vk: 38 },
      up: { key: "ArrowUp", code: "ArrowUp", vk: 38 },
      arrowdown: { key: "ArrowDown", code: "ArrowDown", vk: 40 },
      down: { key: "ArrowDown", code: "ArrowDown", vk: 40 },
      arrowleft: { key: "ArrowLeft", code: "ArrowLeft", vk: 37 },
      left: { key: "ArrowLeft", code: "ArrowLeft", vk: 37 },
      arrowright: { key: "ArrowRight", code: "ArrowRight", vk: 39 },
      right: { key: "ArrowRight", code: "ArrowRight", vk: 39 },
      home: { key: "Home", code: "Home", vk: 36 },
      end: { key: "End", code: "End", vk: 35 },
      pageup: { key: "PageUp", code: "PageUp", vk: 33 },
      pagedown: { key: "PageDown", code: "PageDown", vk: 34 },
      f5: { key: "F5", code: "F5", vk: 116 }
    };
    MOD_BITS = { alt: 1, ctrl: 2, meta: 4, shift: 8 };
  }
});

// ../schema/dist/wire.js
function makeFrame(seq, id, type, payload, inReplyTo) {
  return { seq, id, inReplyTo, ts: Date.now(), type, payload };
}

// ../schema/dist/action.js
var ACTION_NAMES = [
  // navigation / tabs
  "navigate",
  "open_tab",
  "switch_tab",
  "close_tab",
  "reopen_tab",
  "back",
  "forward",
  "reload",
  // element interaction
  "click",
  "click_at",
  "click_selector",
  "mouse",
  "hover",
  "type",
  "type_selector",
  "press",
  "select",
  "submit",
  "drag",
  "upload",
  // page / clipboard / files
  "scroll",
  "wait",
  "wait_for",
  "clipboard",
  "download",
  "evaluate",
  // control
  "done",
  "ask_user"
];
var ACTION_JSON_SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["name", "args"],
  properties: {
    name: { enum: [...ACTION_NAMES] },
    args: {
      type: "object",
      additionalProperties: false,
      properties: {
        url: { type: "string" },
        tab_id: { type: "integer", minimum: 0 },
        idx: { type: "integer", minimum: 0 },
        x: { type: "integer", minimum: 0 },
        y: { type: "integer", minimum: 0 },
        key: { type: "string", maxLength: 32 },
        modifiers: { type: "array", items: { enum: ["alt", "ctrl", "meta", "shift"] }, maxItems: 4 },
        from_idx: { type: "integer", minimum: 0 },
        to_idx: { type: "integer", minimum: 0 },
        files: { type: "array", items: { type: "string", maxLength: 512 }, maxItems: 16 },
        text: { type: "string", maxLength: 2e3 },
        value: { type: "string", maxLength: 500 },
        clear_first: { type: "boolean" },
        direction: { enum: ["down", "up", "top", "bottom"] },
        amount: { type: "integer", minimum: 1, maximum: 20 },
        ms: { type: "integer", minimum: 100, maximum: 1e4 },
        gone: { type: "boolean" },
        url_contains: { type: "string", maxLength: 200 },
        timeout_ms: { type: "integer", minimum: 500, maximum: 6e4 },
        selector: { type: "string", maxLength: 300 },
        count: { type: "integer", minimum: 1, maximum: 1e4 },
        url_stable_ms: { type: "integer", minimum: 100, maximum: 3e4 },
        dom_idle_ms: { type: "integer", minimum: 100, maximum: 3e4 },
        action: { enum: ["read", "write"] },
        code: { type: "string", maxLength: 4e3 },
        filename: { type: "string", maxLength: 200 },
        question: { type: "string", maxLength: 300 },
        kind: { enum: ["login", "captcha", "confirm", "choice"] },
        choices: { type: "array", items: { type: "string", maxLength: 120 }, maxItems: 6 },
        element_idx: { type: "integer", minimum: 0 },
        result: { type: "object" }
      }
    },
    reason: { type: "string", maxLength: 400 },
    step_id: { type: "string", maxLength: 32 }
  }
};

// src/shared/settings.ts
var DEFAULT_URL = "ws://127.0.0.1:8790/chrome";
var KEY = "vicaro.settings";
var DEFAULTS = { orchestratorUrl: DEFAULT_URL, theme: "auto" };
async function getSettings() {
  const bag = await chrome.storage.local.get(KEY);
  if (bag[KEY]) return { ...DEFAULTS, ...bag[KEY] };
  return { ...DEFAULTS };
}
function onSettingsChanged(cb) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[KEY]) cb({ ...DEFAULTS, ...changes[KEY].newValue ?? {} });
  });
}

// src/background/ws-client.ts
var resumeKey = (role) => `vicaro.resumeToken.${role}`;
var WS_STATE_KEY = "vicaro.wsState";
var WsClient = class {
  constructor(opts) {
    this.opts = opts;
  }
  ws;
  seq = 0;
  backoff = 1e3;
  closed = false;
  connecting = false;
  pending = /* @__PURE__ */ new Map();
  connected = false;
  /** Resume token held in memory for THIS client instance. Bridge persists it in
   *  chrome.storage (one SW); side panels deliberately do not: every panel/window
   *  must own an independent session or they supersede each other in a loop. */
  resumeToken;
  get isOpen() {
    return this.connected && this.ws?.readyState === WebSocket.OPEN;
  }
  async connect() {
    if (this.connecting) return;
    if (this.isOpen) return;
    if (this.ws && this.ws.readyState === WebSocket.CONNECTING) return;
    this.connecting = true;
    try {
      await this.doConnect();
    } finally {
      this.connecting = false;
    }
  }
  async doConnect() {
    if (this.closed) return;
    this.closed = false;
    const settings = await getSettings();
    if (this.closed) return;
    let windowIds;
    try {
      const wins = await chrome.windows.getAll({ populate: false });
      windowIds = wins.map((w) => w.id).filter((id) => Number.isInteger(id));
    } catch {
    }
    if (this.closed) return;
    const url = settings.orchestratorUrl || "ws://127.0.0.1:8790/chrome";
    const persistResume = this.opts.role === "bridge";
    const RESUME_KEY = resumeKey(this.opts.role);
    if (persistResume && !this.resumeToken) {
      const tokenBag = await chrome.storage.local.get(RESUME_KEY);
      this.resumeToken = tokenBag[RESUME_KEY];
    }
    const resumeToken = this.resumeToken;
    this.opts.onState?.("connecting");
    await chrome.storage.local.set({ [WS_STATE_KEY]: "connecting" }).catch(() => {
    });
    const wsUrl = settings.bearer ? `${url}?token=${encodeURIComponent(settings.bearer)}` : url;
    let ws2;
    try {
      ws2 = new WebSocket(wsUrl);
    } catch {
      this.scheduleReconnect();
      return;
    }
    this.ws = ws2;
    ws2.onopen = () => {
      if (this.closed) {
        try {
          ws2.close();
        } catch {
        }
        return;
      }
      if (this.ws !== ws2) {
        try {
          ws2.close();
        } catch {
        }
        return;
      }
      this.backoff = 1e3;
      this.connected = true;
      this.opts.onState?.("open");
      void chrome.storage.local.set({ [WS_STATE_KEY]: "open" }).catch(() => {
      });
      try {
        chrome.alarms.clear("vicaro-reconnect").catch(() => {
        });
      } catch {
      }
      const hello = makeFrame(++this.seq, crypto.randomUUID(), "hello", {
        role: this.opts.role,
        resumeToken,
        agentVersion: chrome.runtime.getManifest().version,
        windowIds
      });
      try {
        ws2.send(JSON.stringify(hello));
      } catch {
      }
    };
    ws2.onmessage = async (ev) => {
      if (this.ws !== ws2) return;
      let frame;
      try {
        frame = JSON.parse(String(ev.data));
      } catch {
        return;
      }
      if (frame.type === "hello_ack") {
        const p = frame.payload ?? {};
        if (typeof p.resumeToken === "string") {
          this.resumeToken = p.resumeToken;
          if (persistResume) await chrome.storage.local.set({ [RESUME_KEY]: p.resumeToken }).catch(() => {
          });
        }
        if (p.resumed) await this.opts.onResume?.(p.resumeToken);
        return;
      }
      if (frame.inReplyTo && this.pending.has(frame.inReplyTo)) {
        const p = this.pending.get(frame.inReplyTo);
        clearTimeout(p.timer);
        this.pending.delete(frame.inReplyTo);
        p.resolve(frame);
        return;
      }
      await this.opts.onFrame(frame);
    };
    ws2.onclose = (ev) => {
      if (this.ws !== ws2) return;
      this.ws = void 0;
      this.connected = false;
      this.opts.onState?.("closed", { code: ev.code, reason: ev.reason });
      void chrome.storage.local.set({ [WS_STATE_KEY]: "closed" }).catch(() => {
      });
      for (const [id, p] of this.pending) {
        clearTimeout(p.timer);
        this.pending.delete(id);
        p.resolve(null);
      }
      if (this.closed) return;
      this.scheduleReconnect();
    };
    ws2.onerror = () => {
    };
  }
  scheduleReconnect() {
    try {
      chrome.alarms.create("vicaro-reconnect", { delayInMinutes: Math.max(this.backoff / 6e4, 0.02) });
    } catch {
    }
    const wait = this.backoff;
    this.backoff = Math.min(this.backoff * 2, 3e4);
    setTimeout(() => {
      if (!this.closed) this.connect().catch(() => {
      });
    }, wait);
  }
  disconnect() {
    this.closed = true;
    try {
      this.ws?.close();
    } catch {
    }
  }
  /** Send a frame and await the correlated reply (null on timeout/close). */
  request(type, payload, timeoutMs = 1e4) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return Promise.resolve(null);
    const frame = makeFrame(++this.seq, crypto.randomUUID(), type, payload);
    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        this.pending.delete(frame.id);
        resolve(null);
      }, timeoutMs);
      this.pending.set(frame.id, { resolve, timer });
      try {
        this.ws.send(JSON.stringify(frame));
      } catch {
        clearTimeout(timer);
        this.pending.delete(frame.id);
        resolve(null);
      }
    });
  }
  /** Fire-and-forget frame. Returns false when the socket is down (caller may queue). */
  emit(type, payload, inReplyTo) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return false;
    try {
      this.ws.send(JSON.stringify(makeFrame(++this.seq, crypto.randomUUID(), type, payload, inReplyTo)));
      return true;
    } catch {
      return false;
    }
  }
};

// src/background/idempotency.ts
var KEY2 = "vicaro.executedKeys";
var MAX = 500;
async function markExecuted(effectKey) {
  const bag = await chrome.storage.local.get(KEY2);
  const keys = bag[KEY2] ?? [];
  if (!keys.includes(effectKey)) {
    keys.push(effectKey);
    while (keys.length > MAX) keys.shift();
    await chrome.storage.local.set({ [KEY2]: keys });
  }
}
async function executedKeys() {
  const bag = await chrome.storage.local.get(KEY2);
  return bag[KEY2] ?? [];
}
async function wasExecuted(effectKey) {
  return (await executedKeys()).includes(effectKey);
}

// src/background/content-bridge.ts
async function pageText(tabId, opts) {
  if (!await ensureContent(tabId)) return null;
  const res = await sendWithTimeout(tabId, { type: "vicaro.text", ...opts }, 4e3);
  if (!res || !res.ok) return null;
  return { text: String(res.text ?? ""), length: Number(res.length ?? 0), matches: Array.isArray(res.matches) ? res.matches : void 0 };
}
async function extractPage(tabId, opts) {
  if (!await ensureContent(tabId)) {
    return { ok: false, error: lastContentError(tabId) ?? "content script unavailable (fresh tab or protected page)" };
  }
  const res = await sendWithTimeout(tabId, { type: "vicaro.extract", ...opts }, 8e3);
  return res ?? { ok: false, error: "extract timed out" };
}
async function rowAction(tabId, rowId, selected, expectedText) {
  if (!await ensureContent(tabId)) {
    return { ok: false, error: lastContentError(tabId) ?? "content script unavailable (fresh tab or protected page)" };
  }
  const res = await sendWithTimeout(tabId, { type: "vicaro.row-action", rowId, selected, expectedText }, 5e3);
  return res ?? { ok: false, error: "row action timed out" };
}
async function controlAction(tabId, opts) {
  if (!await ensureContent(tabId)) {
    return { ok: false, error: lastContentError(tabId) ?? "content script unavailable (fresh tab or protected page)" };
  }
  const res = await sendWithTimeout(tabId, { type: "vicaro.click-named", ...opts }, 5e3);
  return res ?? { ok: false, error: "control action timed out" };
}
var contentErrors = /* @__PURE__ */ new Map();
function lastContentError(tabId) {
  return contentErrors.get(tabId);
}
async function sendWithTimeout(tabId, msg, timeoutMs) {
  try {
    const res = await Promise.race([
      chrome.tabs.sendMessage(tabId, msg),
      new Promise((resolve) => setTimeout(() => resolve(null), timeoutMs))
    ]);
    return res ?? null;
  } catch {
    return null;
  }
}
async function hostPermissionFor(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    const raw = tab.url ?? "";
    if (!/^https?:/i.test(raw)) return null;
    const u = new URL(raw);
    const granted = await chrome.permissions.contains({ origins: [`${u.protocol}//${u.host}/*`] });
    return granted;
  } catch {
    return null;
  }
}
async function waitForTabComplete(tabId, timeoutMs = 4e3) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab.status === "complete") return;
    } catch {
      return;
    }
    await new Promise((r) => setTimeout(r, 150));
  }
}
async function ensureContent(tabId) {
  const ping = await sendWithTimeout(tabId, { type: "vicaro.ping" }, 1e3);
  if (ping?.ok) {
    contentErrors.delete(tabId);
    return true;
  }
  await waitForTabComplete(tabId, 4e3);
  const granted = await hostPermissionFor(tabId);
  if (granted === false) {
    contentErrors.set(tabId, "host permission not granted for this site");
    return false;
  }
  let lastErr = "";
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    } catch (err) {
      lastErr = String(err?.message ?? err).slice(0, 220);
    }
    const ping2 = await sendWithTimeout(tabId, { type: "vicaro.ping" }, 1800);
    if (ping2?.ok) {
      contentErrors.delete(tabId);
      return true;
    }
    if (attempt === 0) await new Promise((r) => setTimeout(r, 350));
  }
  contentErrors.set(tabId, lastErr || "injected but the content script did not answer (page may still be loading)");
  return false;
}
async function perceiveTab(tabId, opts = {}) {
  const ok = await ensureContent(tabId);
  if (!ok) {
    const detail = lastContentError(tabId);
    return { error: `content script unavailable on this page${detail ? `: ${detail}` : ""}` };
  }
  const res = await sendWithTimeout(
    tabId,
    { type: "vicaro.perceive", settle: opts.settle !== false },
    8e3
  );
  if (!res) return { error: "perceive timed out" };
  if (!res.ok || !res.artifact) return { error: res.error ?? "serializer failed" };
  return { artifact: res.artifact };
}
async function resolveElement(tabId, idx) {
  if (!await ensureContent(tabId)) return { ok: false, error: "content script unavailable (fresh tab or protected page)" };
  const res = await sendWithTimeout(tabId, { type: "vicaro.resolve", idx }, 2500);
  return res ?? { ok: false, error: "resolve timed out (page changed?)" };
}
async function domAction(tabId, action) {
  if (!await ensureContent(tabId)) return { ok: false, error: "content script unavailable (fresh tab or protected page)" };
  const res = await sendWithTimeout(
    tabId,
    { type: "vicaro.execute-action", action },
    6e3
  );
  return res ?? { ok: false, error: "execute-action timed out" };
}
async function highlightElement(tabId, idx) {
  const res = await sendWithTimeout(tabId, { type: "vicaro.highlight", idx }, 2e3);
  return !!res?.ok;
}
async function markElement(tabId, idx) {
  if (!await ensureContent(tabId)) return null;
  const res = await sendWithTimeout(tabId, { type: "vicaro.mark", idx }, 2500);
  return res?.ok && res.marker ? res.marker : null;
}
async function unmarkElement(tabId, marker) {
  await sendWithTimeout(tabId, { type: "vicaro.unmark", marker }, 1500);
}

// src/background/executor.ts
init_cdp();

// src/background/tabs.ts
var KEY3 = "vicaro.taskTabs";
async function readMap() {
  const bag = await chrome.storage.local.get(KEY3);
  return bag[KEY3] ?? {};
}
async function getTaskTab(taskId) {
  const map = await readMap();
  const tabId = map[taskId];
  if (tabId === void 0) return void 0;
  try {
    await chrome.tabs.get(tabId);
    return tabId;
  } catch {
    return void 0;
  }
}
async function setTaskTab(taskId, tabId) {
  const map = await readMap();
  map[taskId] = tabId;
  await chrome.storage.local.set({ [KEY3]: map });
}
async function clearTaskTab(taskId) {
  const map = await readMap();
  delete map[taskId];
  await chrome.storage.local.set({ [KEY3]: map });
}
function initTabCleanup() {
  chrome.tabs.onRemoved.addListener(async (tabId) => {
    const map = await readMap();
    let changed = false;
    for (const [taskId, id] of Object.entries(map)) {
      if (id === tabId) {
        delete map[taskId];
        changed = true;
      }
    }
    if (changed) await chrome.storage.local.set({ [KEY3]: map });
  });
}
function isInspectable(url) {
  if (!url) return false;
  return /^https?:/i.test(url) || /^file:/i.test(url);
}
async function listTabs() {
  const tabs = await chrome.tabs.query({});
  return tabs.filter((t) => t.id !== void 0).sort((a, b) => a.windowId - b.windowId || a.index - b.index).map((t) => ({
    tabId: t.id,
    windowId: t.windowId,
    index: t.index,
    url: t.url ?? "",
    title: t.title ?? "",
    active: !!t.active,
    inspectable: isInspectable(t.url)
  }));
}
async function focusTab(tabId) {
  try {
    const tab = await chrome.tabs.update(tabId, { active: true });
    if (tab?.windowId !== void 0) await chrome.windows.update(tab.windowId, { focused: true });
    return true;
  } catch {
    return false;
  }
}
function samePage(a, b) {
  try {
    const ua = new URL(a), ub = new URL(b);
    return ua.origin === ub.origin && ua.pathname.replace(/\/+$/, "") === ub.pathname.replace(/\/+$/, "") && ua.search === ub.search;
  } catch {
    return a === b;
  }
}
async function waitForLoad(tabId, timeoutMs = 12e3, expectUrl) {
  const before = expectUrl ? await chrome.tabs.get(tabId).then((t) => t.url ?? "").catch(() => "") : "";
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab.status === "complete") {
        if (!expectUrl) return true;
        const url = tab.url ?? "";
        if (samePage(url, expectUrl) || isInspectable(url) && url !== before) return true;
      }
    } catch {
      return false;
    }
    await sleep2(150);
  }
  return false;
}
async function activeInspectableTab(windowId) {
  const queries = windowId !== void 0 ? [{ active: true, windowId }] : [{ active: true, lastFocusedWindow: true }, { active: true, currentWindow: true }, { active: true }];
  for (const q of queries) {
    try {
      const [tab] = await chrome.tabs.query(q);
      if (tab?.id !== void 0 && isInspectable(tab.url)) {
        return { tabId: tab.id, url: tab.url ?? "about:blank", windowId: tab.windowId };
      }
    } catch {
    }
  }
  return null;
}
async function ensureTaskTab(taskId, opts = {}) {
  if (opts.tabId !== void 0) {
    try {
      const tab = await chrome.tabs.get(opts.tabId);
      if (opts.windowId !== void 0 && tab.windowId !== opts.windowId) {
        return { error: `tab #${opts.tabId} is in Chrome window w${tab.windowId}; this conversation is limited to w${opts.windowId}` };
      }
      if (!isInspectable(tab.url)) return { error: `tab #${opts.tabId} is not inspectable (${tab.url ?? "unknown"})` };
      await setTaskTab(taskId, opts.tabId);
      await focusTab(opts.tabId);
      const after2 = await chrome.tabs.get(opts.tabId).catch(() => tab);
      return { tabId: opts.tabId, url: after2.url ?? tab.url ?? "about:blank", created: false, windowId: after2.windowId ?? tab.windowId };
    } catch {
      return { error: `tab #${opts.tabId} no longer exists` };
    }
  }
  const existing = await getTaskTab(taskId);
  if (existing !== void 0) {
    try {
      const tab = await chrome.tabs.get(existing);
      const currentUrl = tab.url ?? "about:blank";
      if (opts.windowId !== void 0 && tab.windowId !== opts.windowId) {
        await clearTaskTab(taskId);
      } else if (!isInspectable(currentUrl)) {
        await clearTaskTab(taskId);
      } else {
        if (opts.url && currentUrl === "about:blank") {
          await chrome.tabs.update(existing, { url: opts.url, active: true });
          await waitForLoad(existing, 12e3, opts.url);
        } else {
          await chrome.tabs.update(existing, { active: true });
        }
        const after2 = await chrome.tabs.get(existing);
        return { tabId: existing, url: after2.url ?? currentUrl, created: false, windowId: after2.windowId ?? tab.windowId };
      }
    } catch {
      await clearTaskTab(taskId);
    }
  }
  if (opts.preferActive) {
    const active = await activeInspectableTab(opts.windowId);
    if (active) {
      await setTaskTab(taskId, active.tabId);
      await focusTab(active.tabId);
      return { tabId: active.tabId, url: active.url, created: false, windowId: active.windowId };
    }
  }
  let created;
  try {
    created = await chrome.tabs.create({
      url: opts.url ?? "about:blank",
      active: true,
      ...opts.windowId !== void 0 ? { windowId: opts.windowId } : {}
    });
  } catch (err) {
    return {
      error: `could not create a tab in ${opts.windowId !== void 0 ? `window w${opts.windowId}` : "this window"}: ${String(err?.message ?? err)}`
    };
  }
  if (created?.id === void 0) return { error: "tab creation failed" };
  await setTaskTab(taskId, created.id);
  await waitForLoad(created.id, 12e3, opts.url);
  const after = await chrome.tabs.get(created.id).catch(() => created);
  return { tabId: created.id, url: after.url ?? opts.url ?? "about:blank", created: true, windowId: after.windowId ?? created.windowId };
}
async function navigateTab(tabId, url) {
  try {
    await chrome.tabs.update(tabId, { url });
    const loaded = await waitForLoad(tabId, 12e3, url);
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (!loaded) return { ok: false, url: tab?.url, error: "load not confirmed within timeout" };
    await sleep2(250);
    return { ok: true, url: tab?.url };
  } catch (err) {
    return { ok: false, error: String(err?.message ?? err) };
  }
}
async function goBack(tabId) {
  try {
    await chrome.tabs.goBack(tabId);
    await waitForLoad(tabId, 8e3);
    await sleep2(200);
    return { ok: true };
  } catch (err) {
    return { ok: false, error: `back failed: ${String(err?.message ?? err)}` };
  }
}
async function goForward(tabId) {
  try {
    await chrome.tabs.goForward(tabId);
    await waitForLoad(tabId, 8e3);
    await sleep2(200);
    return { ok: true };
  } catch (err) {
    return { ok: false, error: `forward failed: ${String(err?.message ?? err)}` };
  }
}
async function reloadTab(tabId) {
  try {
    await chrome.tabs.reload(tabId);
    await waitForLoad(tabId, 15e3);
    await sleep2(250);
    return { ok: true };
  } catch (err) {
    return { ok: false, error: `reload failed: ${String(err?.message ?? err)}` };
  }
}
async function closeTab(tabId) {
  try {
    await chrome.tabs.remove(tabId);
    return { ok: true };
  } catch (err) {
    return { ok: false, error: `close failed: ${String(err?.message ?? err)}` };
  }
}
async function reopenLastClosed() {
  if (!chrome.sessions?.restore) {
    return { ok: false, error: 'reopening closed tabs is off - enable "History & closed tabs" in Vicaro Settings -> Access' };
  }
  try {
    const session = await chrome.sessions.restore();
    const tab = session?.tab;
    return { ok: true, tabId: tab?.id, url: tab?.url };
  } catch (err) {
    return { ok: false, error: `nothing to reopen: ${String(err?.message ?? err)}` };
  }
}
async function fetchDocument(tabId, maxBytes = 8e6) {
  try {
    const tab = await chrome.tabs.get(tabId);
    const url = tab.url ?? "";
    if (!/^https?:/i.test(url)) return { error: `cannot fetch ${url.slice(0, 80) || "(empty url)"}` };
    const res = await fetch(url, { credentials: "include", redirect: "follow" });
    if (!res.ok) return { error: `fetch HTTP ${res.status} for ${url.slice(0, 80)}` };
    const mime = res.headers.get("content-type") ?? "";
    const buf2 = new Uint8Array(await res.arrayBuffer());
    if (buf2.length > maxBytes) return { error: `document too large (${(buf2.length / 1e6).toFixed(1)} MB > ${(maxBytes / 1e6).toFixed(0)} MB)` };
    const size = buf2.length;
    if (/^text\/|json|xml|javascript|csv|markdown/i.test(mime)) {
      return { url, mime, size, text: new TextDecoder().decode(buf2).slice(0, 15e5), truncated: buf2.length > 15e5 || void 0 };
    }
    return { url, mime, size, base64: bytesToBase64(buf2) };
  } catch (err) {
    return { error: `document fetch failed: ${String(err?.message ?? err).slice(0, 160)}` };
  }
}
function bytesToBase64(bytes) {
  let bin = "";
  for (let i = 0; i < bytes.length; i += 32768) {
    bin += String.fromCharCode(...bytes.subarray(i, i + 32768));
  }
  return btoa(bin);
}
function sleep2(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// src/background/executor.ts
async function executeAction(tabId, action, taskId) {
  switch (action.name) {
    case "navigate":
      return await doNavigate(tabId, String(action.args.url));
    case "open_tab":
      return await doOpenTab(String(action.args.url ?? ""), taskId, tabId);
    case "switch_tab":
      return await doSwitchTab(Number(action.args.tab_id), taskId);
    case "close_tab":
      return await doCloseTab(action.args.tab_id !== void 0 ? Number(action.args.tab_id) : tabId);
    case "reopen_tab":
      return await doReopen();
    case "reload":
      return await doReload(tabId);
    case "forward":
      return await doForward(tabId);
    case "click":
      return await doClick(tabId, Number(action.args.idx));
    case "click_selector":
      return await domAction(tabId, { name: "click_selector", args: { selector: String(action.args.selector ?? "") } });
    case "click_at":
      return await doClickAt(tabId, Number(action.args.x), Number(action.args.y));
    case "mouse":
      return await doMouse(tabId, action.args);
    case "hover":
      return await doHover(tabId, Number(action.args.idx));
    case "type":
      return await doType(tabId, Number(action.args.idx), String(action.args.text ?? ""), !!action.args.clear_first);
    case "type_selector":
      return await domAction(tabId, { name: "type_selector", args: { selector: String(action.args.selector ?? ""), text: String(action.args.text ?? ""), clear_first: !!action.args.clear_first } });
    case "press":
      return await doPress(tabId, String(action.args.key ?? ""), Array.isArray(action.args.modifiers) ? action.args.modifiers.map(String) : []);
    case "select":
      return await doSelect(tabId, Number(action.args.idx), String(action.args.value ?? ""));
    case "drag":
      return await doDrag(tabId, Number(action.args.from_idx), Number(action.args.to_idx));
    case "upload":
      return await doUpload(tabId, Number(action.args.idx), Array.isArray(action.args.files) ? action.args.files.map(String) : []);
    case "scroll":
      return await doScroll(tabId, String(action.args.direction), Number(action.args.amount) || 3, action.args.idx !== void 0 ? Number(action.args.idx) : void 0);
    case "submit":
      return await doSubmit(tabId, action.args.idx !== void 0 ? Number(action.args.idx) : void 0);
    case "back":
      return await doBack(tabId);
    case "wait": {
      const ms = Math.min(Math.max(Number(action.args.ms) || 500, 100), 1e4);
      await sleep3(ms);
      return { ok: true, result: { waited: ms } };
    }
    case "wait_for":
      return await doWaitFor(tabId, action.args);
    case "clipboard":
      return await doClipboard(tabId, String(action.args.action), String(action.args.text ?? ""));
    case "download":
      return await doDownload(String(action.args.url), action.args.filename !== void 0 ? String(action.args.filename) : void 0);
    case "evaluate":
      return await doEvaluate(tabId, String(action.args.code ?? ""));
    default:
      return { ok: false, error: `action "${action.name}" is not executable here` };
  }
}
async function doNavigate(tabId, url) {
  let u;
  try {
    u = new URL(url);
  } catch {
    return { ok: false, error: "invalid url" };
  }
  if (!["http:", "https:", "file:"].includes(u.protocol)) return { ok: false, error: `navigation to ${u.protocol} blocked` };
  const res = await navigateTab(tabId, url);
  return res.ok ? { ok: true, result: { url: res.url } } : { ok: false, error: res.error };
}
async function doOpenTab(url, taskId, contextTabId) {
  let target = !url || url === "about:blank" ? "about:blank" : url;
  if (target !== "about:blank") {
    let u;
    try {
      u = new URL(target);
    } catch {
      return { ok: false, error: "invalid url" };
    }
    if (!["http:", "https:", "file:"].includes(u.protocol)) return { ok: false, error: `opening ${u.protocol} tabs is blocked` };
    target = u.toString();
  }
  let windowId;
  if (contextTabId !== void 0 && contextTabId >= 0) {
    try {
      windowId = (await chrome.tabs.get(contextTabId)).windowId;
    } catch {
    }
  }
  try {
    const tab = await chrome.tabs.create({ url: target, active: true, ...windowId !== void 0 ? { windowId } : {} });
    if (tab.id === void 0) return { ok: false, error: "tab creation failed" };
    const lastFocused = await chrome.windows.getLastFocused().catch(() => null);
    if (tab.windowId !== void 0 && lastFocused?.id === tab.windowId) {
      await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {
      });
    }
    if (taskId) {
      await setTaskTab(taskId, tab.id);
      await waitForLoad(tab.id, 1e4, target).catch(() => false);
    }
    const after = await chrome.tabs.get(tab.id).catch(() => tab);
    return { ok: true, result: { tabId: tab.id, url: after.url ?? target } };
  } catch (err) {
    return { ok: false, error: String(err?.message ?? err) };
  }
}
async function doSwitchTab(tabId, taskId) {
  if (!Number.isInteger(tabId) || tabId < 0) return { ok: false, error: "tab_id must be a non-negative integer" };
  const focused = await focusTab(tabId);
  if (!focused) return { ok: false, error: `tab #${tabId} no longer exists` };
  if (taskId) await setTaskTab(taskId, tabId);
  return { ok: true, result: { tabId } };
}
async function doCloseTab(tabId) {
  if (!Number.isInteger(tabId) || tabId < 0) return { ok: false, error: "bad tab id" };
  const gone = await closeTab(tabId);
  if (!gone.ok) return { ok: false, error: gone.error };
  return { ok: true, result: { closed: tabId } };
}
async function doReopen() {
  const res = await reopenLastClosed();
  if (!res.ok) return { ok: false, error: res.error };
  return { ok: true, result: { tabId: res.tabId, url: res.url } };
}
async function doReload(tabId) {
  const res = await reloadTab(tabId);
  return res.ok ? { ok: true, result: { reloaded: true } } : { ok: false, error: res.error };
}
async function doForward(tabId) {
  const res = await goForward(tabId);
  return res.ok ? { ok: true, result: { forwarded: true } } : { ok: false, error: res.error };
}
async function doClick(tabId, idx) {
  const resolved = await resolveElement(tabId, idx);
  if (!resolved.ok || !resolved.rect) return { ok: false, error: resolved.error ?? "element not found (page changed?)" };
  if (resolved.inViewport === false) return { ok: false, error: "element is outside the viewport - not clicking blind coordinates" };
  const { x, y } = center(resolved.rect);
  if (await ensureAttached(tabId)) {
    try {
      await mouseClick(tabId, x, y);
      return { ok: true, result: { via: "cdp", role: resolved.role } };
    } catch (err) {
      logCdpFallback("click", err);
    }
  }
  const dom = await domAction(tabId, { name: "click", args: { idx } });
  return dom.ok ? { ok: true, result: { via: "dom", role: resolved.role } } : dom;
}
async function doClickAt(tabId, x, y) {
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0) return { ok: false, error: "click_at needs non-negative x,y" };
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab) return { ok: false, error: "that tab no longer exists" };
  const url = tab.url ?? "";
  if (!url || /^(?:about:blank|chrome:\/\/newtab|chrome:\/\/welcome|chrome-error:\/\/)/i.test(url)) {
    return { ok: false, error: `nothing to click: this tab is ${url || "blank"} - navigate to a real page, wait for it to load, then take a fresh screenshot` };
  }
  if (await ensureAttached(tabId)) {
    try {
      await mouseClick(tabId, Math.round(x), Math.round(y));
      return { ok: true, result: { via: "cdp", x: Math.round(x), y: Math.round(y) } };
    } catch (err) {
      logCdpFallback("click_at", err);
    }
  }
  const dom = await domAction(tabId, { name: "click_at", args: { x: Math.round(x), y: Math.round(y) } });
  return dom.ok ? { ok: true, result: { via: "dom", ...dom.result } } : dom;
}
async function doMouse(tabId, args) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab) return { ok: false, error: "that tab no longer exists" };
  const url = tab.url ?? "";
  if (!url || /^(?:about:blank|chrome:\/\/newtab|chrome:\/\/welcome|chrome-error:\/\/)/i.test(url)) {
    return { ok: false, error: `nothing to click: this tab is ${url || "blank"} - navigate to a real page first` };
  }
  const button = ["left", "right", "middle"].includes(String(args.button)) ? String(args.button) : "left";
  const clicks = Number(args.clicks) === 2 ? 2 : 1;
  let x = Number(args.x);
  let y = Number(args.y);
  if (Number.isInteger(args.idx)) {
    const resolved = await resolveElement(tabId, Number(args.idx));
    if (!resolved.ok || !resolved.rect) return { ok: false, error: resolved.error ?? "element not found (page changed?)" };
    if (resolved.inViewport === false) return { ok: false, error: "element is outside the viewport - not clicking blind coordinates" };
    const c = center(resolved.rect);
    x = c.x;
    y = c.y;
  } else if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0) {
    return { ok: false, error: "mouse needs an element idx or non-negative x,y" };
  }
  if (await ensureAttached(tabId)) {
    try {
      await mouseClick(tabId, Math.round(x), Math.round(y), { button, clickCount: clicks });
      return { ok: true, result: { via: "cdp", button, clicks, x: Math.round(x), y: Math.round(y) } };
    } catch (err) {
      logCdpFallback("mouse", err);
    }
  }
  const dom = await domAction(tabId, { name: "mouse", args: { x: Math.round(x), y: Math.round(y), button, clicks } });
  return dom.ok ? { ok: true, result: { via: "dom", button, clicks, ...dom.result } } : dom;
}
async function doHover(tabId, idx) {
  const resolved = await resolveElement(tabId, idx);
  if (!resolved.ok || !resolved.rect) return { ok: false, error: resolved.error ?? "element not found (page changed?)" };
  const { x, y } = center(resolved.rect);
  if (await ensureAttached(tabId)) {
    try {
      await hoverAt(tabId, x, y);
      await sleep3(120);
      return { ok: true, result: { via: "cdp", role: resolved.role } };
    } catch (err) {
      logCdpFallback("hover", err);
    }
  }
  const dom = await domAction(tabId, { name: "hover", args: { idx } });
  return dom.ok ? { ok: true, result: { via: "dom", role: resolved.role } } : dom;
}
async function doType(tabId, idx, text, clearFirst) {
  if (text.length > 2e3) return { ok: false, error: "text too long" };
  if (/\{\{\s*secret:[^}]+\}\}/.test(text)) return { ok: false, error: "unresolved secret reference - refusing to type a literal {{secret:*}} into the page" };
  const resolved = await resolveElement(tabId, idx);
  if (!resolved.ok || !resolved.rect) return { ok: false, error: resolved.error ?? "element not found (page changed?)" };
  if (resolved.inViewport === false) return { ok: false, error: "element is outside the viewport - not typing into blind coordinates" };
  if (await ensureAttached(tabId)) {
    try {
      const { x, y } = center(resolved.rect);
      await mouseClick(tabId, x, y);
      await sleep3(80);
      if (clearFirst) {
        await selectAll(tabId);
        await pressBackspace(tabId);
        await sleep3(40);
      }
      if (text) await insertText(tabId, text);
      const check = await domAction(tabId, { name: "type", args: { idx, text, clear_first: clearFirst, verify: true } });
      if (check.ok) return { ok: true, result: { via: "cdp", verified: check.result?.verified ?? true, sensitive: resolved.sensitive } };
      return { ok: true, result: { via: "cdp", sensitive: resolved.sensitive } };
    } catch (err) {
      logCdpFallback("type", err);
    }
  }
  const dom = await domAction(tabId, { name: "type", args: { idx, text, clear_first: clearFirst } });
  return dom.ok ? { ok: true, result: { via: "dom", sensitive: resolved.sensitive } } : dom;
}
async function doPress(tabId, key, modifiers) {
  if (!key.trim()) return { ok: false, error: "press needs a key" };
  if (await ensureAttached(tabId)) {
    try {
      const { key: k, bits } = await pressKeyCombo(tabId, key, modifiers);
      return { ok: true, result: { via: "cdp", key: k, modifiers: bits } };
    } catch (err) {
      logCdpFallback("press", err);
    }
  }
  const dom = await domAction(tabId, { name: "press", args: { key, modifiers } });
  return dom.ok ? { ok: true, result: { via: "dom", ...dom.result } } : dom;
}
async function pressBackspace(tabId) {
  await send(tabId, "Input.dispatchKeyEvent", { type: "keyDown", key: "Backspace", code: "Backspace", windowsVirtualKeyCode: 8 });
  await send(tabId, "Input.dispatchKeyEvent", { type: "keyUp", key: "Backspace", code: "Backspace", windowsVirtualKeyCode: 8 });
}
async function doSelect(tabId, idx, value) {
  const dom = await domAction(tabId, { name: "select", args: { idx, value } });
  return dom.ok ? { ok: true, result: { via: "dom", value } } : dom;
}
async function doDrag(tabId, fromIdx, toIdx) {
  const from = await resolveElement(tabId, fromIdx);
  const to = await resolveElement(tabId, toIdx);
  if (!from.ok || !from.rect) return { ok: false, error: from.error ?? `drag source #${fromIdx} not found` };
  if (!to.ok || !to.rect) return { ok: false, error: to.error ?? `drag target #${toIdx} not found` };
  if (await ensureAttached(tabId)) {
    try {
      await dragPath(tabId, center(from.rect), center(to.rect));
      return { ok: true, result: { via: "cdp", from: fromIdx, to: toIdx } };
    } catch (err) {
      logCdpFallback("drag", err);
    }
  }
  const dom = await domAction(tabId, { name: "drag", args: { from_idx: fromIdx, to_idx: toIdx } });
  return dom.ok ? { ok: true, result: { via: "dom", from: fromIdx, to: toIdx } } : dom;
}
async function doUpload(tabId, idx, files) {
  if (!files.length) return { ok: false, error: "no files given" };
  if (!await ensureAttached(tabId)) return { ok: false, error: "file upload needs the debugger attachment (CDP)" };
  const resolved = await resolveElement(tabId, idx);
  if (!resolved.ok) return { ok: false, error: resolved.error ?? "file input not found (page changed?)" };
  if (resolved.inputType && resolved.inputType !== "file") return { ok: false, error: `#${idx} is <input type=${resolved.inputType}>, not a file input` };
  const marker = await markElement(tabId, idx);
  if (!marker) return { ok: false, error: "could not mark the file input (page changed?)" };
  try {
    await setFileInputFiles(tabId, marker, files);
    return { ok: true, result: { via: "cdp", files: files.length } };
  } catch (err) {
    return { ok: false, error: String(err?.message ?? err) };
  } finally {
    await unmarkElement(tabId, marker);
  }
}
async function doScroll(tabId, direction, amount, idx) {
  if (!["up", "down", "top", "bottom"].includes(direction)) return { ok: false, error: `bad scroll direction "${direction}"` };
  if (idx !== void 0) {
    const dom2 = await domAction(tabId, { name: "scroll", args: { direction, amount, idx } });
    return dom2.ok ? { ok: true, result: { via: "dom", container: idx, ...dom2.result ?? {} } } : dom2;
  }
  const steps = Math.min(Math.max(amount, 1), 20);
  const dom = await domAction(tabId, { name: "scroll", args: { direction, amount: steps } });
  if (dom.ok) return { ok: true, result: { via: "dom", direction, steps, ...dom.result ?? {} } };
  if (await ensureAttached(tabId)) {
    try {
      const viewport = await send(tabId, "Runtime.evaluate", {
        expression: "JSON.stringify([innerWidth, innerHeight])",
        returnByValue: true
      }).catch(() => null);
      let cx = 640, cy = 400;
      try {
        const arr = JSON.parse(viewport?.result?.value ?? "null");
        if (Array.isArray(arr) && arr.length === 2) {
          cx = arr[0] / 2;
          cy = arr[1] / 2;
        }
      } catch {
      }
      const delta = (direction === "up" || direction === "top" ? -1 : 1) * steps * 600;
      await wheel(tabId, cx, cy, delta);
      await sleep3(150);
      return { ok: true, result: { via: "cdp", direction, steps } };
    } catch (err) {
      logCdpFallback("scroll", err);
    }
  }
  return dom;
}
async function doSubmit(tabId, idx) {
  if (idx !== void 0) {
    const click = await doClick(tabId, idx);
    if (click.ok) return { ok: true, result: { via: click.result?.via, submit: "clicked" } };
  }
  if (await ensureAttached(tabId)) {
    try {
      await pressEnter(tabId);
      return { ok: true, result: { via: "cdp", submit: "enter" } };
    } catch (err) {
      logCdpFallback("submit", err);
    }
  }
  const dom = await domAction(tabId, { name: "submit", args: {} });
  return dom.ok ? { ok: true, result: { via: "dom", submit: "form" } } : dom;
}
async function doBack(tabId) {
  const res = await goBack(tabId);
  return res.ok ? { ok: true, result: { back: true } } : { ok: false, error: res.error };
}
async function doWaitFor(tabId, args) {
  const dom = await domAction(tabId, { name: "wait_for", args });
  if (dom.ok) return { ok: true, result: dom.result };
  return { ok: false, error: dom.error };
}
async function doClipboard(tabId, op, text) {
  if (op !== "read" && op !== "write") return { ok: false, error: 'clipboard action must be "read" or "write"' };
  if (await ensureAttached(tabId)) {
    try {
      try {
        const tab = await chrome.tabs.get(tabId);
        if (tab.url) {
          const origin = new URL(tab.url).origin;
          await send(tabId, "Browser.grantPermissions", {
            origin,
            permissions: ["clipboardReadWrite", "clipboardSanitizedWrite"]
          });
        }
      } catch {
      }
      if (op === "write") {
        await evaluate(tabId, `navigator.clipboard.writeText(${JSON.stringify(text)}).then(() => true)`, { userGesture: true });
        return { ok: true, result: { via: "cdp", copied: text.length } };
      }
      const value = await evaluate(tabId, "navigator.clipboard.readText()", { userGesture: true });
      return { ok: true, result: { via: "cdp", text: String(value ?? "").slice(0, 2e4), length: String(value ?? "").length } };
    } catch (err) {
      logCdpFallback("clipboard", err);
    }
  }
  const dom = await domAction(tabId, { name: "clipboard", args: { action: op, text } });
  return dom.ok ? { ok: true, result: dom.result } : dom;
}
async function doDownload(url, filename) {
  let u;
  try {
    u = new URL(url);
  } catch {
    return { ok: false, error: "invalid url" };
  }
  if (!["http:", "https:"].includes(u.protocol)) return { ok: false, error: `download of ${u.protocol} blocked` };
  try {
    const id = await chrome.downloads.download({ url: u.toString(), filename });
    return { ok: true, result: { downloadId: id, url: u.toString() } };
  } catch (err) {
    return { ok: false, error: `download failed: ${String(err?.message ?? err)}` };
  }
}
async function doEvaluate(tabId, code) {
  if (!code.trim()) return { ok: false, error: "evaluate needs code" };
  if (!await ensureAttached(tabId)) return { ok: false, error: "evaluate needs the debugger attachment (CDP)" };
  try {
    const value = await evaluate(tabId, code, { awaitPromise: true });
    let serialized = value;
    try {
      JSON.stringify(value);
    } catch {
      serialized = String(value);
    }
    return { ok: true, result: { value: serialized } };
  } catch (err) {
    return { ok: false, error: String(err?.message ?? err).slice(0, 300) };
  }
}
function center(r) {
  return { x: Math.round(r.x + r.w / 2), y: Math.round(r.y + r.h / 2) };
}
function logCdpFallback(op, err) {
  console.warn(`[vicaro] CDP ${op} failed, falling back to DOM executor:`, String(err?.message ?? err).slice(0, 120));
}
function sleep3(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// src/background/main.ts
init_cdp();

// src/background/screenshot.ts
init_cdp();
var MAX_EDGE = 1600;
var THUMB_W = 460;
var PREVIEW_W = 880;
async function captureForTab(tabId, opts = {}) {
  if (await ensureAttached(tabId)) {
    const cdp = await captureScreenshotRegion(tabId, opts.rect);
    if (cdp) {
      const img = await resizeToWidth(cdp.base64, MAX_EDGE).catch(() => null) ?? { jpegBase64: cdp.base64, width: cdp.cssWidth, height: cdp.cssHeight };
      if (img.jpegBase64.length > 3e6 && !opts.rect) return { error: "screenshot too large and downscale unavailable" };
      const thumb = await resizeToWidth(img.jpegBase64, THUMB_W).catch(() => null);
      const preview = await resizeToWidth(img.jpegBase64, PREVIEW_W).catch(() => null);
      let jpeg = img.jpegBase64;
      if (opts.grid && !opts.rect) {
        const gridded = await drawGrid(jpeg).catch(() => null);
        if (gridded) jpeg = gridded;
      }
      const out = {
        jpegBase64: jpeg,
        width: img.width,
        height: img.height,
        url: await tabUrl(tabId),
        thumbBase64: thumb?.jpegBase64,
        previewBase64: preview?.jpegBase64,
        idx: opts.idx
      };
      if (!opts.rect) {
        out.viewport = { w: cdp.cssWidth, h: cdp.cssHeight };
        out.scale = img.width / cdp.cssWidth;
      }
      return out;
    }
  }
  try {
    if (opts.rect) return { error: "region screenshots need the debugger attachment" };
    const tab = await chrome.tabs.get(tabId);
    if (tab.windowId === void 0) return { error: "no window for tab" };
    if (!tab.active) return { error: "task tab is not visible; cannot capture via visible-tab fallback" };
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "jpeg", quality: 82 });
    const base64 = dataUrl.replace(/^data:image\/jpeg;base64,/, "");
    const img = await resizeToWidth(base64, MAX_EDGE).catch(() => null);
    if (!img) return { error: "capture failed (no image tools)" };
    const thumb = await resizeToWidth(img.jpegBase64, THUMB_W).catch(() => null);
    const preview = await resizeToWidth(img.jpegBase64, PREVIEW_W).catch(() => null);
    return { jpegBase64: img.jpegBase64, width: img.width, height: img.height, url: tab.url, thumbBase64: thumb?.jpegBase64, previewBase64: preview?.jpegBase64 };
  } catch (err) {
    return { error: `capture failed: ${String(err?.message ?? err)}` };
  }
}
async function captureForTask(taskId, opts = {}) {
  const tabId = await getTaskTab(taskId);
  if (tabId === void 0) return { error: "no task tab" };
  return captureForTab(tabId, opts);
}
async function tabUrl(tabId) {
  try {
    return (await chrome.tabs.get(tabId)).url;
  } catch {
    return void 0;
  }
}
async function resizeToWidth(jpegBase64, maxW) {
  if (typeof createImageBitmap !== "function" || typeof OffscreenCanvas !== "function") return null;
  const bytes = base64ToBytes(jpegBase64);
  const blob = new Blob([bytes], { type: "image/jpeg" });
  const bitmap = await createImageBitmap(blob);
  const factor = maxW > 0 ? Math.min(1, maxW / bitmap.width) : 1;
  if (factor >= 1) return { jpegBase64, width: bitmap.width, height: bitmap.height };
  const w = Math.max(1, Math.round(bitmap.width * factor));
  const h = Math.max(1, Math.round(bitmap.height * factor));
  const canvas = new OffscreenCanvas(w, h);
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  ctx.drawImage(bitmap, 0, 0, w, h);
  const out = await canvas.convertToBlob({ type: "image/jpeg", quality: 0.82 });
  const buf2 = await out.arrayBuffer();
  return { jpegBase64: bytesToBase642(new Uint8Array(buf2)), width: w, height: h };
}
async function drawGrid(jpegBase64, spacing = 100) {
  if (typeof createImageBitmap !== "function" || typeof OffscreenCanvas !== "function") return null;
  const bitmap = await createImageBitmap(new Blob([base64ToBytes(jpegBase64)], { type: "image/jpeg" }));
  const w = bitmap.width, h = bitmap.height;
  const canvas = new OffscreenCanvas(w, h);
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  ctx.drawImage(bitmap, 0, 0);
  ctx.lineWidth = 1;
  ctx.strokeStyle = "rgba(215,60,60,0.35)";
  ctx.fillStyle = "rgba(215,60,60,0.9)";
  ctx.font = "11px ui-monospace, Menlo, monospace";
  ctx.textBaseline = "top";
  for (let x = spacing; x < w; x += spacing) {
    ctx.beginPath();
    ctx.moveTo(x + 0.5, 0);
    ctx.lineTo(x + 0.5, h);
    ctx.stroke();
    ctx.fillText(String(x), Math.min(x + 3, w - 30), 3);
  }
  for (let y = spacing; y < h; y += spacing) {
    ctx.beginPath();
    ctx.moveTo(0, y + 0.5);
    ctx.lineTo(w, y + 0.5);
    ctx.stroke();
    ctx.fillText(String(y), 3, Math.min(y + 3, h - 14));
  }
  const out = await canvas.convertToBlob({ type: "image/jpeg", quality: 0.85 });
  return bytesToBase642(new Uint8Array(await out.arrayBuffer()));
}
function base64ToBytes(b64) {
  const bin = atob(b64);
  const bytes = new Uint8Array(new ArrayBuffer(bin.length));
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}
function bytesToBase642(bytes) {
  let bin = "";
  for (let i = 0; i < bytes.length; i += 32768) {
    bin += String.fromCharCode(...bytes.subarray(i, i + 32768));
  }
  return btoa(bin);
}

// src/background/devtools.ts
init_cdp();
var MAX2 = 400;
var MAX_CAPTURE = 250;
var BODY_CAP = 128 * 1024;
var POST_CAP = 64 * 1024;
var NET_ENABLE = { maxTotalBufferSize: 16e6, maxResourceBufferSize: 4e6, maxPostDataSize: 128e3 };
var buffers = /* @__PURE__ */ new Map();
function buf(tabId) {
  let b = buffers.get(tabId);
  if (!b) {
    b = {
      console: [],
      network: [],
      consoleOn: false,
      netOn: false,
      armed: false,
      seq: 0,
      pending: /* @__PURE__ */ new Map(),
      sessions: /* @__PURE__ */ new Set()
    };
    buffers.set(tabId, b);
  }
  return b;
}
function sourceSession(source) {
  const sid = source.sessionId;
  return typeof sid === "string" && sid ? sid : void 0;
}
var listenersReady2 = false;
function initDevtools() {
  if (listenersReady2) return;
  try {
    chrome.debugger.onDetach.addListener((source) => {
      if (source.tabId !== void 0) buffers.delete(source.tabId);
    });
    chrome.tabs.onRemoved.addListener((tabId) => {
      buffers.delete(tabId);
    });
    chrome.debugger.onEvent.addListener((source, method, params) => {
      const tabId = source.tabId;
      if (tabId === void 0) return;
      const b = buffers.get(tabId);
      if (!b) return;
      const sid = sourceSession(source);
      switch (method) {
        case "Runtime.consoleAPICalled": {
          const level = String(params?.type ?? "log");
          const text = (params?.args ?? []).map((a) => a?.value !== void 0 ? stringify(a.value) : a?.description ?? a?.type ?? "").join(" ").slice(0, 500);
          pushConsole(b, { ts: params?.timestamp ?? Date.now(), level, text, url: params?.stackTrace?.callFrames?.[0]?.url });
          break;
        }
        case "Log.entryAdded": {
          const e = params?.entry ?? {};
          pushConsole(b, { ts: e.timestamp ?? Date.now(), level: String(e.level ?? "info"), text: String(e.text ?? "").slice(0, 500), url: e.url });
          break;
        }
        case "Target.attachedToTarget": {
          const childSid = String(params?.sessionId ?? "");
          if (!childSid) break;
          b.sessions.add(childSid);
          void sendSession(tabId, childSid, "Network.enable", NET_ENABLE).catch(() => null);
          void sendSession(tabId, childSid, "Runtime.runIfWaitingForDebugger").catch(() => null);
          break;
        }
        case "Target.detachedFromTarget": {
          const gone = String(params?.sessionId ?? "");
          if (gone) b.sessions.delete(gone);
          break;
        }
        case "Network.requestWillBeSent": {
          const requestId = String(params?.requestId ?? "");
          if (!requestId) break;
          const req = params?.request ?? {};
          const key = `${sid ?? ""}:${requestId}`;
          const entry = {
            id: `req_${++b.seq}`,
            requestId,
            sessionId: sid,
            ts: params?.timestamp ? Math.round(params.timestamp * 1e3) : Date.now(),
            method: String(req.method ?? "GET"),
            url: String(req.url ?? ""),
            type: params?.type ? String(params.type) : void 0,
            frameId: params?.frameId ? String(params.frameId) : void 0,
            requestHeaders: normalizeHeaders(req.headers),
            postData: typeof req.postData === "string" ? cap(req.postData, POST_CAP) : void 0,
            postDataTruncated: typeof req.postData === "string" && req.postData.length > POST_CAP
          };
          const prev = b.pending.get(key);
          if (prev && params?.redirectResponse) {
            prev.status = params.redirectResponse.status;
            prev.responseHeaders = normalizeHeaders(params.redirectResponse.headers);
          }
          b.pending.set(key, entry);
          b.network.push(entry);
          if (b.network.length > MAX_CAPTURE) {
            const dropped = b.network.splice(0, b.network.length - MAX_CAPTURE);
            for (const d of dropped) b.pending.delete(`${d.sessionId ?? ""}:${d.requestId}`);
          }
          break;
        }
        case "Network.responseReceived": {
          const p = b.pending.get(`${sid ?? ""}:${String(params?.requestId ?? "")}`);
          if (!p) break;
          const res = params?.response ?? {};
          p.status = res.status;
          p.mimeType = res.mimeType;
          p.responseHeaders = normalizeHeaders(res.headers);
          p.fromCache = !!res.fromDiskCache || !!res.fromServiceWorker;
          break;
        }
        case "Network.loadingFinished": {
          const key = `${sid ?? ""}:${String(params?.requestId ?? "")}`;
          const p = b.pending.get(key);
          if (!p) break;
          p.bytes = Number(params?.encodedDataLength) || void 0;
          p.ms = params?.timestamp && p.ts ? Math.max(0, Math.round(params.timestamp * 1e3 - p.ts)) : void 0;
          b.pending.delete(key);
          break;
        }
        case "Network.loadingFailed": {
          const key = `${sid ?? ""}:${String(params?.requestId ?? "")}`;
          const p = b.pending.get(key);
          if (!p) break;
          p.failed = String(params?.errorText ?? "failed");
          b.pending.delete(key);
          break;
        }
        default:
          break;
      }
    });
    listenersReady2 = true;
  } catch {
  }
}
function pushConsole(b, e) {
  b.console.push(e);
  if (b.console.length > MAX2) b.console.splice(0, b.console.length - MAX2);
}
function normalizeHeaders(h) {
  if (!h || typeof h !== "object") return void 0;
  const out = {};
  for (const [k, v] of Object.entries(h)) out[k] = String(v);
  return Object.keys(out).length ? out : void 0;
}
function cap(text, limit) {
  return text.length > limit ? `${text.slice(0, limit)}
\u2026(truncated ${text.length - limit} chars)` : text;
}
var SECRET_HEADER = /authorization|proxy-authorization|cookie|set-cookie|x-api-key|api-key|access-token|bearer/i;
function redactHeaders(h, includeSecrets) {
  if (!h) return void 0;
  const out = {};
  for (const [k, v] of Object.entries(h)) {
    out[k] = !includeSecrets && SECRET_HEADER.test(k) ? "\xABredacted - pass include_secrets:true\xBB" : v;
  }
  return out;
}
function stringify(v) {
  try {
    return typeof v === "string" ? v : JSON.stringify(v);
  } catch {
    return String(v);
  }
}
async function devtoolsConsole(tabId, opts = {}) {
  const b = buf(tabId);
  if (!b.consoleOn) {
    if (!await ensureAttached(tabId)) throw new Error("debugger attachment unavailable for this tab");
    await send(tabId, "Runtime.enable").catch(() => null);
    await send(tabId, "Log.enable").catch(() => null);
    b.consoleOn = true;
  }
  const filter = opts.filter?.trim().toLowerCase();
  const rows = filter ? b.console.filter((e) => `${e.text} ${e.url ?? ""}`.toLowerCase().includes(filter)) : [...b.console];
  return rows.slice(-Math.min(Math.max(opts.limit ?? 50, 1), 200));
}
async function devtoolsNetwork(tabId, opts = {}) {
  const b = buf(tabId);
  if (!b.netOn) {
    if (!await ensureAttached(tabId)) throw new Error("debugger attachment unavailable for this tab");
    await send(tabId, "Network.enable", NET_ENABLE).catch(() => null);
    b.netOn = true;
  }
  const filter = opts.filter?.trim().toLowerCase();
  const rows = filter ? b.network.filter((e) => `${e.url} ${e.method} ${e.status ?? ""}`.toLowerCase().includes(filter)) : [...b.network];
  return rows.slice(-Math.min(Math.max(opts.limit ?? 50, 1), 200));
}
async function devtoolsCaptureStart(tabId) {
  const b = buf(tabId);
  if (!await ensureAttached(tabId)) throw new Error("debugger attachment unavailable for this tab");
  await send(tabId, "Network.enable", NET_ENABLE).catch(() => null);
  await send(tabId, "Target.setAutoAttach", { autoAttach: true, waitForDebuggerOnStart: false, flatten: true }).catch(() => null);
  b.netOn = true;
  b.armed = true;
  b.startedAt = Date.now();
  b.network = [];
  b.pending.clear();
  b.sessions.clear();
  b.seq = 0;
  return { started: true, startedAt: b.startedAt, tabId };
}
function devtoolsCaptureStop(tabId) {
  const b = buffers.get(tabId);
  if (!b) return { stopped: true, count: 0 };
  b.armed = false;
  return { stopped: true, count: b.network.length };
}
function devtoolsCaptureList(tabId, opts = {}) {
  const b = buffers.get(tabId) ?? buf(tabId);
  const filter = opts.filter?.trim().toLowerCase();
  const rows = filter ? b.network.filter((e) => `${e.url} ${e.method} ${e.status ?? ""} ${e.type ?? ""}`.toLowerCase().includes(filter)) : [...b.network];
  const limit = Math.min(Math.max(opts.limit ?? 50, 1), 200);
  return {
    armed: b.armed,
    startedAt: b.startedAt,
    count: b.network.length,
    entries: rows.slice(-limit).map((e) => ({
      id: e.id,
      ts: e.ts,
      method: e.method,
      url: e.url,
      type: e.type,
      frameId: e.frameId,
      status: e.status,
      mimeType: e.mimeType,
      bytes: e.bytes,
      ms: e.ms,
      failed: e.failed,
      fromCache: e.fromCache,
      hasBody: !e.failed && e.status !== void 0 && !/^(script|stylesheet|image|font|media)$/i.test(e.type ?? "")
    }))
  };
}
async function devtoolsCaptureBody(tabId, id, includeSecrets = false, filter) {
  const b = buffers.get(tabId);
  let entry = b?.network.find((e) => e.id === id || e.requestId === id);
  if (!entry && !id && filter) {
    const f = filter.trim().toLowerCase();
    entry = [...b?.network ?? []].reverse().find((e) => `${e.url} ${e.method} ${e.type ?? ""}`.toLowerCase().includes(f));
  }
  if (!entry) throw new Error(id ? `no captured request "${id}" (run capture list to get ids)` : `no captured request matches "${filter ?? ""}"`);
  let postData = entry.postData;
  if (!postData) {
    const pd = await sendSession(tabId, entry.sessionId, "Network.getRequestPostData", { requestId: entry.requestId }).catch(() => null);
    if (pd?.postData) postData = cap(pd.postData, POST_CAP);
  }
  const out = {
    id: entry.id,
    method: entry.method,
    url: entry.url,
    status: entry.status,
    mimeType: entry.mimeType,
    requestHeaders: redactHeaders(entry.requestHeaders, includeSecrets),
    postData,
    postDataTruncated: postData ? postData.length >= POST_CAP : void 0,
    responseHeaders: redactHeaders(entry.responseHeaders, includeSecrets)
  };
  try {
    const rb = await sendSession(
      tabId,
      entry.sessionId,
      "Network.getResponseBody",
      { requestId: entry.requestId }
    );
    const raw = String(rb?.body ?? "");
    out.base64 = !!rb?.base64Encoded;
    out.bodyTruncated = raw.length > BODY_CAP;
    out.body = cap(raw, BODY_CAP);
  } catch (err) {
    out.note = `Response body unavailable (${String(err?.message ?? err).slice(0, 140)}). Bodies exist only for requests captured after start and before the CDP buffer evicts them.`;
  }
  return out;
}
async function devtoolsPerf(tabId) {
  if (!await ensureAttached(tabId)) throw new Error("debugger attachment unavailable for this tab");
  await send(tabId, "Performance.enable").catch(() => null);
  const res = await send(tabId, "Performance.getMetrics");
  return (res?.metrics ?? []).map((m) => ({ name: m.name, value: m.value }));
}

// src/background/downloads.ts
var recent = [];
var MAX3 = 60;
function initDownloads() {
  try {
    chrome.downloads.onCreated.addListener((item) => {
      touch(item);
    });
    chrome.downloads.onChanged.addListener((delta) => {
      void chrome.downloads.search({ id: delta.id }).then(([item]) => {
        if (item) touch(item);
      }).catch(() => {
      });
    });
  } catch {
  }
}
async function primeDownloads() {
  try {
    const items = await chrome.downloads.search({ limit: 25, orderBy: ["-startTime"] });
    for (const item of items.reverse()) touch(item);
  } catch {
  }
}
function listDownloads(limit = 20) {
  return recent.slice(0, Math.min(Math.max(limit, 1), MAX3));
}
function touch(item) {
  const size = item.fileSize > 0 ? item.fileSize : item.bytesReceived > 0 ? item.bytesReceived : item.totalBytes;
  const info = {
    id: item.id,
    filename: item.filename,
    url: item.url,
    mime: item.mime || void 0,
    bytes: size || void 0,
    state: item.state,
    startTime: item.startTime ? Date.parse(item.startTime) : void 0,
    error: item.error || void 0
  };
  const i = recent.findIndex((d) => d.id === info.id);
  if (i >= 0) recent[i] = info;
  else recent.unshift(info);
  if (recent.length > MAX3) recent.length = MAX3;
}

// src/background/history.ts
async function searchHistory(opts) {
  if (!chrome.history?.search) {
    throw new Error('browsing history is off - enable "History & closed tabs" in Vicaro Settings -> Access');
  }
  const text = String(opts.query ?? "").trim();
  const maxResults = Math.min(200, Math.max(1, Number(opts.limit) || 50));
  const since = Number(opts.since);
  const items = await chrome.history.search({
    text,
    startTime: Number.isFinite(since) && since > 0 ? since : 0,
    maxResults
  });
  return items.filter((i) => typeof i.url === "string" && /^(https?|file):/i.test(i.url)).map((i) => ({
    url: String(i.url),
    title: String(i.title ?? "").trim(),
    lastVisitTime: Number(i.lastVisitTime ?? 0),
    visitCount: Number(i.visitCount ?? 0),
    typedCount: i.typedCount !== void 0 ? Number(i.typedCount) : void 0
  })).sort((a, b) => b.lastVisitTime - a.lastVisitTime).slice(0, maxResults);
}

// src/background/main.ts
var ws = null;
function client() {
  if (ws) {
    if (!ws.isOpen) void ws.connect().catch(() => {
    });
    return ws;
  }
  ws = new WsClient({
    role: "bridge",
    onFrame: async (f) => {
      observeBroadcasts(f);
      await handleFrame(f);
    },
    onResume: async () => {
      console.log("[vicaro] re-attached to orchestrator session");
    }
  });
  ws.connect().catch(() => {
  });
  return ws;
}
async function handleFrame(frame) {
  switch (frame.type) {
    case "action_command":
      return void await onActionCommand(frame);
    case "perceive_request":
      return void await onPerceive(frame);
    case "page_text_request":
      return void await onPageText(frame);
    case "extract_request":
      return void await onExtract(frame);
    case "row_action_request":
      return void await onRowAction(frame);
    case "control_action_request":
      return void await onControlAction(frame);
    case "screenshot_request":
      return void await onScreenshot(frame);
    case "tab_ensure":
      return void await onTabEnsure(frame);
    case "tabs_list": {
      try {
        ws?.emit("tabs_snapshot", { tabs: await listTabs() }, frame.id);
      } catch (err) {
        ws?.emit("tabs_snapshot", { tabs: [], error: String(err?.message ?? err) }, frame.id);
      }
      return;
    }
    case "highlight":
      return void await onHighlight(frame);
    case "devtools_request":
      return void await onDevtools(frame);
    case "downloads_request": {
      try {
        ws?.emit("downloads_result", { downloads: listDownloads(20) }, frame.id);
      } catch (err) {
        ws?.emit("downloads_result", { downloads: [], error: String(err?.message ?? err) }, frame.id);
      }
      return;
    }
    case "history_request":
      return void await onHistory(frame);
    case "document_request":
      return void await onDocument(frame);
    case "frames_request":
      return void await onFrames(frame);
    case "frame_request":
      return void await onFrameAction(frame);
    case "task_command":
      return void await onTaskEcho(frame);
    case "resume_request":
      if (frame.payload?.reconcile) {
        const keys = await executedKeys();
        ws?.emit("resume_state", { taskId: frame.payload?.taskId, executedKeys: keys }, frame.id);
      }
      return;
    default:
      return;
  }
}
async function onActionCommand(frame) {
  const p = frame.payload;
  if (!p?.effectKey || !p?.action) return;
  const taskId = p.taskId;
  if (await wasExecuted(p.effectKey)) {
    reply(p, true, { deduped: true }, void 0, frame.id);
    return;
  }
  let tabId = p.tabId;
  if (tabId !== void 0) {
    try {
      await chrome.tabs.get(tabId);
    } catch {
      tabId = void 0;
    }
    if (tabId === void 0) {
      reply(p, false, void 0, "explicit tab no longer exists", frame.id);
      return;
    }
  } else {
    tabId = await getTaskTab(taskId);
  }
  if (tabId === void 0) {
    const NO_TAB = /* @__PURE__ */ new Set(["open_tab", "switch_tab", "reopen_tab", "download", "wait"]);
    if (NO_TAB.has(p.action.name)) tabId = -1;
    else {
      reply(p, false, void 0, "no browser tab for this task", frame.id);
      return;
    }
  }
  let result;
  try {
    result = await executeAction(tabId, p.action, taskId);
  } catch (err) {
    result = { ok: false, error: String(err?.message ?? err) };
  }
  await markExecuted(p.effectKey);
  reply(p, result.ok, result.result, result.error, frame.id);
}
function reply(p, ok, result, error, inReplyTo) {
  const ev = {
    taskId: p.taskId,
    step: p.step,
    kind: "action",
    ok,
    result: result ?? void 0,
    error: error ?? void 0,
    effectKey: p.effectKey
  };
  ws?.emit("device_event", ev, inReplyTo);
}
async function onPerceive(frame) {
  const { taskId, tabId: explicit, url } = frame.payload ?? {};
  let tabId = explicit ?? (taskId ? await getTaskTab(taskId) : void 0);
  if (tabId !== void 0) {
    try {
      await chrome.tabs.get(tabId);
    } catch {
      ws?.emit("page_artifact", { artifact: null, captureError: "tab no longer exists", tabLost: true }, frame.id);
      return;
    }
  } else {
    tabId = await activeTabId();
  }
  if (tabId === void 0) {
    ws?.emit("page_artifact", { artifact: null, captureError: "no active tab" }, frame.id);
    return;
  }
  const res = await perceiveTab(tabId, { settle: true });
  if ("error" in res) {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    ws?.emit("page_artifact", {
      artifact: null,
      captureError: res.error,
      url: tab?.url ?? url,
      title: tab?.title
    }, frame.id);
  } else ws?.emit("page_artifact", { artifact: res.artifact }, frame.id);
}
async function onPageText(frame) {
  const { taskId, tabId: explicit, query, offset, max } = frame.payload ?? {};
  let tabId = explicit ?? (taskId ? await getTaskTab(taskId) : void 0);
  if (tabId !== void 0) {
    try {
      await chrome.tabs.get(tabId);
    } catch {
      ws?.emit("page_text", { text: "", length: 0, error: "tab no longer exists" }, frame.id);
      return;
    }
  } else {
    tabId = await activeTabId();
  }
  if (tabId === void 0) {
    ws?.emit("page_text", { text: "", length: 0, error: "no active tab" }, frame.id);
    return;
  }
  const res = await pageText(tabId, { query, offset, max });
  if (!res) ws?.emit("page_text", { text: "", length: 0, error: "content script unavailable" }, frame.id);
  else ws?.emit("page_text", res, frame.id);
}
async function onExtract(frame) {
  const { taskId, tabId: explicit, mode, selector, fields, limit, include_without_checkbox } = frame.payload ?? {};
  let tabId = explicit ?? (taskId ? await getTaskTab(taskId) : void 0);
  if (tabId !== void 0) {
    try {
      await chrome.tabs.get(tabId);
    } catch {
      ws?.emit("extract_result", { error: "tab no longer exists" }, frame.id);
      return;
    }
  } else {
    tabId = await activeTabId();
  }
  if (tabId === void 0) {
    ws?.emit("extract_result", { error: "no active tab" }, frame.id);
    return;
  }
  const res = await extractPage(tabId, { mode, selector, fields, limit, include_without_checkbox });
  ws?.emit("extract_result", res, frame.id);
}
async function onRowAction(frame) {
  const { taskId, tabId: explicit, rowId, selected, expectedText } = frame.payload ?? {};
  let tabId = explicit ?? (taskId ? await getTaskTab(taskId) : void 0);
  if (tabId !== void 0) {
    try {
      await chrome.tabs.get(tabId);
    } catch {
      ws?.emit("row_action", { ok: false, error: "tab no longer exists" }, frame.id);
      return;
    }
  } else {
    tabId = await activeTabId();
  }
  if (tabId === void 0) {
    ws?.emit("row_action", { ok: false, error: "no active tab" }, frame.id);
    return;
  }
  if (!rowId) {
    ws?.emit("row_action", { ok: false, error: "rowId is required" }, frame.id);
    return;
  }
  const res = await rowAction(tabId, String(rowId), selected === true, expectedText ? String(expectedText) : void 0);
  ws?.emit("row_action", res, frame.id);
}
async function onControlAction(frame) {
  const { taskId, tabId: explicit, name, role, within } = frame.payload ?? {};
  let tabId = explicit ?? (taskId ? await getTaskTab(taskId) : void 0);
  if (tabId !== void 0) {
    try {
      await chrome.tabs.get(tabId);
    } catch {
      ws?.emit("control_action", { ok: false, error: "tab no longer exists" }, frame.id);
      return;
    }
  } else {
    tabId = await activeTabId();
  }
  if (tabId === void 0) {
    ws?.emit("control_action", { ok: false, error: "no active tab" }, frame.id);
    return;
  }
  if (!name) {
    ws?.emit("control_action", { ok: false, error: "name is required" }, frame.id);
    return;
  }
  const res = await controlAction(tabId, { name: String(name), role: role ? String(role) : void 0, within: within ? String(within) : void 0 });
  ws?.emit("control_action", res, frame.id);
}
async function onScreenshot(frame) {
  const { taskId, tabId, idx, grid } = frame.payload ?? {};
  let res;
  if (idx !== void 0) {
    const target = tabId ?? (taskId ? await getTaskTab(taskId) : void 0) ?? await activeTabId();
    if (target === void 0) res = { error: "no tab" };
    else {
      const el = await resolveElement(target, Number(idx));
      if (!el.ok || !el.rect) res = { error: el.error ?? "element not found for the region shot" };
      else res = await captureForTab(target, { rect: el.rect, idx: Number(idx) });
    }
  } else {
    res = tabId !== void 0 ? await captureForTab(Number(tabId), { grid: !!grid }) : taskId ? await captureForTask(taskId, { grid: !!grid }) : { error: "no taskId" };
  }
  if ("error" in res) ws?.emit("screenshot", { error: res.error }, frame.id);
  else ws?.emit("screenshot", res, frame.id);
}
async function onDevtools(frame) {
  const p = frame.payload ?? {};
  const kind = String(p.kind ?? "console");
  const requested = Number.isInteger(p.tabId) ? Number(p.tabId) : void 0;
  const tabId = requested ?? (p.taskId ? await getTaskTab(p.taskId) : void 0) ?? await activeTabId();
  try {
    if (tabId === void 0) throw new Error("no tab for devtools");
    if (kind === "console") {
      ws?.emit("devtools_result", { kind, tabId, console: await devtoolsConsole(tabId, { filter: p.filter, limit: p.limit }) }, frame.id);
    } else if (kind === "network") {
      ws?.emit("devtools_result", { kind, tabId, network: await devtoolsNetwork(tabId, { filter: p.filter, limit: p.limit }) }, frame.id);
    } else if (kind === "perf") {
      ws?.emit("devtools_result", { kind, tabId, perf: await devtoolsPerf(tabId) }, frame.id);
    } else if (kind === "capture_start") {
      ws?.emit("devtools_result", { kind, tabId, capture: await devtoolsCaptureStart(tabId) }, frame.id);
    } else if (kind === "capture_stop") {
      ws?.emit("devtools_result", { kind, tabId, capture: devtoolsCaptureStop(tabId) }, frame.id);
    } else if (kind === "capture_list") {
      ws?.emit("devtools_result", { kind, tabId, capture: devtoolsCaptureList(tabId, { filter: p.filter, limit: p.limit }) }, frame.id);
    } else if (kind === "capture_body") {
      ws?.emit("devtools_result", {
        kind,
        tabId,
        capture: { body: await devtoolsCaptureBody(tabId, String(p.requestId ?? ""), !!p.includeSecrets, typeof p.filter === "string" ? p.filter : void 0) }
      }, frame.id);
    } else if (kind === "evaluate") {
      if (!await ensureAttached(tabId)) throw new Error("debugger attachment unavailable for this tab");
      const { evaluate: evaluate2 } = await Promise.resolve().then(() => (init_cdp(), cdp_exports));
      const value = await evaluate2(tabId, String(p.expression ?? ""));
      ws?.emit("devtools_result", { kind, tabId, value }, frame.id);
    } else {
      throw new Error(`unknown devtools kind "${kind}"`);
    }
  } catch (err) {
    ws?.emit("devtools_result", { kind, tabId, error: String(err?.message ?? err).slice(0, 300) }, frame.id);
  }
}
async function onHistory(frame) {
  const p = frame.payload ?? {};
  try {
    const entries = await searchHistory({ query: p.query, since: p.since, limit: p.limit });
    ws?.emit("history_result", { entries }, frame.id);
  } catch (err) {
    ws?.emit("history_result", { entries: [], error: String(err?.message ?? err).slice(0, 300) }, frame.id);
  }
}
async function onDocument(frame) {
  const { taskId, tabId: explicit, maxBytes } = frame.payload ?? {};
  let tabId = explicit ?? (taskId ? await getTaskTab(taskId) : void 0);
  if (tabId === void 0) tabId = await activeTabId();
  if (tabId === void 0) {
    ws?.emit("document", { error: "no tab" }, frame.id);
    return;
  }
  const res = await fetchDocument(tabId, Number(maxBytes) || 8e6);
  ws?.emit("document", res, frame.id);
}
async function onFrames(frame) {
  const { taskId, tabId: explicit } = frame.payload ?? {};
  let tabId = explicit ?? (taskId ? await getTaskTab(taskId) : void 0);
  if (tabId === void 0) {
    ws?.emit("frames_result", { frames: [], error: "no tab" }, frame.id);
    return;
  }
  if (!await ensureAttached(tabId)) {
    ws?.emit("frames_result", { frames: [], error: "debugger not attached" }, frame.id);
    return;
  }
  try {
    await send(tabId, "Page.enable").catch(() => null);
    const tree = await send(tabId, "Page.getFrameTree");
    const flatten = (node, parentId) => {
      if (!node?.frame) return [];
      const out = [{ frameId: node.frame.id, parentId, url: node.frame.url ?? "", name: node.frame.name ?? "" }];
      for (const child of node.childFrames ?? []) out.push(...flatten(child, node.frame.id));
      return out;
    };
    ws?.emit("frames_result", { frames: flatten(tree.frameTree) }, frame.id);
  } catch (err) {
    ws?.emit("frames_result", { frames: [], error: String(err?.message ?? err) }, frame.id);
  }
}
async function onFrameAction(frame) {
  const { taskId, tabId: explicit, frameId, mode, selector, text } = frame.payload ?? {};
  let tabId = explicit ?? (taskId ? await getTaskTab(taskId) : void 0);
  if (tabId === void 0) {
    ws?.emit("frame_result", { ok: false, error: "no tab" }, frame.id);
    return;
  }
  if (!frameId || !await ensureAttached(tabId)) {
    ws?.emit("frame_result", { ok: false, error: "frame actions need a debugger attachment and a frameId" }, frame.id);
    return;
  }
  try {
    await send(tabId, "Page.enable").catch(() => null);
    await send(tabId, "Runtime.enable").catch(() => null);
    const { executionContextId } = await send(tabId, "Page.createIsolatedWorld", {
      frameId: String(frameId),
      worldName: "vicaro-frame",
      grantUniveralAccess: false
    });
    const run = async (expression) => {
      const res = await send(tabId, "Runtime.evaluate", {
        expression,
        contextId: executionContextId,
        returnByValue: true,
        awaitPromise: true
      });
      if (res.exceptionDetails) throw new Error(res.exceptionDetails.text ?? "frame evaluation failed");
      return res.result?.value;
    };
    if (mode === "read") {
      const value = await run(`(() => {
        const path = (el) => {
          if (el.id) return "#" + CSS.escape(el.id);
          const bits = [];
          while (el && el.nodeType === 1) {
            let s = el.tagName.toLowerCase();
            const parent = el.parentElement;
            if (parent) {
              let i = 1, sib = el;
              while ((sib = sib.previousElementSibling)) if (sib.tagName === el.tagName) i++;
              s += ":nth-of-type(" + i + ")";
            }
            bits.unshift(s);
            el = parent;
          }
          return bits.join(" > ");
        };
        const sels = "a[href],button,input,select,textarea,[role=button],[role=link],[role=textbox],[contenteditable=true]";
        return [...document.querySelectorAll(sels)].slice(0, 120).map((el) => {
          const r = el.getBoundingClientRect();
          return {
            selector: path(el),
            tag: el.tagName.toLowerCase(),
            role: el.getAttribute("role") || el.tagName.toLowerCase(),
            text: String(el.innerText || el.value || el.getAttribute("aria-label") || el.getAttribute("placeholder") || "").replace(/\\s+/g, " ").trim().slice(0, 120),
            inViewport: r.width > 0 && r.height > 0 && r.top < innerHeight && r.bottom > 0
          };
        });
      })()`);
      ws?.emit("frame_result", { ok: true, elements: value ?? [] }, frame.id);
      return;
    }
    if (mode === "click") {
      if (!selector) throw new Error("selector required");
      const value = await run(`(() => {
        const el = document.querySelector(${JSON.stringify(String(selector))});
        if (!el) return { ok: false, error: "selector not found" };
        el.scrollIntoView({ block: "center", inline: "center" });
        el.click();
        return { ok: true };
      })()`);
      ws?.emit("frame_result", value ?? { ok: false, error: "no result" }, frame.id);
      return;
    }
    if (mode === "type") {
      if (!selector) throw new Error("selector required");
      const value = await run(`(() => {
        const el = document.querySelector(${JSON.stringify(String(selector))});
        if (!el) return { ok: false, error: "selector not found" };
        if (!("value" in el)) return { ok: false, error: "not a field" };
        el.focus();
        const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
        if (setter) setter.call(el, ${JSON.stringify(String(text ?? ""))}); else el.value = ${JSON.stringify(String(text ?? ""))};
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        return { ok: true };
      })()`);
      ws?.emit("frame_result", value ?? { ok: false, error: "no result" }, frame.id);
      return;
    }
    ws?.emit("frame_result", { ok: false, error: `unknown frame mode "${mode}"` }, frame.id);
  } catch (err) {
    ws?.emit("frame_result", { ok: false, error: String(err?.message ?? err) }, frame.id);
  }
}
async function onTabEnsure(frame) {
  const { taskId, url, tabId, preferActive, windowId } = frame.payload ?? {};
  if (!taskId) {
    ws?.emit("tab_ready", { error: "no taskId" }, frame.id);
    return;
  }
  try {
    const res = await ensureTaskTab(taskId, { url, tabId, preferActive, windowId });
    if ("error" in res) ws?.emit("tab_ready", { taskId, error: res.error }, frame.id);
    else ws?.emit("tab_ready", { taskId, tabId: res.tabId, url: res.url, created: res.created, windowId: res.windowId }, frame.id);
  } catch (err) {
    ws?.emit("tab_ready", { taskId, error: String(err?.message ?? err) }, frame.id);
  }
}
async function onHighlight(frame) {
  const { taskId, idx, tabId: explicit } = frame.payload ?? {};
  const tabId = explicit ?? (taskId ? await getTaskTab(taskId) : void 0);
  if (tabId === void 0) {
    ws?.emit("command_ack", { ok: false, error: "no tab" }, frame.id);
    return;
  }
  await ensureContent(tabId);
  const ok = await highlightElement(tabId, Number(idx));
  ws?.emit("command_ack", { ok }, frame.id);
}
async function onTaskEcho(frame) {
  const p = frame.payload;
  if (!p?.effectKey) return;
  if (await wasExecuted(p.effectKey)) {
    ws?.emit("device_event", { taskId: p.taskId, step: p.step, kind: p.command?.kind ?? "task-echo", ok: true, result: { deduped: true }, effectKey: p.effectKey }, frame.id);
    return;
  }
  let tabOk = false;
  try {
    const tabId = await activeTabId();
    if (tabId !== void 0) tabOk = await ensureContent(tabId).catch(() => false);
  } catch {
  }
  await markExecuted(p.effectKey);
  ws?.emit("device_event", { taskId: p.taskId, step: p.step, kind: p.command?.kind ?? "task-echo", ok: true, result: { echoed: p.command?.text, tabOk }, effectKey: p.effectKey }, frame.id);
}
async function activeTabId() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab?.id;
  } catch {
    return void 0;
  }
}
async function panelOpen() {
  try {
    const contexts = await chrome.runtime.getContexts({ contextTypes: ["SIDE_PANEL"] });
    return contexts.length > 0;
  } catch {
    return false;
  }
}
async function windowFocused() {
  try {
    const w = await chrome.windows.getLastFocused();
    return !!w.focused;
  } catch {
    return true;
  }
}
async function setBadge(kind) {
  try {
    if (kind === "none") {
      await chrome.action.setBadgeText({ text: "" });
      return;
    }
    const map = {
      confirm: { text: "!", color: "#c0392b" },
      handoff: { text: "\u2022", color: "#2f6fd6" },
      done: { text: "\u2713", color: "#1e8449" }
    };
    await chrome.action.setBadgeText({ text: map[kind].text });
    await chrome.action.setBadgeBackgroundColor({ color: map[kind].color });
  } catch {
  }
}
async function notify(title, message) {
  if (await panelOpen()) return;
  if (await windowFocused()) return;
  try {
    await chrome.notifications.create(`vicaro-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, {
      type: "basic",
      iconUrl: chrome.runtime.getURL("icon128.png"),
      title,
      message,
      priority: 1
    });
  } catch {
  }
}
function observeBroadcasts(frame) {
  if (frame.type === "confirm_request") {
    const p = frame.payload ?? {};
    if (p.kind === "confirm") {
      void setBadge("confirm");
      void notify("Approval needed", p.action?.summary ? `Vicaro wants to ${p.action.summary}.` : "Vicaro is waiting for your approval.");
    } else if (p.kind === "handoff") {
      void setBadge("handoff");
      void notify("Your turn", String(p.question ?? "Vicaro is waiting for you."));
    } else if (p.kind === "ask_user") {
      void setBadge("confirm");
      void notify("Vicaro needs guidance", String(p.question ?? "The agent is blocked."));
    }
  } else if (frame.type === "chat_done") {
    const conversationId = String(frame.payload?.conversationId ?? "");
    const taskId = conversationId ? `chat:${conversationId}` : "";
    void (taskId ? getTaskTab(taskId).then((tabId) => tabId ? detach(tabId) : detachAll()) : detachAll());
  } else if (frame.type === "task_status") {
    const s = frame.payload?.status;
    if (s === "done") {
      void setBadge("done");
      void notify("Task finished", String(frame.payload?.taskId ? `Task ${frame.payload.taskId} finished.` : "Task finished."));
      const taskId = String(frame.payload?.taskId ?? "");
      void (taskId ? getTaskTab(taskId).then((tabId) => tabId ? detach(tabId) : detachAll()) : detachAll());
    } else if (s === "waiting_user") {
    } else if (s === "running" || s === "planning") {
      void setBadge("none");
    }
  }
}
chrome.runtime.onInstalled.addListener(() => {
  client();
  void setupPanel();
});
chrome.runtime.onStartup.addListener(() => {
  client();
  void setupPanel();
});
async function setupPanel() {
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  } catch {
  }
}
chrome.alarms.create("vicaro-keepalive", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "vicaro-keepalive") {
    client().request("ping", { keepalive: true }, 5e3).catch(() => {
    });
  }
  if (a.name === "vicaro-reconnect") {
    client();
  }
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "vicaro.bridgeStatus") {
    sendResponse({ connected: !!ws?.isOpen });
    return true;
  }
  if (msg?.type === "vicaro.panelOpened") {
    void setBadge("none");
    sendResponse({ ok: true });
    return true;
  }
  if (msg?.type === "vicaro.settingsChanged") {
    try {
      ws?.disconnect();
    } catch {
    }
    ws = null;
    client();
    sendResponse({ ok: true });
    return true;
  }
  return false;
});
initCdp();
initDevtools();
try {
  chrome.permissions.onAdded.addListener(() => {
    initCdp();
    initDevtools();
  });
} catch {
}
initDownloads();
void primeDownloads();
initTabCleanup();
onSettingsChanged(() => {
  try {
    ws?.disconnect();
  } catch {
  }
  ws = null;
  client();
});
client();
