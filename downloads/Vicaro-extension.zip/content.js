"use strict";
(() => {
  // src/content/element-map.ts
  var map = /* @__PURE__ */ new Map();
  var identities = /* @__PURE__ */ new Map();
  var epoch = 0;
  function resetMap() {
    map.clear();
    identities.clear();
    epoch++;
  }
  function put(idx, el, identity) {
    map.set(idx, new WeakRef(el));
    identities.set(idx, identity);
  }
  function resolveValidated(idx) {
    const ref = map.get(idx);
    const id = identities.get(idx);
    if (!ref || !id) return null;
    const el = ref.deref();
    if (!el || !el.isConnected) return null;
    if (roleOf(el) !== id.role) return null;
    if (collapse(textOf(el)).slice(0, 24) !== id.textPrefix) return null;
    const r = topRect(el);
    const dx = Math.round(r.x + window.scrollX), dy = Math.round(r.y + window.scrollY);
    if (Math.abs(dx - id.rect.x) > 20 || Math.abs(dy - id.rect.y) > 20) return null;
    return el;
  }
  function topRect(el) {
    const r = el.getBoundingClientRect();
    let x = r.x, y = r.y;
    let win = el.ownerDocument?.defaultView ?? null;
    let guard = 0;
    while (win && win !== window && guard++ < 10) {
      const frame = win.frameElement;
      if (!frame) break;
      const fr = frame.getBoundingClientRect();
      x += fr.x;
      y += fr.y;
      win = frame.ownerDocument?.defaultView ?? null;
    }
    return { x, y, w: r.width, h: r.height };
  }
  function deepText(root, budget = 4e5, includeOverlays = false) {
    const out = [];
    let used = 0;
    const skipTags = /* @__PURE__ */ new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE", "HEAD", "META", "LINK"]);
    const walk = (node) => {
      if (used > budget) return;
      if (node.nodeType === Node.TEXT_NODE) {
        const t = node.nodeValue ?? "";
        if (t.trim()) {
          out.push(t);
          used += t.length;
        }
        return;
      }
      if (node.nodeType !== Node.ELEMENT_NODE && node.nodeType !== Node.DOCUMENT_NODE && node.nodeType !== Node.DOCUMENT_FRAGMENT_NODE) return;
      const el = node;
      if (el.nodeType === Node.ELEMENT_NODE) {
        const tag = el.tagName.toUpperCase();
        if (skipTags.has(tag)) return;
        if (el.hasAttribute("hidden") || el.hasAttribute("inert") || el.getAttribute("aria-hidden") === "true") return;
        if (!includeOverlays && el.matches('[role="dialog"], [aria-modal="true"], dialog, [data-vicaro-overlay]')) return;
        if (el instanceof HTMLIFrameElement) {
          try {
            const cd = el.contentDocument;
            if (cd) walk(cd);
          } catch {
          }
        }
      }
      const sr = el.shadowRoot;
      if (sr) walk(sr);
      for (let c = node.firstChild; c; c = c.nextSibling) walk(c);
    };
    walk(root);
    return out.join(" ").replace(/\s+/g, " ").trim();
  }
  function roleOf(el) {
    const explicit = el.getAttribute("role");
    if (explicit) return explicit;
    const t = el.tagName.toLowerCase();
    if (t === "a") return el.hasAttribute("href") ? "link" : "generic";
    if (t === "button") return "button";
    if (t === "input") {
      const it = el.type;
      if (it === "checkbox") return "checkbox";
      if (it === "radio") return "radio";
      if (it === "search") return "searchbox";
      if (it === "submit" || it === "button" || it === "image") return "button";
      return "textbox";
    }
    if (t === "select") return "combobox";
    if (t === "textarea") return "textbox";
    if (t === "details") return "disclosure";
    if (t === "summary") return "button";
    return "generic";
  }
  function accessibleName(el, seen = /* @__PURE__ */ new Set()) {
    if (seen.has(el)) return "";
    seen.add(el);
    const attr = (name2) => collapse(el.getAttribute(name2) ?? "");
    const aria = attr("aria-label");
    if (aria) return aria.slice(0, 240);
    const labelledBy = attr("aria-labelledby");
    if (labelledBy) {
      const text2 = labelledBy.split(/\s+/).map((id) => {
        const target = el.ownerDocument.getElementById(id);
        return target ? accessibleName(target, seen) : "";
      }).filter(Boolean).join(" ");
      if (text2.trim()) return collapse(text2).slice(0, 240);
    }
    const labels = el.labels;
    if (labels?.length) {
      const text2 = Array.from(labels).map((l) => collapse(l.textContent ?? "")).filter(Boolean).join(" ");
      if (text2.trim()) return text2.slice(0, 240);
    }
    const alt = attr("alt");
    if (alt) return alt.slice(0, 240);
    const title = attr("title");
    if (title) return title.slice(0, 240);
    const tooltip = attr("data-tooltip");
    if (tooltip) return tooltip.slice(0, 240);
    const tooltipHost = el.closest("[data-tooltip]");
    if (tooltipHost && tooltipHost !== el) {
      const text2 = collapse(tooltipHost.getAttribute("data-tooltip") ?? "");
      if (text2) return text2.slice(0, 240);
    }
    const description = attr("aria-description");
    if (description) return description.slice(0, 240);
    if (el.tagName === "INPUT") {
      const i = el;
      if (["button", "submit", "reset"].includes(i.type) && i.value) return collapse(i.value).slice(0, 240);
      if (i.placeholder) return collapse(i.placeholder).slice(0, 240);
    }
    const text = (el.innerText || el.textContent || "").trim();
    if (text) return collapse(text).slice(0, 240);
    const svgTitle = (el.querySelector("svg title")?.textContent ?? "").trim();
    if (svgTitle) return collapse(svgTitle).slice(0, 240);
    const nestedLabel = (el.querySelector("[aria-label]")?.getAttribute("aria-label") ?? "").trim();
    if (nestedLabel) return collapse(nestedLabel).slice(0, 240);
    const imageAlt = (el.querySelector("img[alt]")?.getAttribute("alt") ?? "").trim();
    if (imageAlt) return collapse(imageAlt).slice(0, 240);
    const name = attr("name");
    return name.slice(0, 240);
  }
  function textOf(el) {
    const name = accessibleName(el);
    if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
      return name || collapse(el.placeholder ?? "");
    }
    return name;
  }
  function collapse(s) {
    return s.replace(/\s+/g, " ").trim();
  }

  // src/content/serializer.ts
  var MAX_ELEMENTS = 120;
  var LOW_COUNT = 3;
  var HIGH_COUNT = 400;
  var ROW_SELECTOR = '[role="row"], tr, [role="listitem"], [role="option"], [role="treeitem"], li';
  var CANDIDATE_SELECTOR = [
    "a[href]",
    "button",
    "input",
    "select",
    "textarea",
    "[role=button]",
    "[role=link]",
    "[role=textbox]",
    "[role=combobox]",
    "[role=searchbox]",
    "[role=menuitem]",
    "[role=tab]",
    "[role=option]",
    "[role=checkbox]",
    "[role=radio]",
    "[contenteditable=true]",
    "details",
    "summary",
    "[onclick]",
    "[tabindex]",
    "[draggable=true]"
  ].join(",");
  var PAYMENT_HINT = /\b(cc|card|credit|cvv|cvc|expir|billing|payment)\b/i;
  var SECRET_HINT = /\b(password|passwd|secret|otp|pin|2fa|auth)\b/i;
  function isSensitive(el) {
    const i = el;
    if (i.type === "password") return true;
    const hint = ((i.name ?? "") + " " + (i.id ?? "") + " " + (i.getAttribute("autocomplete") ?? "") + " " + (i.getAttribute("aria-label") ?? "")).toLowerCase();
    return SECRET_HINT.test(hint) || PAYMENT_HINT.test(hint) && i.tagName === "INPUT" && i.type !== "hidden";
  }
  function isVisible(el) {
    try {
      if (el.closest("[aria-hidden=true], [hidden]")) return false;
    } catch {
    }
    const win = el.ownerDocument?.defaultView ?? window;
    const s = win.getComputedStyle(el);
    if (s.visibility === "hidden" || s.display === "none" || Number(s.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    return r.width > 1 && r.height > 1;
  }
  function collectRoots() {
    const list = [];
    let skipped = 0;
    const visitDoc = (doc, frame) => {
      list.push({ root: doc, frame });
      for (const el of Array.from(doc.querySelectorAll("*"))) {
        const sr = el.shadowRoot;
        if (sr) {
          list.push({ root: sr, frame });
          for (const f of Array.from(sr.querySelectorAll("iframe"))) {
            const cd = tryFrameDoc(f);
            if (cd) visitDoc(cd, frame ? `${frame}.${iframeIndex(f)}` : String(iframeIndex(f)));
            else skipped++;
          }
        }
      }
      let i = 0;
      for (const f of Array.from(doc.querySelectorAll("iframe"))) {
        const cd = tryFrameDoc(f);
        const path = frame ? `${frame}.${i}` : String(i);
        if (cd) visitDoc(cd, path);
        else skipped++;
        i++;
      }
    };
    visitDoc(document, "");
    return { list, skipped };
  }
  function tryFrameDoc(f) {
    try {
      return f.contentDocument ?? null;
    } catch {
      return null;
    }
  }
  function iframeIndex(f) {
    const parent = f.parentElement;
    if (!parent) return 0;
    return Array.prototype.indexOf.call(parent.querySelectorAll("iframe"), f);
  }
  function serializePage() {
    resetMap();
    const vw = innerWidth, vh = innerHeight;
    const sx = scrollX, sy = scrollY;
    const cx = vw / 2, cy = vh / 2;
    const { list: roots, skipped } = collectRoots();
    const scored = [];
    const seen = /* @__PURE__ */ new Set();
    for (const ctx of roots) {
      let candidates;
      try {
        candidates = Array.from(ctx.root.querySelectorAll(CANDIDATE_SELECTOR));
      } catch {
        continue;
      }
      for (const el of candidates) {
        if (seen.has(el)) continue;
        try {
          if (el.closest("[data-vicaro-overlay]")) continue;
          if (el.tagName === "INPUT" && el.type === "hidden") continue;
          if (el.getAttribute("tabindex") === "-1" && !/^(A|BUTTON|INPUT|SELECT|TEXTAREA)$/.test(el.tagName) && !el.hasAttribute("role") && !el.hasAttribute("onclick")) continue;
          if (!isVisible(el)) continue;
        } catch {
          continue;
        }
        const r = topRect(el);
        const inView = r.y + r.h > 0 && r.y < vh && r.x + r.w > 0 && r.x < vw;
        const ex = r.x + r.w / 2, ey = r.y + r.h / 2;
        const dist = inView ? Math.hypot(ex - cx, ey - cy) : Math.max(r.y - vh, r.x - vw, -r.y - r.h, -r.x - r.w, 0) + 1e4;
        const dx = Math.round((r.x + sx) / 4) * 4, dy = Math.round((r.y + sy) / 4) * 4;
        const dedupe = roleOf(el) + "|" + collapse(textOf(el)).slice(0, 40) + "|" + dx + "|" + dy + "|" + ctx.frame;
        seen.add(el);
        scored.push({ el, prox: dist, dedupe, frame: ctx.frame });
      }
    }
    const minProx = /* @__PURE__ */ new Map();
    for (const s of scored) minProx.set(s.dedupe, Math.min(minProx.get(s.dedupe) ?? Infinity, s.prox));
    const seenDedupe = /* @__PURE__ */ new Set();
    const kept = scored.filter((s) => {
      if (s.prox > (minProx.get(s.dedupe) ?? s.prox)) return false;
      if (seenDedupe.has(s.dedupe)) return false;
      seenDedupe.add(s.dedupe);
      return true;
    });
    kept.sort((a, b) => a.prox - b.prox);
    const capped = kept.slice(0, MAX_ELEMENTS);
    const elements = [];
    const rowIds = /* @__PURE__ */ new WeakMap();
    let rowSeq = 0;
    const rowFor = (el) => {
      try {
        return el.closest(ROW_SELECTOR);
      } catch {
        return null;
      }
    };
    const rowIdFor = (row) => {
      if (!row) return void 0;
      let id = rowIds.get(row);
      if (!id) {
        id = `r${++rowSeq}`;
        rowIds.set(row, id);
      }
      return id;
    };
    let hashAcc = 2166136261;
    const hashPush = (s) => {
      for (let i = 0; i < s.length; i++) {
        hashAcc ^= s.charCodeAt(i);
        hashAcc = Math.imul(hashAcc, 16777619) >>> 0;
      }
    };
    capped.forEach((s, idx) => {
      const el = s.el;
      const r = topRect(el);
      const role = roleOf(el);
      const text = collapse(textOf(el)).slice(0, 120);
      const i = el;
      const inViewport = r.y + r.h > 0 && r.y < vh && r.x + r.w > 0 && r.x < vw;
      const rect = { x: Math.round((r.x + sx) / 4) * 4, y: Math.round((r.y + sy) / 4) * 4, w: Math.round(r.w / 4) * 4, h: Math.round(r.h / 4) * 4 };
      let valueMasked = "";
      if (role === "textbox" || role === "combobox" || role === "searchbox") {
        valueMasked = isSensitive(el) ? "" : collapse(String(i.value ?? "")).slice(0, 40);
      }
      const hrefHost = el.tagName === "A" ? safeHost(el.href) : "";
      const row = rowFor(el);
      const rowId = rowIdFor(row);
      const context = row && row !== el ? collapse(accessibleName(row)).slice(0, 180) : void 0;
      const ariaChecked = el.getAttribute("aria-checked");
      const ariaSelected = el.getAttribute("aria-selected");
      const ariaExpanded = el.getAttribute("aria-expanded");
      const checked = i.type === "checkbox" || i.type === "radio" ? !!i.checked : ariaChecked !== null ? ariaChecked === "true" : void 0;
      const selected = ariaSelected !== null ? ariaSelected === "true" : void 0;
      const expanded = ariaExpanded !== null ? ariaExpanded === "true" : void 0;
      const disabled = !!(i.disabled || el.getAttribute("aria-disabled") === "true");
      elements.push({
        idx,
        role,
        tag: el.tagName.toLowerCase(),
        text,
        ariaLabel: accessibleName(el) || void 0,
        title: el.getAttribute("title") || void 0,
        placeholder: el.placeholder || void 0,
        valueMasked,
        hrefHost,
        inViewport,
        rect,
        inputType: el.tagName === "INPUT" ? i.type : void 0,
        sensitive: isSensitive(el),
        context: context || void 0,
        rowId,
        checked,
        selected,
        expanded,
        disabled,
        frame: s.frame || void 0
      });
      put(idx, el, { role, textPrefix: text.slice(0, 24), rect: { x: rect.x, y: rect.y } });
      hashPush(role + "|" + text.slice(0, 24) + "|" + rect.x + ":" + rect.y + "|" + s.frame);
    });
    const rowTop = /* @__PURE__ */ new Map();
    for (const e of elements) {
      if (!e.rowId) continue;
      const y = e.rect.y;
      rowTop.set(e.rowId, Math.min(rowTop.get(e.rowId) ?? Infinity, y));
    }
    const orderedRowIds = [...rowTop.entries()].sort((a, b) => a[1] - b[1]).map(([id]) => id);
    const renumber = new Map(orderedRowIds.map((id, i) => [id, `r${i + 1}`]));
    for (const e of elements) if (e.rowId) e.rowId = renumber.get(e.rowId) ?? e.rowId;
    const total = capped.length;
    return {
      url: location.href,
      title: collapse(document.title).slice(0, 100),
      readyState: document.readyState,
      elements,
      // Structural hash ONLY (roles + text-prefixes + document-relative rect buckets) —
      // stable across re-serializations of an unchanged page AND across scrolls; the idx
      // map epoch is deliberately NOT part of it.
      elementSetHash: hashAcc.toString(36),
      heuristicKind: heuristicKind(),
      lowElementCount: total < LOW_COUNT,
      highElementCount: total >= MAX_ELEMENTS || kept.length > HIGH_COUNT,
      scrollTop: Math.round(scrollY),
      viewport: { w: vw, h: vh },
      skippedFrames: skipped || void 0
    };
  }
  function heuristicKind() {
    const t = document.title.toLowerCase();
    if (/error|404|403|500/.test(t)) return "error";
    const authSignals = document.querySelectorAll("input[type=password], input[name*='user' i], input[id*='login' i], form[action*='login' i]").length;
    if (authSignals > 0 && /log ?in|sign ?in|register|account/.test(t + " " + location.pathname)) return "auth";
    if (document.querySelectorAll("form").length > 0) return "form";
    if (document.querySelectorAll("li,article,tr").length > 12) return "list";
    if (document.querySelectorAll("h1,h2").length <= 2 && (document.body?.innerText ?? "").length > 1500) return "detail";
    if ((document.body?.innerText ?? "").trim().length < 40) return "blank";
    return "other";
  }
  function safeHost(href) {
    try {
      return new URL(href).host;
    } catch {
      return "";
    }
  }

  // src/content/actions.ts
  async function executeDomAction(action) {
    switch (action.name) {
      case "click":
        return doClick(Number(action.args.idx));
      case "click_at":
        return doClickAt(Number(action.args.x), Number(action.args.y));
      case "mouse":
        return doMouseAt(
          Number(action.args.x),
          Number(action.args.y),
          String(action.args.button ?? "left"),
          Number(action.args.clicks) === 2 ? 2 : 1
        );
      case "hover":
        return doHover(Number(action.args.idx));
      case "type":
        return doType(Number(action.args.idx), String(action.args.text ?? ""), !!action.args.clear_first, !!action.args.verify);
      case "press":
        return doPress(String(action.args.key ?? ""), Array.isArray(action.args.modifiers) ? action.args.modifiers : []);
      case "select":
        return doSelect(Number(action.args.idx), String(action.args.value ?? ""));
      case "drag":
        return doDrag(Number(action.args.from_idx), Number(action.args.to_idx));
      case "scroll":
        return doScroll(String(action.args.direction), Number(action.args.amount) || 3, action.args.idx !== void 0 ? Number(action.args.idx) : void 0);
      case "submit":
        return doSubmit(action.args.idx !== void 0 ? Number(action.args.idx) : void 0);
      case "click_selector":
        return doClickSelector(String(action.args.selector ?? ""));
      case "type_selector":
        return doTypeSelector(String(action.args.selector ?? ""), String(action.args.text ?? ""), !!action.args.clear_first);
      case "wait_for":
        return await doWaitFor(action.args);
      case "clipboard":
        return await doClipboard(String(action.args.action), String(action.args.text ?? ""));
      case "back":
        return doBack();
      case "forward":
        return doForward();
      case "reload":
        return doReload();
      case "wait":
        return { ok: true, result: { waited: Number(action.args.ms) || 500 } };
      case "navigate":
        return { ok: false, error: "navigate is handled by the tabs API" };
      case "close_tab":
      case "reopen_tab":
      case "download":
      case "upload":
      case "evaluate":
        return { ok: false, error: `${action.name} requires the extension background (CDP/tabs), not the DOM executor` };
      default:
        return { ok: false, error: `unsupported DOM action ${action.name}` };
    }
  }
  async function doClick(idx) {
    const el = resolveValidated(idx);
    if (!el) return { ok: false, error: "element not found or changed since perception" };
    try {
      el.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    } catch {
    }
    let el2 = resolveValidated(idx);
    if (!el2) {
      await new Promise((r) => setTimeout(r, 120));
      el2 = resolveValidated(idx);
    }
    if (!el2) return { ok: false, error: "element changed during scroll - re-perceive and retry" };
    focusSafe(el2);
    const rect = el2.getBoundingClientRect();
    const opts = { bubbles: true, cancelable: true, view: el2.ownerDocument?.defaultView ?? window, clientX: rect.x + rect.width / 2, clientY: rect.y + rect.height / 2, button: 0 };
    try {
      if (el2.tagName === "INPUT" || el2.tagName === "BUTTON" || el2.tagName === "SELECT" || el2.tagName === "TEXTAREA" || el2.hasAttribute("role")) {
        el2.click();
      } else {
        el2.dispatchEvent(new MouseEvent("mousedown", opts));
        el2.dispatchEvent(new MouseEvent("mouseup", opts));
        el2.dispatchEvent(new MouseEvent("click", opts));
      }
      return { ok: true, result: { role: roleOf(el2), text: collapse(textOf(el2)).slice(0, 60) } };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  function doClickAt(x, y) {
    if (!Number.isFinite(x) || !Number.isFinite(y)) return { ok: false, error: "click_at needs numeric x,y" };
    try {
      const doc = document;
      const el = doc.elementFromPoint(x, y);
      if (!el) return { ok: false, error: `nothing at (${x}, ${y})` };
      const opts = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0 };
      el.dispatchEvent(new MouseEvent("mousedown", opts));
      el.dispatchEvent(new MouseEvent("mouseup", opts));
      el.dispatchEvent(new MouseEvent("click", opts));
      return { ok: true, result: { tag: el.tagName.toLowerCase(), text: collapse(textOf(el)).slice(0, 60) } };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  function doMouseAt(x, y, button, clicks) {
    if (!Number.isFinite(x) || !Number.isFinite(y)) return { ok: false, error: "mouse needs numeric x,y" };
    try {
      const el = document.elementFromPoint(x, y);
      if (!el) return { ok: false, error: `nothing at (${x}, ${y})` };
      const btn = button === "right" ? 2 : button === "middle" ? 1 : 0;
      const buttons = button === "right" ? 2 : button === "middle" ? 4 : 1;
      const opts = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: btn, buttons };
      for (let i = 1; i <= clicks; i++) {
        el.dispatchEvent(new MouseEvent("mousedown", { ...opts, detail: i }));
        if (button === "right" && i === 1) el.dispatchEvent(new MouseEvent("contextmenu", { ...opts, detail: i }));
        el.dispatchEvent(new MouseEvent("mouseup", { ...opts, detail: i }));
        el.dispatchEvent(new MouseEvent(button === "middle" ? "auxclick" : "click", { ...opts, detail: i }));
      }
      return { ok: true, result: { tag: el.tagName.toLowerCase(), button, clicks, text: collapse(textOf(el)).slice(0, 60) } };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  function doHover(idx) {
    const el = resolveValidated(idx);
    if (!el) return { ok: false, error: "element not found or changed since perception" };
    try {
      el.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    } catch {
    }
    const r = el.getBoundingClientRect();
    const opts = { bubbles: true, cancelable: true, view: el.ownerDocument?.defaultView ?? window, clientX: r.x + r.width / 2, clientY: r.y + r.height / 2 };
    try {
      for (const type of ["mouseover", "mouseenter", "mousemove", "pointerover", "pointerenter"]) {
        el.dispatchEvent(type.startsWith("pointer") ? new PointerEvent(type, opts) : new MouseEvent(type, opts));
      }
      return { ok: true, result: { role: roleOf(el), text: collapse(textOf(el)).slice(0, 60) } };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  function doPress(key, modifiers) {
    if (!key) return { ok: false, error: "press needs a key" };
    const target = document.activeElement ?? document.body;
    const info = keyInfo(key, modifiers);
    try {
      target.dispatchEvent(new KeyboardEvent("keydown", { key: info.key, code: info.code, bubbles: true, cancelable: true, ctrlKey: info.ctrl, metaKey: info.meta, shiftKey: info.shift, altKey: info.alt }));
      if (info.key.length === 1 && !info.ctrl && !info.meta && !info.alt) {
        if (target.isContentEditable) {
          document.execCommand("insertText", false, info.key);
        } else if (target.value !== void 0) {
          const input = target;
          const proto = input.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
          const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
          if (setter) setter.call(input, String(input.value ?? "") + info.key);
          else input.value += info.key;
          input.dispatchEvent(new InputEvent("input", { bubbles: true, data: info.key }));
        }
      }
      target.dispatchEvent(new KeyboardEvent("keyup", { key: info.key, code: info.code, bubbles: true, cancelable: true, ctrlKey: info.ctrl, metaKey: info.meta, shiftKey: info.shift, altKey: info.alt }));
      return { ok: true, result: { key: info.key, modifiers } };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  function doDrag(fromIdx, toIdx) {
    const from = resolveValidated(fromIdx);
    const to = resolveValidated(toIdx);
    if (!from) return { ok: false, error: `drag source #${fromIdx} not found or changed` };
    if (!to) return { ok: false, error: `drag target #${toIdx} not found or changed` };
    const a = from.getBoundingClientRect();
    const b = to.getBoundingClientRect();
    const ax = a.x + a.width / 2, ay = a.y + a.height / 2;
    const bx = b.x + b.width / 2, by = b.y + b.height / 2;
    const view = from.ownerDocument?.defaultView ?? window;
    const mk = (x, y) => ({ bubbles: true, cancelable: true, view, clientX: x, clientY: y, button: 0 });
    try {
      from.dispatchEvent(new MouseEvent("mousedown", mk(ax, ay)));
      for (let i = 1; i <= 5; i++) {
        const x = ax + (bx - ax) * i / 5, y = ay + (by - ay) * i / 5;
        const target = document.elementFromPoint(x, y) ?? to;
        target.dispatchEvent(new MouseEvent("mousemove", mk(x, y)));
        target.dispatchEvent(new DragEvent("dragover", mk(x, y)));
      }
      to.dispatchEvent(new MouseEvent("mouseup", mk(bx, by)));
      to.dispatchEvent(new DragEvent("drop", mk(bx, by)));
      return { ok: true, result: { from: fromIdx, to: toIdx } };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  function resolveSelector(selector) {
    const s = selector.trim();
    if (!s) return null;
    try {
      if (/^xpath:/i.test(s)) {
        const x = document.evaluate(s.replace(/^xpath:/i, ""), document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        return x.singleNodeValue ?? null;
      }
      return document.querySelector(s);
    } catch {
      return null;
    }
  }
  function doClickSelector(selector) {
    const el = resolveSelector(selector);
    if (!el) return { ok: false, error: `selector not found: ${selector.slice(0, 120)}` };
    try {
      el.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    } catch {
    }
    try {
      el.click();
      return { ok: true, result: { role: roleOf(el), text: collapse(textOf(el)).slice(0, 60) } };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  function doTypeSelector(selector, text, clearFirst) {
    const el = resolveSelector(selector);
    if (!el) return { ok: false, error: `selector not found: ${selector.slice(0, 120)}` };
    if (el.tagName !== "INPUT" && el.tagName !== "TEXTAREA" && !el.isContentEditable) {
      return { ok: false, error: "selector does not point at a text field" };
    }
    try {
      el.focus();
      const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      const next = clearFirst ? text : `${el.value ?? ""}${text}`;
      if (setter) setter.call(el, next);
      else el.value = next;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return { ok: true, result: { typed: text.length, valueMasked: "\u2022".repeat(Math.min(text.length, 12)) } };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  async function doWaitFor(args) {
    const text = typeof args?.text === "string" ? args.text : void 0;
    const gone = !!args?.gone;
    const urlContains = typeof args?.url_contains === "string" ? args.url_contains : void 0;
    const selector = typeof args?.selector === "string" ? args.selector : void 0;
    const needCount = Math.max(1, Number(args?.count) || 1);
    const urlStableMs = Math.min(Math.max(Number(args?.url_stable_ms) || 0, 0), 3e4);
    const domIdleMs = Math.min(Math.max(Number(args?.dom_idle_ms) || 0, 0), 3e4);
    const timeout = Math.min(Math.max(Number(args?.timeout_ms) || 1e4, 500), 6e4);
    const started = Date.now();
    let lastUrl = location.href;
    let urlSince = Date.now();
    let lastMutation = Date.now();
    const observer = domIdleMs ? new MutationObserver(() => {
      lastMutation = Date.now();
    }) : null;
    observer?.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
    try {
      for (; ; ) {
        let hit = true;
        if (text !== void 0) {
          const present = deepText(document, 4e5, true).toLowerCase().includes(text.toLowerCase());
          hit = gone ? !present : present;
        }
        if (hit && selector !== void 0) {
          let found = 0;
          try {
            found = document.querySelectorAll(selector).length;
          } catch {
            return { ok: false, error: `invalid selector: ${selector.slice(0, 80)}` };
          }
          hit = gone ? found === 0 : found >= needCount;
        }
        if (hit && urlContains !== void 0) hit = location.href.includes(urlContains);
        if (hit && urlStableMs > 0) {
          if (location.href !== lastUrl) {
            lastUrl = location.href;
            urlSince = Date.now();
            hit = false;
          } else hit = Date.now() - urlSince >= urlStableMs;
        }
        if (hit && domIdleMs > 0) hit = Date.now() - lastMutation >= domIdleMs;
        if (hit) return { ok: true, result: { matched: true, waitedMs: Date.now() - started, url: location.href } };
        if (Date.now() - started > timeout) {
          const what = text !== void 0 ? `text "${text.slice(0, 40)}"${gone ? " to disappear" : ""}` : selector !== void 0 ? `selector "${selector.slice(0, 60)}"${needCount > 1 ? ` \xD7${needCount}` : ""}${gone ? " to disappear" : ""}` : urlStableMs ? `url to stay stable for ${urlStableMs}ms` : domIdleMs ? `DOM to be idle for ${domIdleMs}ms` : urlContains ? `url containing "${urlContains}"` : "condition";
          return { ok: true, result: { matched: false, waitedMs: Date.now() - started, timeout, what, url: location.href } };
        }
        await new Promise((r) => setTimeout(r, 150));
      }
    } finally {
      observer?.disconnect();
    }
  }
  async function doClipboard(op, text) {
    try {
      if (op === "write") {
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.append(ta);
        ta.select();
        const ok = document.execCommand("copy");
        ta.remove();
        if (ok) return { ok: true, result: { copied: text.length } };
        try {
          await navigator.clipboard.writeText(text);
          return { ok: true, result: { copied: text.length, via: "clipboard-api" } };
        } catch (err) {
          return { ok: false, error: `clipboard write blocked: ${String(err?.message ?? err)}` };
        }
      }
      const value = await navigator.clipboard.readText();
      return { ok: true, result: { text: value.slice(0, 2e4), length: value.length } };
    } catch (err) {
      return { ok: false, error: `clipboard ${op} failed: ${String(err?.message ?? err)}` };
    }
  }
  function doType(idx, text, clearFirst, verifyOnly) {
    const el = resolveValidated(idx);
    if (!el) return { ok: false, error: "element not found or changed since perception" };
    const input = el;
    if (input.tagName !== "INPUT" && input.tagName !== "TEXTAREA" && !input.isContentEditable) {
      return { ok: false, error: "target is not a text field" };
    }
    if (verifyOnly) {
      const current = input.value ?? input.innerText ?? "";
      return { ok: true, result: { verified: current.includes(text) } };
    }
    focusSafe(el);
    try {
      if (input.isContentEditable) {
        if (clearFirst) input.innerText = "";
        input.innerText = (input.innerText ?? "") + text;
        input.dispatchEvent(new InputEvent("input", { bubbles: true, data: text }));
        return { ok: true, result: { via: "contenteditable" } };
      }
      const proto = input.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      const next = clearFirst ? text : String(input.value ?? "") + text;
      if (setter) setter.call(input, next);
      else input.value = next;
      input.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      return { ok: true, result: { via: "native-setter" } };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  function doSelect(idx, value) {
    const el = resolveValidated(idx);
    if (!el) return { ok: false, error: "element not found or changed since perception" };
    if (!(el instanceof HTMLSelectElement)) return { ok: false, error: "target is not a select element" };
    const options = Array.from(el.options);
    const norm = (s) => collapse(s).toLowerCase();
    const want = norm(value);
    const match = options.find((o) => o.value === value) ?? options.find((o) => norm(o.textContent ?? "") === want);
    if (!match) return { ok: false, error: `no option matches "${value.slice(0, 40)}"` };
    try {
      el.value = match.value;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return { ok: true, result: { selected: match.value } };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  function scrollableAtViewport() {
    const canScroll = (el) => {
      try {
        const s = getComputedStyle(el);
        const oy = s.overflowY;
        return (oy === "auto" || oy === "scroll" || oy === "overlay") && el.scrollHeight > el.clientHeight + 8 && el.clientHeight > 40;
      } catch {
        return false;
      }
    };
    try {
      let node = document.elementFromPoint(innerWidth / 2, innerHeight / 2);
      for (let el = node; el && el !== document.documentElement; el = el.parentElement) {
        if (canScroll(el)) return el;
      }
      const candidates = Array.from(document.querySelectorAll(
        '[role="main"], main, [role="grid"], [role="list"], [role="table"], [role="log"], [role="feed"]'
      )).filter((el) => {
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && r.bottom > 0 && r.top < innerHeight;
      });
      candidates.sort((a, b) => b.clientHeight * b.clientWidth - a.clientHeight * a.clientWidth);
      const known = candidates.find(canScroll);
      if (known) return known;
      const all = Array.from(document.querySelectorAll("div,section,main,article,ul,ol,[role]")).filter((el) => {
        const r = el.getBoundingClientRect();
        return r.width > 40 && r.height > 40 && r.bottom > 0 && r.top < innerHeight && canScroll(el);
      }).sort((a, b) => b.clientHeight * b.clientWidth - a.clientHeight * a.clientWidth);
      return all[0] ?? null;
    } catch {
      return null;
    }
  }
  function scrollWindow(direction, y) {
    const before = window.scrollY;
    if (direction === "top") window.scrollTo({ top: 0, behavior: "instant" });
    else if (direction === "bottom") window.scrollTo({ top: document.documentElement.scrollHeight, behavior: "instant" });
    else window.scrollBy({ top: direction === "up" ? -y : y, behavior: "instant" });
    return {
      ok: true,
      result: {
        via: "window",
        scrollTop: Math.round(window.scrollY),
        moved: Math.round(window.scrollY) !== Math.round(before)
      }
    };
  }
  function doScroll(direction, amount, idx) {
    if (!["up", "down", "top", "bottom"].includes(direction)) return { ok: false, error: `bad scroll direction "${direction}"` };
    const y = Math.min(Math.max(amount, 1), 20) * 300;
    try {
      if (idx !== void 0) {
        const el = resolveValidated(idx);
        if (!el) return { ok: false, error: `scroll container #${idx} not found or changed` };
        if (direction === "top") el.scrollTo({ top: 0, behavior: "instant" });
        else if (direction === "bottom") el.scrollTo({ top: el.scrollHeight, behavior: "instant" });
        else el.scrollBy({ top: direction === "up" ? -y : y, behavior: "instant" });
        return { ok: true, result: { via: "element", container: idx, scrollTop: Math.round(el.scrollTop) } };
      }
      const pane = scrollableAtViewport();
      if (pane) {
        const before = Math.round(pane.scrollTop);
        if (direction === "top") pane.scrollTo({ top: 0, behavior: "instant" });
        else if (direction === "bottom") pane.scrollTo({ top: pane.scrollHeight, behavior: "instant" });
        else pane.scrollBy({ top: direction === "up" ? -y : y, behavior: "instant" });
        return {
          ok: true,
          result: {
            via: "pane",
            tag: pane.tagName.toLowerCase(),
            role: pane.getAttribute("role") ?? void 0,
            scrollTop: Math.round(pane.scrollTop),
            scrollHeight: pane.scrollHeight,
            clientHeight: pane.clientHeight,
            moved: Math.round(pane.scrollTop) !== before
          }
        };
      }
      return scrollWindow(direction, y);
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  function doSubmit(idx) {
    let target = null;
    if (idx !== void 0) target = resolveValidated(idx);
    if (!target) {
      const active2 = document.activeElement;
      target = active2 ?? document.querySelector("form input, form textarea, form button");
    }
    if (!target) return { ok: false, error: "no form target found" };
    const form = target.form ?? target.closest("form");
    try {
      if (form) {
        const submitter = form.querySelector("button[type=submit], input[type=submit], button:not([type])");
        if (submitter) {
          submitter.click();
          return { ok: true, result: { via: "submit-button" } };
        }
        if (typeof form.requestSubmit === "function") {
          form.requestSubmit();
          return { ok: true, result: { via: "requestSubmit" } };
        }
        form.submit();
        return { ok: true, result: { via: "form.submit", warning: "bypassed validation" } };
      }
      target.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true }));
      target.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", code: "Enter", bubbles: true }));
      return { ok: true, result: { via: "enter" } };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  function doBack() {
    try {
      history.back();
      return { ok: true, result: { via: "history" } };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  function doForward() {
    try {
      history.forward();
      return { ok: true, result: { via: "history" } };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  function doReload() {
    try {
      location.reload();
      return { ok: true, result: { via: "location" } };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  function focusSafe(el) {
    try {
      el.focus({ preventScroll: true });
    } catch {
    }
  }
  function keyInfo(rawKey, modifiers = []) {
    const named = {
      enter: { key: "Enter", code: "Enter" },
      tab: { key: "Tab", code: "Tab" },
      escape: { key: "Escape", code: "Escape" },
      esc: { key: "Escape", code: "Escape" },
      backspace: { key: "Backspace", code: "Backspace" },
      delete: { key: "Delete", code: "Delete" },
      space: { key: " ", code: "Space" },
      arrowup: { key: "ArrowUp", code: "ArrowUp" },
      up: { key: "ArrowUp", code: "ArrowUp" },
      arrowdown: { key: "ArrowDown", code: "ArrowDown" },
      down: { key: "ArrowDown", code: "ArrowDown" },
      arrowleft: { key: "ArrowLeft", code: "ArrowLeft" },
      left: { key: "ArrowLeft", code: "ArrowLeft" },
      arrowright: { key: "ArrowRight", code: "ArrowRight" },
      right: { key: "ArrowRight", code: "ArrowRight" },
      home: { key: "Home", code: "Home" },
      end: { key: "End", code: "End" },
      pageup: { key: "PageUp", code: "PageUp" },
      pagedown: { key: "PageDown", code: "PageDown" }
    };
    const hit = named[rawKey.toLowerCase()];
    const key = hit ? hit.key : rawKey;
    const code = hit ? hit.code : /^[a-zA-Z]$/.test(rawKey) ? `Key${rawKey.toUpperCase()}` : /^[0-9]$/.test(rawKey) ? `Digit${rawKey}` : rawKey;
    return {
      key,
      code,
      ctrl: modifiers.includes("ctrl"),
      meta: modifiers.includes("meta"),
      shift: modifiers.includes("shift"),
      alt: modifiers.includes("alt")
    };
  }

  // src/content/highlight.ts
  var active = null;
  function highlight(idx) {
    const el = resolveValidated(idx);
    if (!el) return false;
    try {
      el.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    } catch {
    }
    const rect = el.getBoundingClientRect();
    clear();
    const box = document.createElement("div");
    box.setAttribute("data-vicaro-overlay", "true");
    box.style.cssText = [
      "position:fixed",
      `left:${Math.max(0, rect.x - 4)}px`,
      `top:${Math.max(0, rect.y - 4)}px`,
      `width:${rect.width + 8}px`,
      `height:${rect.height + 8}px`,
      "border:3px solid #f59e0b",
      "border-radius:6px",
      "background:rgba(245,158,11,0.15)",
      "pointer-events:none",
      "z-index:2147483646",
      "transition:opacity 200ms ease"
    ].join(";");
    document.documentElement.appendChild(box);
    const timer = window.setTimeout(clear, 2600);
    active = { box, timer };
    return true;
    function clear() {
      if (!active) return;
      window.clearTimeout(active.timer);
      active.box.remove();
      active = null;
    }
  }

  // src/content/main.ts
  var rowKeys = /* @__PURE__ */ new WeakMap();
  var rowIndexes = /* @__PURE__ */ new WeakMap();
  var rowElements = /* @__PURE__ */ new Map();
  var rowKeySeq = 0;
  function rowKeyFor(row) {
    let id = rowKeys.get(row);
    if (!id) {
      id = `r${++rowKeySeq}`;
      rowKeys.set(row, id);
      rowElements.set(id, row);
    }
    return id;
  }
  function rowCheckbox(row) {
    try {
      return row.querySelector("input[type=checkbox],input[type=radio],[role=checkbox],[role=radio]");
    } catch {
      return null;
    }
  }
  function checkboxState(box) {
    if (!box) return void 0;
    if (box instanceof HTMLInputElement) return box.checked;
    const aria = box.getAttribute("aria-checked");
    if (aria !== null) return aria === "true";
    const selected = box.getAttribute("aria-selected");
    if (selected !== null) return selected === "true";
    return void 0;
  }
  function clickElement(box) {
    try {
      box.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    } catch {
    }
    try {
      box.focus({ preventScroll: true });
    } catch {
    }
    try {
      if (box.tagName === "INPUT") box.click();
      else box.click();
    } catch {
      const r = box.getBoundingClientRect();
      const opts = { bubbles: true, cancelable: true, view: window, clientX: r.x + r.width / 2, clientY: r.y + r.height / 2, button: 0 };
      box.dispatchEvent(new MouseEvent("mousedown", opts));
      box.dispatchEvent(new MouseEvent("mouseup", opts));
      box.dispatchEvent(new MouseEvent("click", opts));
    }
  }
  async function toggleRow(rowId, selected, expectedText) {
    const row = rowElements.get(rowId);
    if (!row || !row.isConnected) {
      rowElements.delete(rowId);
      return { ok: false, error: "row changed or is no longer rendered - call rows_list again" };
    }
    if (expectedText) {
      const now = collapse(cleanText(row, 700)).toLowerCase();
      const want = collapse(expectedText).toLowerCase();
      if (now !== want) {
        return { ok: false, error: "row changed or was recycled for a different item - call rows_list again" };
      }
    }
    try {
      row.scrollIntoView({ block: "center", inline: "nearest", behavior: "instant" });
    } catch {
    }
    const box = rowCheckbox(row);
    if (!box) return { ok: false, error: "row has no checkbox/radio" };
    const before = checkboxState(box);
    if (before !== selected) {
      clickElement(box);
      await new Promise((r) => setTimeout(r, 90));
      let after2 = checkboxState(box);
      if (after2 !== selected) {
        const r = box.getBoundingClientRect();
        const opts = { bubbles: true, cancelable: true, view: window, clientX: r.x + r.width / 2, clientY: r.y + r.height / 2, button: 0 };
        box.dispatchEvent(new PointerEvent("pointerdown", opts));
        box.dispatchEvent(new MouseEvent("mousedown", opts));
        box.dispatchEvent(new PointerEvent("pointerup", opts));
        box.dispatchEvent(new MouseEvent("mouseup", opts));
        box.dispatchEvent(new MouseEvent("click", opts));
        await new Promise((r2) => setTimeout(r2, 90));
        after2 = checkboxState(box);
      }
      if (after2 !== selected) {
        return { ok: false, error: `checkbox did not change after click (currently ${String(after2)})` };
      }
    }
    const after = checkboxState(box);
    return {
      ok: true,
      row: {
        rowId,
        index: rowIndexes.get(row) ?? 0,
        text: cleanText(row, 700),
        checked: after === true,
        hasCheckbox: true
      },
      scrollTop: Math.round(window.scrollY)
    };
  }
  var installedKey = "__vicaroContentInstalled";
  if (!globalThis[installedKey]) {
    let controlName = function(el) {
      const html = el;
      const input = el;
      return collapse(
        el.getAttribute("aria-label") || el.getAttribute("title") || (el.tagName === "INPUT" ? input.value || input.getAttribute("placeholder") : "") || html.innerText || el.textContent || ""
      ).trim();
    }, controlRole = function(el) {
      return (el.getAttribute("role") || (el.tagName === "A" ? "link" : el.tagName.toLowerCase())).toLowerCase();
    }, controlContext = function(el) {
      const row = el.closest('[role="row"],tr,[role="listitem"],[role="toolbar"],[role="navigation"],nav,header,footer');
      return row ? collapse(row.innerText || row.textContent || "").slice(0, 300) : "";
    }, clickNamedControl = function(name, role, within) {
      const q = collapse(name).toLowerCase().trim();
      if (!q) return { ok: false, error: "name is required" };
      const selector = "button,a,input[type=button],input[type=submit],[role=button],[role=link],[role=menuitem],[role=tab],[aria-label],[title]";
      const seen = /* @__PURE__ */ new Set();
      const pool = [];
      for (const el of Array.from(document.querySelectorAll(selector))) {
        if (!(el instanceof HTMLElement) || seen.has(el)) continue;
        seen.add(el);
        if (el.getAttribute("aria-hidden") === "true") continue;
        const r = el.getBoundingClientRect();
        if (r.width <= 0 && r.height <= 0) continue;
        const rl = controlRole(el);
        if (role && rl !== String(role).toLowerCase()) continue;
        if (within && !controlContext(el).toLowerCase().includes(String(within).toLowerCase())) continue;
        const n = controlName(el);
        if (!n) continue;
        pool.push({ el, name: collapse(n).toLowerCase(), role: rl });
      }
      let matches = pool.filter((c) => c.name === q);
      if (!matches.length) {
        const partial = pool.filter((c) => c.name.includes(q));
        if (partial.length > 1) {
          return { ok: false, error: `"${name}" is ambiguous in the full DOM`, candidates: partial.slice(0, 8).map((c) => `${c.role}: ${c.name}`) };
        }
        matches = partial;
      }
      if (matches.length > 1) {
        const visible = matches.filter((c) => {
          const r = c.el.getBoundingClientRect();
          return r.top < innerHeight && r.bottom > 0 && r.left < innerWidth && r.right > 0;
        });
        if (visible.length === 1) matches = visible;
        else return { ok: false, error: `"${name}" is ambiguous in the full DOM`, candidates: matches.slice(0, 8).map((c) => `${c.role}: ${c.name}`) };
      }
      const hit = matches[0];
      if (!hit) return { ok: false, error: `No control matches "${name}" in the full DOM` };
      clickElement(hit.el);
      return { ok: true, text: controlName(hit.el).slice(0, 160), role: hit.role, tag: hit.el.tagName.toLowerCase() };
    };
    controlName2 = controlName, controlRole2 = controlRole, controlContext2 = controlContext, clickNamedControl2 = clickNamedControl;
    globalThis[installedKey] = true;
    let domVersion = 0;
    try {
      const observer = new MutationObserver(() => {
        domVersion++;
      });
      observer.observe(document.documentElement, { subtree: true, childList: true, attributes: true });
    } catch {
    }
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (msg?.type === "vicaro.ping") {
        sendResponse({ ok: true, domVersion, url: location.href });
        return true;
      }
      if (msg?.type === "vicaro.perceive") {
        void (async () => {
          try {
            if (msg.settle !== false) await settle();
            const artifact = serializePage();
            artifact.domVersion = domVersion;
            sendResponse({ ok: true, artifact });
          } catch (err) {
            sendResponse({ ok: false, error: String(err?.message ?? err) });
          }
        })();
        return true;
      }
      if (msg?.type === "vicaro.resolve") {
        const idx = Number(msg.idx);
        let el = resolveValidated(idx);
        if (!el) {
          sendResponse({ ok: false, error: "element not found or changed since perception" });
          return true;
        }
        try {
          el.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
        } catch {
        }
        let r = topRect(el);
        if (r.y + r.h < 0 || r.y > innerHeight || r.x + r.w < 0 || r.x > innerWidth) {
          try {
            window.scrollBy({ top: Math.round(r.y - Math.max(0, (innerHeight - r.h) / 2)), behavior: "instant" });
          } catch {
          }
        }
        el = resolveValidated(idx);
        if (!el) {
          sendResponse({ ok: false, error: "element changed during scroll - re-perceive and retry" });
          return true;
        }
        r = topRect(el);
        const inViewport = r.y + r.h > 0 && r.y < innerHeight && r.x + r.w > 0 && r.x < innerWidth;
        const sensitive = isSensitive(el);
        sendResponse({
          ok: true,
          rect: { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.w), h: Math.round(r.h) },
          role: roleOf(el),
          text: collapse(textOf(el)).slice(0, 120),
          sensitive,
          inViewport,
          inputType: el.tagName === "INPUT" ? el.type : void 0
        });
        return true;
      }
      if (msg?.type === "vicaro.execute-action") {
        void executeDomAction(msg.action).then((res) => sendResponse(res)).catch((err) => sendResponse({ ok: false, error: String(err?.message ?? err) }));
        return true;
      }
      if (msg?.type === "vicaro.highlight") {
        sendResponse({ ok: highlight(Number(msg.idx)) });
        return true;
      }
      if (msg?.type === "vicaro.mark") {
        const el = resolveValidated(Number(msg.idx));
        if (!el) {
          sendResponse({ ok: false, error: "element not found or changed" });
          return true;
        }
        const marker = `m${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
        try {
          el.setAttribute("data-cu-mark", marker);
        } catch {
        }
        sendResponse({ ok: true, marker });
        return true;
      }
      if (msg?.type === "vicaro.unmark") {
        try {
          const marker = String(msg.marker ?? "");
          for (const el of Array.from(document.querySelectorAll(`[data-cu-mark="${marker}"]`))) el.removeAttribute("data-cu-mark");
          sendResponse({ ok: true });
        } catch {
          sendResponse({ ok: false });
        }
        return true;
      }
      if (msg?.type === "vicaro.extract") {
        try {
          sendResponse(extractPageData(msg));
        } catch (err) {
          sendResponse({ ok: false, error: String(err?.message ?? err) });
        }
        return true;
      }
      if (msg?.type === "vicaro.row-action") {
        void (async () => {
          try {
            sendResponse(await toggleRow(String(msg.rowId ?? ""), msg.selected === true, msg.expectedText ? String(msg.expectedText) : void 0));
          } catch (err) {
            sendResponse({ ok: false, error: String(err?.message ?? err) });
          }
        })();
        return true;
      }
      if (msg?.type === "vicaro.click-named") {
        try {
          sendResponse(clickNamedControl(String(msg.name ?? ""), msg.role ? String(msg.role) : void 0, msg.within ? String(msg.within) : void 0));
        } catch (err) {
          sendResponse({ ok: false, error: String(err?.message ?? err) });
        }
        return true;
      }
      if (msg?.type === "vicaro.text") {
        try {
          const full = pageSectionText(String(msg.section ?? "full")).replace(/\n{3,}/g, "\n\n");
          const max = Math.min(Math.max(Number(msg.max) || 4e3, 500), 2e4);
          if (msg.query) {
            const q = String(msg.query);
            const lower = full.toLowerCase();
            const ql = q.toLowerCase();
            const matches = [];
            let at = 0;
            while (matches.length < 8) {
              const hit = lower.indexOf(ql, at);
              if (hit < 0) break;
              matches.push({ offset: hit, snippet: full.slice(Math.max(0, hit - 160), hit + q.length + 240).replace(/\s+/g, " ").trim() });
              at = hit + ql.length;
            }
            sendResponse({ ok: true, length: full.length, text: "", matches });
          } else {
            const offset = Math.min(Math.max(Number(msg.offset) || 0, 0), Math.max(0, full.length - 1));
            sendResponse({ ok: true, length: full.length, text: full.slice(offset, offset + max) });
          }
        } catch (err) {
          sendResponse({ ok: false, error: String(err?.message ?? err) });
        }
        return true;
      }
      if (msg?.type === "task-echo") {
        sendResponse({ ok: true, at: location.href });
        return true;
      }
      return false;
    });
  }
  var controlName2;
  var controlRole2;
  var controlContext2;
  var clickNamedControl2;
  var LANDMARKS = [
    ["main", "main, [role=main], article"],
    ["nav", "nav, [role=navigation]"],
    ["footer", "footer, [role=contentinfo]"],
    ["header", "header, [role=banner]"]
  ];
  function joinSectionText(selector) {
    return Array.from(document.querySelectorAll(selector)).map((el) => deepText(el)).filter(Boolean).join("\n\n");
  }
  function mainSectionText() {
    const candidates = Array.from(document.querySelectorAll("main, [role=main], article"));
    if (!candidates.length) return deepText(document.body ?? document.documentElement);
    const texts = candidates.map((el) => deepText(el));
    return texts.sort((a, b) => b.length - a.length)[0] ?? "";
  }
  function pageOutline() {
    const lines = [`url: ${location.href}`, `title: ${document.title}`];
    const desc = document.querySelector('meta[name="description"]')?.getAttribute("content");
    if (desc?.trim()) lines.push(`description: ${collapse(desc).slice(0, 300)}`);
    const headings = Array.from(document.querySelectorAll("h1, h2, h3")).slice(0, 40).map((h) => {
      const level = Number(h.tagName.slice(1)) || 1;
      const text = collapse(h.innerText || h.textContent || "");
      return text ? `${"#".repeat(level)} ${text.slice(0, 160)}` : "";
    }).filter(Boolean);
    if (headings.length) lines.push(`Headings:
${headings.join("\n")}`);
    const sections = LANDMARKS.map(([name, selector]) => {
      const els = Array.from(document.querySelectorAll(selector));
      if (!els.length) return "";
      const chars = els.reduce((n, el) => n + (el.innerText?.length ?? 0), 0);
      return `${name} ${els.length} (${chars} chars)`;
    }).filter(Boolean);
    if (sections.length) lines.push(`Sections: ${sections.join(" \xB7 ")}`);
    const bodyChars = (document.body?.innerText ?? "").length;
    lines.push(`Visible text: ${bodyChars} chars`);
    return lines.join("\n");
  }
  function pageSectionText(raw) {
    const scope = String(raw || "full").toLowerCase();
    switch (scope) {
      case "auto": {
        const main = mainSectionText();
        return main.trim().length >= 300 ? main : deepText(document);
      }
      case "main":
        return mainSectionText();
      case "nav":
        return joinSectionText("nav, [role=navigation]");
      case "footer":
        return joinSectionText("footer, [role=contentinfo]");
      case "header":
        return joinSectionText("header, [role=banner]");
      case "outline":
        return pageOutline();
      case "overview": {
        const outline = pageOutline();
        const main = mainSectionText();
        return `${outline}

Main content preview (${Math.min(main.length, 1500)} of ${main.length} chars):
${main.slice(0, 1500)}`;
      }
      default:
        return deepText(document);
    }
  }
  function cleanText(el, max = 500) {
    if (!el) return "";
    return collapse(el.innerText ?? el.textContent ?? "").slice(0, max);
  }
  function absoluteUrl(raw) {
    try {
      return new URL(raw, location.href).href;
    } catch {
      return raw;
    }
  }
  function extractNodes(selector) {
    if (!selector) return [document.body ?? document.documentElement];
    try {
      return Array.from(document.querySelectorAll(selector));
    } catch {
      return [];
    }
  }
  function extractLinks(opts, limit) {
    const roots = extractNodes(opts.selector);
    const seen = /* @__PURE__ */ new Set();
    const rows = [];
    let total = 0;
    for (const root of roots) {
      for (const node of Array.from(root.querySelectorAll("a[href]"))) {
        const raw = node.getAttribute("href") ?? "";
        if (!raw || raw === "#" || /^javascript:/i.test(raw)) continue;
        const href = absoluteUrl(raw);
        if (seen.has(href)) continue;
        const text = cleanText(node, 200) || node.getAttribute("aria-label") || node.getAttribute("title") || "";
        if (!text) continue;
        seen.add(href);
        total++;
        if (rows.length >= limit) continue;
        const title = node.getAttribute("title") ?? void 0;
        rows.push({ text, href, ...title ? { title: title.slice(0, 160) } : {} });
      }
    }
    return { data: rows, count: total, truncated: total > rows.length };
  }
  function extractFields(opts, limit) {
    if (!opts.selector) return { error: "mode fields needs a selector for the item containers" };
    if (!opts.fields || !Object.keys(opts.fields).length) return { error: "mode fields needs a fields map" };
    const containers = extractNodes(opts.selector);
    if (!containers.length) return { error: `selector "${opts.selector}" matched no elements` };
    const rows = containers.slice(0, limit).map((container) => {
      const row = {};
      for (const [name, spec] of Object.entries(opts.fields)) {
        const at = spec.lastIndexOf("@");
        const selector = at > 0 ? spec.slice(0, at) : spec;
        const attr = at > 0 ? spec.slice(at + 1) : "";
        let target = container;
        if (selector && selector !== ":scope") {
          try {
            target = container.querySelector(selector);
          } catch {
            target = null;
          }
        }
        if (!target) {
          row[name] = "";
          continue;
        }
        if (attr && !["text", "innerText", "textContent"].includes(attr)) {
          const value = target.getAttribute(attr) ?? "";
          row[name] = /^(href|src|action)$/i.test(attr) ? absoluteUrl(value) : value.slice(0, 500);
        } else {
          row[name] = cleanText(target, 500);
        }
      }
      return row;
    });
    return { data: rows, count: containers.length, truncated: containers.length > rows.length };
  }
  function rowVisible(row) {
    const el = row;
    if (el.getAttribute("aria-hidden") === "true") return false;
    const check = el.checkVisibility;
    if (typeof check === "function") {
      try {
        if (!check.call(el, { checkOpacity: true, checkVisibilityCSS: true })) return false;
      } catch {
      }
    }
    try {
      const cs = getComputedStyle(el);
      if (cs.display === "none" || cs.visibility === "hidden" || cs.opacity === "0") return false;
    } catch {
    }
    return true;
  }
  function extractRows(opts, limit) {
    const roots = extractNodes(opts.selector);
    const seen = /* @__PURE__ */ new Set();
    const rows = [];
    let total = 0;
    for (const root of roots) {
      for (const row of Array.from(root.querySelectorAll("tr,[role=row],[role=listitem],[role=option],[role=treeitem]"))) {
        if (seen.has(row)) continue;
        seen.add(row);
        if (!rowVisible(row)) continue;
        const text = cleanText(row, 700);
        if (!text) continue;
        const box = rowCheckbox(row);
        if (!box && opts.include_without_checkbox !== true) continue;
        const checked = checkboxState(box) === true;
        total++;
        if (rows.length >= limit) continue;
        const rowId = rowKeyFor(row);
        rowIndexes.set(row, total);
        const selected = row.getAttribute("aria-selected") === "true" || box?.getAttribute("aria-selected") === "true";
        rows.push({
          index: total,
          rowId,
          text,
          checked,
          hasCheckbox: !!box,
          ...selected !== (checked === true) ? { selected } : {}
        });
      }
    }
    const main = document.querySelector('[role="main"]') ?? document.body;
    const mainText = (main?.innerText ?? "").toLowerCase();
    const noResults = /no messages matched your search|no results found|nothing (?:was )?found|0 results/.test(mainText);
    return {
      data: noResults ? [] : rows,
      count: noResults ? 0 : total,
      truncated: !noResults && total > rows.length,
      ...noResults ? { noResults: true, staleCount: total } : {}
    };
  }
  function extractTable(opts, limit) {
    let tables = [];
    if (opts.selector) {
      const nodes = extractNodes(opts.selector);
      for (const n of nodes) {
        if (n.tagName === "TABLE") tables.push(n);
        tables.push(...Array.from(n.querySelectorAll("table")));
      }
    } else {
      tables = Array.from(document.querySelectorAll("table"));
    }
    if (!tables.length) return { error: opts.selector ? `no table under "${opts.selector}"` : "no table on this page" };
    tables.sort((a, b) => b.querySelectorAll("tr").length - a.querySelectorAll("tr").length);
    const trs = Array.from(tables[0].querySelectorAll("tr"));
    const headerCells = trs[0] ? Array.from(trs[0].querySelectorAll("th,td")) : [];
    const hasHeader = headerCells.some((c) => c.tagName === "TH");
    const headers = hasHeader ? headerCells.map((c) => cleanText(c, 120)) : [];
    const bodyRows = trs.slice(hasHeader ? 1 : 0);
    const rows = bodyRows.slice(0, limit).map(
      (tr) => Array.from(tr.querySelectorAll("th,td")).map((c) => cleanText(c, 500))
    );
    return {
      data: { headers, rows },
      count: bodyRows.length,
      truncated: bodyRows.length > rows.length
    };
  }
  function extractJsonLd(limit) {
    const nodes = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
    const data = [];
    for (const node of nodes.slice(0, limit)) {
      try {
        data.push(JSON.parse(node.textContent ?? ""));
      } catch {
      }
    }
    return { data, count: nodes.length, truncated: nodes.length > data.length };
  }
  function extractMetadata() {
    const meta = (selector) => document.querySelector(selector)?.getAttribute("content") ?? void 0;
    const collect = (prefix) => {
      const out = {};
      for (const el of Array.from(document.querySelectorAll(`meta[property^="${prefix}"], meta[name^="${prefix}"]`))) {
        const key = (el.getAttribute("property") ?? el.getAttribute("name") ?? "").slice(prefix.length);
        const value = el.getAttribute("content");
        if (key && value) out[key] = value.slice(0, 500);
      }
      return out;
    };
    return {
      data: {
        url: location.href,
        title: document.title,
        description: meta('meta[name="description"]'),
        canonical: document.querySelector('link[rel="canonical"]')?.getAttribute("href") ?? void 0,
        lang: document.documentElement.lang || void 0,
        og: collect("og:"),
        twitter: collect("twitter:")
      },
      count: 1,
      truncated: false
    };
  }
  function extractPageData(opts) {
    const limit = Math.min(Math.max(Number(opts.limit) || 50, 1), 200);
    const mode = String(opts.mode || "links").toLowerCase();
    try {
      if (mode === "links") return { ok: true, mode, ...extractLinks(opts, limit) };
      if (mode === "rows") return { ok: true, mode, ...extractRows(opts, limit) };
      if (mode === "fields") return { ok: true, mode, ...extractFields(opts, limit) };
      if (mode === "table") return { ok: true, mode, ...extractTable(opts, limit) };
      if (mode === "jsonld") return { ok: true, mode, ...extractJsonLd(limit) };
      if (mode === "metadata") return { ok: true, mode, ...extractMetadata() };
      return { ok: false, error: `unknown extract mode "${mode}"` };
    } catch (err) {
      return { ok: false, error: String(err?.message ?? err) };
    }
  }
  function settle(maxMs = 2500) {
    return new Promise((resolve) => {
      const started = Date.now();
      let lastMutation = Date.now();
      const observer = new MutationObserver(() => {
        lastMutation = Date.now();
      });
      try {
        observer.observe(document.documentElement, { subtree: true, childList: true });
      } catch {
      }
      const tick = () => {
        const ready = document.readyState === "complete";
        const quiet = Date.now() - lastMutation > 150;
        if (ready && quiet || Date.now() - started > maxMs) {
          observer.disconnect();
          resolve();
          return;
        }
        setTimeout(tick, 60);
      };
      tick();
    });
  }
})();
