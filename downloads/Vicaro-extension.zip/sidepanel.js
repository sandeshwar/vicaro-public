"use strict";
(() => {
  // ../schema/dist/wire.js
  function makeFrame(seq, id, type, payload, inReplyTo) {
    return { seq, id, inReplyTo, ts: Date.now(), type, payload };
  }

  // ../schema/dist/action.js
  var ACTION_NAMES = [
    // navigation / tabs
    "navigate",
    "open_tab",
    "switch_tab",
    "close_tab",
    "reopen_tab",
    "back",
    "forward",
    "reload",
    // element interaction
    "click",
    "click_at",
    "click_selector",
    "mouse",
    "hover",
    "type",
    "type_selector",
    "press",
    "select",
    "submit",
    "drag",
    "upload",
    // page / clipboard / files
    "scroll",
    "wait",
    "wait_for",
    "clipboard",
    "download",
    "evaluate",
    // control
    "done",
    "ask_user"
  ];
  var ACTION_JSON_SCHEMA = {
    type: "object",
    additionalProperties: false,
    required: ["name", "args"],
    properties: {
      name: { enum: [...ACTION_NAMES] },
      args: {
        type: "object",
        additionalProperties: false,
        properties: {
          url: { type: "string" },
          tab_id: { type: "integer", minimum: 0 },
          idx: { type: "integer", minimum: 0 },
          x: { type: "integer", minimum: 0 },
          y: { type: "integer", minimum: 0 },
          key: { type: "string", maxLength: 32 },
          modifiers: { type: "array", items: { enum: ["alt", "ctrl", "meta", "shift"] }, maxItems: 4 },
          from_idx: { type: "integer", minimum: 0 },
          to_idx: { type: "integer", minimum: 0 },
          files: { type: "array", items: { type: "string", maxLength: 512 }, maxItems: 16 },
          text: { type: "string", maxLength: 2e3 },
          value: { type: "string", maxLength: 500 },
          clear_first: { type: "boolean" },
          direction: { enum: ["down", "up", "top", "bottom"] },
          amount: { type: "integer", minimum: 1, maximum: 20 },
          ms: { type: "integer", minimum: 100, maximum: 1e4 },
          gone: { type: "boolean" },
          url_contains: { type: "string", maxLength: 200 },
          timeout_ms: { type: "integer", minimum: 500, maximum: 6e4 },
          selector: { type: "string", maxLength: 300 },
          count: { type: "integer", minimum: 1, maximum: 1e4 },
          url_stable_ms: { type: "integer", minimum: 100, maximum: 3e4 },
          dom_idle_ms: { type: "integer", minimum: 100, maximum: 3e4 },
          action: { enum: ["read", "write"] },
          code: { type: "string", maxLength: 4e3 },
          filename: { type: "string", maxLength: 200 },
          question: { type: "string", maxLength: 300 },
          kind: { enum: ["login", "captcha", "confirm", "choice"] },
          choices: { type: "array", items: { type: "string", maxLength: 120 }, maxItems: 6 },
          element_idx: { type: "integer", minimum: 0 },
          result: { type: "object" }
        }
      },
      reason: { type: "string", maxLength: 400 },
      step_id: { type: "string", maxLength: 32 }
    }
  };

  // src/shared/settings.ts
  var DEFAULT_URL = "ws://127.0.0.1:8790/chrome";
  var KEY = "vicaro.settings";
  var DEFAULTS = { orchestratorUrl: DEFAULT_URL, theme: "auto" };
  async function getSettings() {
    const bag = await chrome.storage.local.get(KEY);
    if (bag[KEY]) return { ...DEFAULTS, ...bag[KEY] };
    return { ...DEFAULTS };
  }
  async function setSettings(patch) {
    const cur = await getSettings();
    const next = { ...cur, ...patch };
    await chrome.storage.local.set({ [KEY]: next });
    return next;
  }

  // src/background/ws-client.ts
  var resumeKey = (role) => `vicaro.resumeToken.${role}`;
  var WS_STATE_KEY = "vicaro.wsState";
  var WsClient = class {
    constructor(opts) {
      this.opts = opts;
    }
    ws;
    seq = 0;
    backoff = 1e3;
    closed = false;
    connecting = false;
    pending = /* @__PURE__ */ new Map();
    connected = false;
    /** Resume token held in memory for THIS client instance. Bridge persists it in
     *  chrome.storage (one SW); side panels deliberately do not: every panel/window
     *  must own an independent session or they supersede each other in a loop. */
    resumeToken;
    get isOpen() {
      return this.connected && this.ws?.readyState === WebSocket.OPEN;
    }
    async connect() {
      if (this.connecting) return;
      if (this.isOpen) return;
      if (this.ws && this.ws.readyState === WebSocket.CONNECTING) return;
      this.connecting = true;
      try {
        await this.doConnect();
      } finally {
        this.connecting = false;
      }
    }
    async doConnect() {
      if (this.closed) return;
      this.closed = false;
      const settings = await getSettings();
      if (this.closed) return;
      let windowIds;
      try {
        const wins = await chrome.windows.getAll({ populate: false });
        windowIds = wins.map((w) => w.id).filter((id) => Number.isInteger(id));
      } catch {
      }
      if (this.closed) return;
      const url = settings.orchestratorUrl || "ws://127.0.0.1:8790/chrome";
      const persistResume = this.opts.role === "bridge";
      const RESUME_KEY = resumeKey(this.opts.role);
      if (persistResume && !this.resumeToken) {
        const tokenBag = await chrome.storage.local.get(RESUME_KEY);
        this.resumeToken = tokenBag[RESUME_KEY];
      }
      const resumeToken = this.resumeToken;
      this.opts.onState?.("connecting");
      await chrome.storage.local.set({ [WS_STATE_KEY]: "connecting" }).catch(() => {
      });
      const wsUrl = settings.bearer ? `${url}?token=${encodeURIComponent(settings.bearer)}` : url;
      let ws;
      try {
        ws = new WebSocket(wsUrl);
      } catch {
        this.scheduleReconnect();
        return;
      }
      this.ws = ws;
      ws.onopen = () => {
        if (this.closed) {
          try {
            ws.close();
          } catch {
          }
          return;
        }
        if (this.ws !== ws) {
          try {
            ws.close();
          } catch {
          }
          return;
        }
        this.backoff = 1e3;
        this.connected = true;
        this.opts.onState?.("open");
        void chrome.storage.local.set({ [WS_STATE_KEY]: "open" }).catch(() => {
        });
        try {
          chrome.alarms.clear("vicaro-reconnect").catch(() => {
          });
        } catch {
        }
        const hello = makeFrame(++this.seq, crypto.randomUUID(), "hello", {
          role: this.opts.role,
          resumeToken,
          agentVersion: chrome.runtime.getManifest().version,
          windowIds
        });
        try {
          ws.send(JSON.stringify(hello));
        } catch {
        }
      };
      ws.onmessage = async (ev) => {
        if (this.ws !== ws) return;
        let frame;
        try {
          frame = JSON.parse(String(ev.data));
        } catch {
          return;
        }
        if (frame.type === "hello_ack") {
          const p = frame.payload ?? {};
          if (typeof p.resumeToken === "string") {
            this.resumeToken = p.resumeToken;
            if (persistResume) await chrome.storage.local.set({ [RESUME_KEY]: p.resumeToken }).catch(() => {
            });
          }
          if (p.resumed) await this.opts.onResume?.(p.resumeToken);
          return;
        }
        if (frame.inReplyTo && this.pending.has(frame.inReplyTo)) {
          const p = this.pending.get(frame.inReplyTo);
          clearTimeout(p.timer);
          this.pending.delete(frame.inReplyTo);
          p.resolve(frame);
          return;
        }
        await this.opts.onFrame(frame);
      };
      ws.onclose = (ev) => {
        if (this.ws !== ws) return;
        this.ws = void 0;
        this.connected = false;
        this.opts.onState?.("closed", { code: ev.code, reason: ev.reason });
        void chrome.storage.local.set({ [WS_STATE_KEY]: "closed" }).catch(() => {
        });
        for (const [id, p] of this.pending) {
          clearTimeout(p.timer);
          this.pending.delete(id);
          p.resolve(null);
        }
        if (this.closed) return;
        this.scheduleReconnect();
      };
      ws.onerror = () => {
      };
    }
    scheduleReconnect() {
      try {
        chrome.alarms.create("vicaro-reconnect", { delayInMinutes: Math.max(this.backoff / 6e4, 0.02) });
      } catch {
      }
      const wait = this.backoff;
      this.backoff = Math.min(this.backoff * 2, 3e4);
      setTimeout(() => {
        if (!this.closed) this.connect().catch(() => {
        });
      }, wait);
    }
    disconnect() {
      this.closed = true;
      try {
        this.ws?.close();
      } catch {
      }
    }
    /** Send a frame and await the correlated reply (null on timeout/close). */
    request(type, payload, timeoutMs = 1e4) {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return Promise.resolve(null);
      const frame = makeFrame(++this.seq, crypto.randomUUID(), type, payload);
      return new Promise((resolve) => {
        const timer = setTimeout(() => {
          this.pending.delete(frame.id);
          resolve(null);
        }, timeoutMs);
        this.pending.set(frame.id, { resolve, timer });
        try {
          this.ws.send(JSON.stringify(frame));
        } catch {
          clearTimeout(timer);
          this.pending.delete(frame.id);
          resolve(null);
        }
      });
    }
    /** Fire-and-forget frame. Returns false when the socket is down (caller may queue). */
    emit(type, payload, inReplyTo) {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return false;
      try {
        this.ws.send(JSON.stringify(makeFrame(++this.seq, crypto.randomUUID(), type, payload, inReplyTo)));
        return true;
      } catch {
        return false;
      }
    }
  };

  // src/sidepanel/format.ts
  function elapsed(from, to = Date.now()) {
    const s = Math.max(0, Math.floor((to - from) / 1e3));
    if (s < 60) return `${s}s`;
    const m = Math.floor(s / 60);
    const rs = s % 60;
    if (m < 60) return `${m}m ${rs}s`;
    const h = Math.floor(m / 60);
    return `${h}h ${m % 60}m`;
  }
  function elapsedCompact(from, to = Date.now()) {
    const s = Math.max(0, Math.floor((to - from) / 1e3));
    if (s < 60) return `${s}s`;
    const m = Math.floor(s / 60);
    if (m < 60) return `${m}m${String(s % 60).padStart(2, "0")}s`;
    const h = Math.floor(m / 60);
    return `${h}h${String(m % 60).padStart(2, "0")}m`;
  }
  function shortWhen(ts, now = Date.now()) {
    if (!Number.isFinite(ts) || ts <= 0) return "";
    const d = new Date(ts);
    const n = new Date(now);
    const startOfDay = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
    const time = d.toLocaleTimeString(void 0, { hour: "numeric", minute: "2-digit" });
    const today = startOfDay(n);
    if (ts >= today) return time;
    if (ts >= startOfDay(new Date(n.getFullYear(), n.getMonth(), n.getDate() - 1))) return time;
    if (ts >= startOfDay(new Date(n.getFullYear(), n.getMonth(), n.getDate() - 6))) {
      return `${d.toLocaleDateString(void 0, { weekday: "short" })} ${time}`;
    }
    const sameYear = d.getFullYear() === n.getFullYear();
    return d.toLocaleDateString(void 0, {
      month: "short",
      day: "numeric",
      ...sameYear ? {} : { year: "numeric" }
    });
  }
  function margin(v) {
    return v === null || v === void 0 ? "m -" : `m ${v.toFixed(2)}`;
  }
  function tps(v) {
    if (v === null || v === void 0 || !Number.isFinite(v) || v <= 0) return "-";
    if (v >= 1e3) return `${(v / 1e3).toFixed(1)}k`;
    if (v >= 100) return String(Math.round(v));
    return v.toFixed(1);
  }
  function percent(v) {
    if (v === null || v === void 0 || !Number.isFinite(v)) return "-";
    if (v > 0 && v < 10) return `${v.toFixed(1)}%`;
    return `${Math.round(v)}%`;
  }
  function tokenCount(v) {
    if (v === null || v === void 0 || !Number.isFinite(v) || v < 0) return "-";
    if (v >= 1e6) return `${(v / 1e6).toFixed(1)}m`;
    if (v >= 1e3) return `${(v / 1e3).toFixed(1)}k`;
    return String(Math.round(v));
  }
  function truncate(s, n) {
    return s.length > n ? s.slice(0, n - 1) + "\u2026" : s;
  }

  // src/sidepanel/markdown.ts
  var TABLE_PAGE_ROWS = 10;
  var activeRefs = /* @__PURE__ */ new Map();
  var activeFootnotes = /* @__PURE__ */ new Map();
  var footnoteOrder = [];
  var headingSlugs = /* @__PURE__ */ new Map();
  function renderMarkdown(text) {
    const frag = document.createDocumentFragment();
    const { body, refs, footnotes } = extractDefinitions(String(text ?? "").replace(/\r\n?/g, "\n"));
    activeRefs = refs;
    activeFootnotes = footnotes;
    footnoteOrder = [];
    headingSlugs = /* @__PURE__ */ new Map();
    const lines = body;
    const para = [];
    let i = 0;
    const flush = () => {
      if (!para.length) return;
      const p = document.createElement("p");
      appendInline(p, para.join(" "));
      frag.append(p);
      para.length = 0;
    };
    while (i < lines.length) {
      const line = lines[i];
      const fence = line.match(/^\s*```(\S*)\s*$/);
      if (fence) {
        flush();
        i++;
        const code = [];
        while (i < lines.length && !/^\s*```\s*$/.test(lines[i])) {
          code.push(lines[i]);
          i++;
        }
        if (i < lines.length) i++;
        const wrap = document.createElement("div");
        wrap.className = "code-block";
        const head = document.createElement("div");
        head.className = "code-head";
        head.append(document.createTextNode(fence[1] || "code"));
        const copy = document.createElement("button");
        copy.className = "code-copy";
        copy.type = "button";
        copy.textContent = "Copy";
        const raw = code.join("\n");
        copy.addEventListener("click", async () => {
          try {
            await navigator.clipboard.writeText(raw);
            copy.textContent = "Copied";
            setTimeout(() => copy.textContent = "Copy", 1400);
          } catch {
            copy.textContent = "Failed";
            setTimeout(() => copy.textContent = "Copy", 1400);
          }
        });
        head.append(copy);
        wrap.append(head);
        const pre = document.createElement("pre");
        const codeEl = document.createElement("code");
        if (fence[1]) codeEl.dataset.lang = fence[1];
        highlightCode(codeEl, fence[1] ?? "", raw);
        pre.append(codeEl);
        wrap.append(pre);
        frag.append(wrap);
        continue;
      }
      if (/^\s*\$\$\s*$/.test(line)) {
        flush();
        i++;
        const math = [];
        while (i < lines.length && !/^\s*\$\$\s*$/.test(lines[i])) {
          math.push(lines[i]);
          i++;
        }
        if (i < lines.length) i++;
        const block = document.createElement("div");
        block.className = "math-block";
        block.textContent = math.join("\n");
        frag.append(block);
        continue;
      }
      const heading = line.match(/^(#{1,6})\s+(.*)$/);
      if (heading) {
        flush();
        const level = heading[1].length;
        const h = document.createElement(`h${level}`);
        const label = heading[2];
        h.id = uniqueSlug(plainText(label));
        appendInline(h, label);
        frag.append(h);
        i++;
        continue;
      }
      if (/^\s*(?:-{3,}|\*{3,}|_{3,})\s*$/.test(line)) {
        flush();
        frag.append(document.createElement("hr"));
        i++;
        continue;
      }
      if (/^\s*>\s?/.test(line)) {
        flush();
        const quote = [];
        while (i < lines.length && /^\s*>\s?/.test(lines[i])) {
          quote.push(lines[i].replace(/^\s*>\s?/, ""));
          i++;
        }
        const bq = document.createElement("blockquote");
        appendInline(bq, quote.join(" "));
        frag.append(bq);
        continue;
      }
      if (line.trim() && i + 1 < lines.length && /^\s*:\s+/.test(lines[i + 1])) {
        flush();
        const dl = document.createElement("dl");
        while (i < lines.length && lines[i].trim()) {
          const term = lines[i].trim();
          if (!/^\s*:\s+/.test(lines[i + 1] ?? "")) {
            dl.append(termEl(term));
            i++;
            continue;
          }
          dl.append(termEl(term));
          i++;
          while (i < lines.length && /^\s*:\s+/.test(lines[i])) {
            const dd = document.createElement("dd");
            appendInline(dd, lines[i].replace(/^\s*:\s+/, ""));
            dl.append(dd);
            i++;
          }
        }
        frag.append(dl);
        continue;
      }
      if (/^\s*(?:[-*+]|\d+[.)])\s+/.test(line)) {
        flush();
        const items = [];
        while (i < lines.length && /^\s*(?:[-*+]|\d+[.)])\s+/.test(lines[i])) {
          const m = lines[i].match(/^(\s*)([-*+]|\d+[.)])\s+(.*)$/);
          if (!m) break;
          const ordered = /\d/.test(m[2]);
          const start = ordered ? Number(m[2].replace(/[.)]/, "")) : void 0;
          items.push({ indent: m[1].length, ordered, start, text: m[3] });
          i++;
        }
        frag.append(buildList(items));
        continue;
      }
      if (/^\s*\|/.test(line) && i + 1 < lines.length && /^\s*\|[\s:|-]+\|\s*$/.test(lines[i + 1])) {
        flush();
        const rows = [];
        while (i < lines.length && /^\s*\|/.test(lines[i])) {
          rows.push(lines[i]);
          i++;
        }
        const splitRow = (r) => r.trim().replace(/^\|/, "").replace(/\|$/, "").split("|");
        const aligns = splitRow(rows[1]).map((c) => {
          const t = c.trim();
          if (t.startsWith(":") && t.endsWith(":")) return "center";
          if (t.endsWith(":")) return "right";
          return "left";
        });
        const header = splitRow(rows[0]);
        const table = document.createElement("table");
        table.className = "md-table";
        const thead = document.createElement("thead");
        const hr = document.createElement("tr");
        header.forEach((c, idx) => {
          const th = document.createElement("th");
          th.style.textAlign = aligns[idx] ?? "left";
          appendInline(th, c.trim());
          hr.append(th);
        });
        thead.append(hr);
        table.append(thead);
        const tbody = document.createElement("tbody");
        const bodyRows = [];
        for (let r = 2; r < rows.length; r++) {
          const cells = splitRow(rows[r]);
          const tr = document.createElement("tr");
          for (let c = 0; c < header.length; c++) {
            const td = document.createElement("td");
            td.style.textAlign = aligns[c] ?? "left";
            appendInline(td, (cells[c] ?? "").trim());
            tr.append(td);
          }
          tbody.append(tr);
          bodyRows.push(tr);
        }
        table.append(tbody);
        const wrap = document.createElement("div");
        wrap.className = "md-table-wrap";
        const scroller = document.createElement("div");
        scroller.className = "md-table-scroll";
        scroller.append(table);
        wrap.append(scroller);
        if (bodyRows.length > TABLE_PAGE_ROWS) wrap.append(buildTablePager(bodyRows));
        frag.append(wrap);
        continue;
      }
      if (!line.trim()) {
        flush();
        i++;
        continue;
      }
      para.push(line);
      i++;
    }
    flush();
    if (footnoteOrder.length) frag.append(buildFootnotes());
    activeRefs = /* @__PURE__ */ new Map();
    activeFootnotes = /* @__PURE__ */ new Map();
    return frag;
  }
  var INLINE = /(!\[[^\]]*\]\([^)\s]+\)|!\[[^\]]*\]\[[^\]]*\]|\[[^\]]+\]\([^)\s]+\)|\[[^\]]+\]\[[^\]]*\]|\[\^[^\]]+\]|`[^`]+`|\*\*[^*]+\*\*|__[^_]+__|\*[^*\n]+\*|_[^_\n]+_|~~[^~]+~~|\\\([^)]*\\\)|https?:\/\/[^\s<]+)/g;
  function appendInline(parent, src) {
    const re = new RegExp(INLINE.source, "g");
    let last = 0;
    for (let m = re.exec(src); m; m = re.exec(src)) {
      if (m.index > last) parent.appendChild(document.createTextNode(src.slice(last, m.index)));
      const tok = m[0];
      if (tok.startsWith("![")) {
        const inline = tok.match(/^!\[([^\]]*)\]\(([^)\s]+)\)$/);
        const ref = tok.match(/^!\[([^\]]*)\]\[([^\]]*)\]$/);
        if (inline) appendImage(parent, inline[1], inline[2]);
        else if (ref) {
          const r = activeRefs.get((ref[2] || ref[1]).toLowerCase());
          if (r) appendImage(parent, ref[1], r.url, r.title);
          else parent.appendChild(document.createTextNode(tok));
        } else parent.appendChild(document.createTextNode(tok));
      } else if (tok.startsWith("`")) {
        const code = document.createElement("code");
        code.textContent = tok.slice(1, -1);
        parent.appendChild(code);
      } else if (tok.startsWith("**") || tok.startsWith("__")) {
        const strong = document.createElement("strong");
        appendInline(strong, tok.slice(2, -2));
        parent.appendChild(strong);
      } else if (tok.startsWith("~~")) {
        const del = document.createElement("del");
        del.textContent = tok.slice(2, -2);
        parent.appendChild(del);
      } else if (tok.startsWith("[^")) {
        appendFootnoteRef(parent, tok.slice(2, -1));
      } else if (tok.startsWith("[")) {
        const inline = tok.match(/^\[([^\]]+)\]\(([^)\s]+)\)$/);
        const ref = tok.match(/^\[([^\]]+)\]\[([^\]]*)\]$/);
        if (inline) appendLink(parent, inline[1], inline[2]);
        else if (ref) {
          const r = activeRefs.get((ref[2] || ref[1]).toLowerCase());
          if (r) appendLink(parent, ref[1], r.url, r.title);
          else parent.appendChild(document.createTextNode(tok));
        } else parent.appendChild(document.createTextNode(tok));
      } else if (/^https?:\/\//i.test(tok)) {
        appendLink(parent, tok, tok);
      } else if (tok.startsWith("\\(")) {
        const math = document.createElement("span");
        math.className = "math";
        math.textContent = tok.slice(2, -2);
        parent.appendChild(math);
      } else {
        const em = document.createElement("em");
        appendInline(em, tok.slice(1, -1));
        parent.appendChild(em);
      }
      last = m.index + tok.length;
    }
    if (last < src.length) parent.appendChild(document.createTextNode(src.slice(last)));
  }
  function appendLink(parent, label, url, title) {
    if (!/^(https?:|mailto:)/i.test(url)) {
      appendInline(parent, label);
      if (url) parent.appendChild(document.createTextNode(` (${url})`));
      return;
    }
    const a = document.createElement("a");
    a.href = url;
    a.target = "_blank";
    a.rel = "noreferrer noopener";
    if (title) a.title = title;
    if (/^https?:\/\//i.test(label)) a.textContent = label;
    else appendInline(a, label || url);
    parent.appendChild(a);
  }
  function appendImage(parent, alt, url, title) {
    if (!/^https?:/i.test(url)) {
      parent.appendChild(document.createTextNode(`![${alt}](${url})`));
      return;
    }
    const img = document.createElement("img");
    img.src = url;
    img.alt = alt;
    if (title) img.title = title;
    img.loading = "lazy";
    img.className = "md-image";
    parent.appendChild(img);
  }
  function appendFootnoteRef(parent, id) {
    if (!activeFootnotes.has(id)) {
      parent.appendChild(document.createTextNode(`[^${id}]`));
      return;
    }
    if (!footnoteOrder.includes(id)) footnoteOrder.push(id);
    const n = footnoteOrder.indexOf(id) + 1;
    const sup = document.createElement("sup");
    const a = document.createElement("a");
    a.href = `#fn-${id}`;
    a.id = `fnref-${id}`;
    a.textContent = String(n);
    sup.append(a);
    parent.appendChild(sup);
  }
  function buildFootnotes() {
    const section = document.createElement("section");
    section.className = "footnotes";
    section.append(document.createElement("hr"));
    const ol = document.createElement("ol");
    for (const id of footnoteOrder) {
      const li = document.createElement("li");
      li.id = `fn-${id}`;
      appendInline(li, activeFootnotes.get(id) ?? "");
      const back = document.createElement("a");
      back.href = `#fnref-${id}`;
      back.className = "footnote-back";
      back.textContent = "\u21A9";
      li.append(document.createTextNode(" "), back);
      ol.append(li);
    }
    section.append(ol);
    return section;
  }
  function buildTablePager(rows) {
    const pages = Math.ceil(rows.length / TABLE_PAGE_ROWS);
    let page = 0;
    const pager = document.createElement("div");
    pager.className = "md-table-pager";
    const range = document.createElement("span");
    range.className = "md-table-range mono";
    const nav = document.createElement("div");
    nav.className = "md-table-nav";
    const prev = document.createElement("button");
    prev.type = "button";
    prev.className = "md-table-page-btn";
    prev.setAttribute("aria-label", "Previous table page");
    prev.textContent = "\u2039 Prev";
    const label = document.createElement("span");
    label.className = "md-table-page mono";
    label.setAttribute("aria-live", "polite");
    const next = document.createElement("button");
    next.type = "button";
    next.className = "md-table-page-btn";
    next.setAttribute("aria-label", "Next table page");
    next.textContent = "Next \u203A";
    nav.append(prev, label, next);
    pager.append(range, nav);
    const apply = () => {
      rows.forEach((row, i) => {
        row.hidden = Math.floor(i / TABLE_PAGE_ROWS) !== page;
      });
      const first = page * TABLE_PAGE_ROWS + 1;
      const last = Math.min(rows.length, (page + 1) * TABLE_PAGE_ROWS);
      range.textContent = `${first}-${last} of ${rows.length}`;
      label.textContent = `${page + 1} / ${pages}`;
      prev.disabled = page === 0;
      next.disabled = page === pages - 1;
    };
    prev.addEventListener("click", () => {
      if (page > 0) {
        page--;
        apply();
      }
    });
    next.addEventListener("click", () => {
      if (page < pages - 1) {
        page++;
        apply();
      }
    });
    apply();
    return pager;
  }
  function buildList(items) {
    const root = document.createElement(items[0].ordered ? "ol" : "ul");
    if (items[0].ordered && items[0].start && items[0].start !== 1) root.start = items[0].start;
    const stack = [{ indent: items[0].indent, el: root }];
    for (const item of items) {
      while (stack.length > 1 && item.indent < stack[stack.length - 1].indent) stack.pop();
      if (item.indent > stack[stack.length - 1].indent) {
        const parentLi = stack[stack.length - 1].el.lastElementChild;
        const child = document.createElement(item.ordered ? "ol" : "ul");
        if (item.ordered && item.start && item.start !== 1) child.start = item.start;
        (parentLi ?? stack[stack.length - 1].el).append(child);
        stack.push({ indent: item.indent, el: child });
      }
      const li = document.createElement("li");
      const task = item.text.match(/^\[([ xX])\]\s+(.*)$/);
      if (task) {
        const cb = document.createElement("input");
        cb.type = "checkbox";
        cb.disabled = true;
        cb.checked = task[1].toLowerCase() === "x";
        li.append(cb, document.createTextNode(" "));
        appendInline(li, task[2]);
        li.classList.add("task-item");
      } else {
        appendInline(li, item.text);
      }
      stack[stack.length - 1].el.append(li);
    }
    return root;
  }
  function extractDefinitions(src) {
    const lines = src.split("\n");
    const body = [];
    const refs = /* @__PURE__ */ new Map();
    const footnotes = /* @__PURE__ */ new Map();
    let inFence = false;
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (/^\s*```/.test(line)) inFence = !inFence;
      if (inFence) {
        body.push(line);
        continue;
      }
      const fn = line.match(/^\[\^([^\]]+)\]:\s*(.*)$/);
      if (fn) {
        const id = fn[1];
        const parts = [fn[2]];
        while (i + 1 < lines.length && /^\s{2,}\S/.test(lines[i + 1])) {
          parts.push(lines[++i].trim());
        }
        footnotes.set(id, parts.join(" "));
        continue;
      }
      const ref = line.match(/^\s*\[([^\]]+)\]:\s*(\S+)(?:\s+"([^"]*)")?\s*$/);
      if (ref) {
        refs.set(ref[1].toLowerCase(), { url: ref[2], title: ref[3] });
        continue;
      }
      body.push(line);
    }
    return { body, refs, footnotes };
  }
  function plainText(s) {
    return s.replace(/!\[([^\]]*)\]\([^)]*\)/g, "$1").replace(/\[([^\]]+)\]\([^)]*\)/g, "$1").replace(/[`*_~]/g, "").trim();
  }
  function uniqueSlug(text) {
    const base = text.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "section";
    const n = headingSlugs.get(base) ?? 0;
    headingSlugs.set(base, n + 1);
    return n ? `${base}-${n}` : base;
  }
  var KEYWORDS = /* @__PURE__ */ new Set([
    "const",
    "let",
    "var",
    "function",
    "return",
    "if",
    "else",
    "for",
    "while",
    "do",
    "class",
    "extends",
    "new",
    "import",
    "export",
    "from",
    "default",
    "async",
    "await",
    "try",
    "catch",
    "finally",
    "throw",
    "typeof",
    "instanceof",
    "this",
    "super",
    "null",
    "undefined",
    "true",
    "false",
    "in",
    "of",
    "switch",
    "case",
    "break",
    "continue",
    "interface",
    "type",
    "enum",
    "public",
    "private",
    "protected",
    "static",
    "readonly",
    "def",
    "None",
    "True",
    "False",
    "elif",
    "lambda",
    "with",
    "as",
    "pass",
    "raise",
    "yield",
    "and",
    "or",
    "not",
    "is",
    "print"
  ]);
  function highlightCode(el2, lang, code) {
    const l = lang.toLowerCase();
    const kind = /^(js|javascript|jsx|ts|typescript|tsx)$/.test(l) ? "js" : /^(json)$/.test(l) ? "json" : /^(py|python)$/.test(l) ? "py" : /^(sh|bash|zsh|shell)$/.test(l) ? "sh" : /^(html|xml|svg)$/.test(l) ? "html" : /^(css|scss|less)$/.test(l) ? "css" : "none";
    if (kind === "none") {
      el2.textContent = code;
      return;
    }
    const token = kind === "html" ? /(<!--[\s\S]*?-->)|(<\/?[a-zA-Z][\w:-]*|\/?>)|("[^"]*"|'[^']*')/g : kind === "css" ? /(\/\*[\s\S]*?\*\/)|("[^"]*"|'[^']*')|([.#]?[a-zA-Z-]+)(?=\s*[:{])|([\d.]+(?:px|em|rem|%|s|ms|vh|vw)?)/g : kind === "json" ? /("(?:\\.|[^"\\])*")\s*(?=:)|("(?:\\.|[^"\\])*")|(\btrue\b|\bfalse\b|\bnull\b)|(-?\d+(?:\.\d+)?)/g : /(\/\/[^\n]*|\/\*[\s\S]*?\*\/|#[^\n]*)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`)|(\b\d+(?:\.\d+)?\b)|(\b[a-zA-Z_]\w*\b)/g;
    let last = 0;
    let m;
    const push = (text, cls) => {
      if (!text) return;
      if (!cls) {
        el2.appendChild(document.createTextNode(text));
        return;
      }
      const span = document.createElement("span");
      span.className = cls;
      span.textContent = text;
      el2.appendChild(span);
    };
    while (m = token.exec(code)) {
      push(code.slice(last, m.index));
      if (kind === "html") {
        if (m[1]) push(m[1], "tok-com");
        else if (m[2]) push(m[2], "tok-tag");
        else if (m[3]) push(m[3], "tok-str");
      } else if (kind === "css") {
        if (m[1]) push(m[1], "tok-com");
        else if (m[2]) push(m[2], "tok-str");
        else if (m[3]) push(m[3], "tok-prop");
        else if (m[4]) push(m[4], "tok-num");
      } else if (kind === "json") {
        if (m[1]) push(m[1], "tok-prop");
        else if (m[2]) push(m[2], "tok-str");
        else if (m[3]) push(m[3], "tok-kw");
        else if (m[4]) push(m[4], "tok-num");
      } else {
        if (m[1]) push(m[1], "tok-com");
        else if (m[2]) push(m[2], "tok-str");
        else if (m[3]) push(m[3], "tok-num");
        else if (m[4]) push(m[4], KEYWORDS.has(m[4]) ? "tok-kw" : "");
      }
      last = m.index + m[0].length;
    }
    push(code.slice(last));
  }
  function termEl(text) {
    const dt = document.createElement("dt");
    appendInline(dt, text);
    return dt;
  }

  // src/sidepanel/panel.ts
  var PAGE_ORIGINS = ["http://*/*", "https://*/*"];
  var EMPTY = {
    conn: "connecting",
    connSince: Date.now(),
    reconnects: 0,
    firstRun: false,
    everConnected: false,
    chatPaused: null,
    settings: { orchestratorUrl: "ws://127.0.0.1:8790/chrome", theme: "auto" },
    rail: { status: "idle" },
    plan: null,
    planReplaceFrom: void 0,
    planAnnotation: void 0,
    stepStates: {},
    scratch: [],
    compressedCount: 0,
    confirm: null,
    confirmQueue: [],
    health: null,
    pageAccess: null,
    paused: false,
    approvals: 0,
    feed: [],
    resumedNotice: false,
    queuedTask: null,
    queuedAnswers: [],
    lastSnapshotAt: 0,
    conversation: null,
    conversations: [],
    messages: [],
    live: null,
    chatRunning: false
  };
  var SUGGESTIONS = [
    { title: "Summarize this page", hint: "Read the tab you're on" },
    { title: "Check my open tabs", hint: "See what's waiting for you" },
    { title: "What needs a reply?", hint: "Look through unread mail" }
  ];
  var Panel = class {
    state = { ...EMPTY };
    ws = null;
    renderQueued = false;
    /** Timer fallback for the rAF path (rAF can be starved in occluded/headless docs). */
    renderFallback = null;
    tick = null;
    scratchExpanded = false;
    planCollapsed = false;
    feedCollapsed = true;
    composerText = "";
    /** Inline edit of a previous user message (null = not editing). */
    editingId = null;
    editingDraft = "";
    sentTaskText = null;
    noticeDismissed = false;
    /** Dismissed the one-time page-access prompt for this panel session. */
    accessDismissed = false;
    /** Why "open a tab here" failed: the panel's window is not tabbable. */
    noTabsError = "";
    /** Open state for grouped tool runs, keyed by the first call id. */
    openToolGroups = /* @__PURE__ */ new Set();
    /** Rail controls are stable DOM nodes; rebuilding them every stream frame
     *  makes the Stop button impossible to click. */
    railControlsKey = "";
    /** Filter text for the chat history page. */
    historyQuery = "";
    /** Inline rename/delete state in the chat history page. */
    renamingId = null;
    renamingDraft = "";
    deletingId = null;
    /** This chat's thread id (ChatGPT-style). Owned by the panel, persisted locally,
     *  sent with every task so follow-ups share memory. Null until first use. */
    conversationId = null;
    /** Window this panel belongs to (used to keep multi-window work scoped). */
    windowId;
    /** Auto-prompt for page access at most once per panel session (Settings can re-ask). */
    pageAccessAsked = false;
    /** Turns superseded by a steering message: their late frames must not touch the
     *  new turn's UI or produce a misleading "Stopped" notice. */
    staleTurns = /* @__PURE__ */ new Set();
    // Rebuild gating: overlay/sheet bodies are only reconstructed when their
    // content actually changes — every-rebuild wipes inputs and yanks focus.
    lastOverlayKey = null;
    lastSheetSig = null;
    lastHistorySig = null;
    /** Models fetched from the configured OpenAI-compatible endpoint. */
    llmModels = [];
    /** AI hosts Vicaro can register itself with (Settings -> AI tools). */
    mcpHosts = null;
    mcpError = null;
    /** Reveal the saved API key in Settings. Reset every time the page opens. */
    showApiKey = false;
    /** Whether the helper connection fields are expanded. */
    advancedOpen = false;
    /** On-demand permissions (Settings -> Access). null until checked. */
    caps = { cdp: null, history: null };
    connBannerTimer = null;
    /** Banners are rebuilt only when their meaning changes; a click must survive
     *  the next stream frame. */
    bannersKey = "";
    el;
    chatPinned = true;
    scrollTimer = null;
    async init() {
      this.el = {
        app: document.getElementById("app"),
        rail: document.getElementById("rail"),
        banners: document.getElementById("banners"),
        stream: document.getElementById("stream"),
        overlay: document.getElementById("overlay"),
        sheet: document.getElementById("sheet"),
        sheetBackdrop: document.getElementById("sheetBackdrop"),
        history: document.getElementById("history")
      };
      try {
        this.windowId = (await chrome.windows.getCurrent()).id;
      } catch {
      }
      this.state.settings = await getSettings();
      this.applyTheme();
      this.buildShell();
      try {
        const key = this.convKey();
        const bag = await chrome.storage.local.get(key);
        if (typeof bag[key] === "string" && bag[key]) {
          this.conversationId = String(bag[key]).slice(0, 64);
        }
      } catch {
      }
      this.el.stream.addEventListener("scroll", () => {
        const s = this.el.stream;
        this.chatPinned = s.scrollHeight - s.scrollTop - s.clientHeight < 80;
        this.updateJumpButton();
      });
      window.addEventListener("resize", () => {
        if (this.state.confirm) this.syncConfirmSpace();
      });
      this.el.history.addEventListener("keydown", (ev) => {
        if (ev.key !== "Escape") return;
        if (this.deletingId) {
          ev.preventDefault();
          ev.stopPropagation();
          this.deletingId = null;
          this.renderHistory();
          return;
        }
        if (this.renamingId) {
          ev.preventDefault();
          ev.stopPropagation();
          this.renamingId = null;
          this.renderHistory();
          return;
        }
        ev.preventDefault();
        this.toggleHistory(false);
      });
      this.el.sheet.addEventListener("keydown", (ev) => {
        if (ev.key !== "Escape") return;
        const target = ev.target;
        if (target && /^(INPUT|SELECT|TEXTAREA)$/.test(target.tagName)) {
          ev.preventDefault();
          target.blur();
          window.setTimeout(() => {
            if (!this.el.sheet.hidden) this.el.sheet.querySelector("#settings-back")?.focus({ preventScroll: true });
          }, 0);
          return;
        }
        ev.preventDefault();
        this.toggleSheet(false);
      });
      document.addEventListener("visibilitychange", () => {
        this.scheduleRender();
        void this.refreshTabContext();
      });
      const sameWindow = (id) => this.windowId === void 0 || id === void 0 || id === this.windowId;
      const onCreated = (tab) => {
        if (sameWindow(tab.windowId)) void this.refreshTabContext();
      };
      const onRemoved = (_tabId, info) => {
        if (sameWindow(info.windowId)) void this.refreshTabContext();
      };
      const onActivated = (info) => {
        if (sameWindow(info.windowId)) void this.refreshTabContext();
      };
      const onUpdated = (_tabId, change, tab) => {
        if (sameWindow(tab.windowId) && (change.url || change.title || change.status === "complete")) void this.refreshTabContext();
      };
      try {
        chrome.tabs.onCreated.addListener(onCreated);
        chrome.tabs.onRemoved.addListener(onRemoved);
        chrome.tabs.onActivated.addListener(onActivated);
        chrome.tabs.onUpdated.addListener(onUpdated);
      } catch {
      }
      this.setState({ firstRun: !await this.hasEverConnected() });
      void this.refreshPageAccess();
      void this.refreshTabContext();
      this.render();
      await this.connect();
      this.tick = window.setInterval(() => {
        if (this.state.chatRunning || this.isLive()) this.scheduleRender();
      }, 1e3);
      try {
        await chrome.runtime.sendMessage({ type: "vicaro.panelOpened" });
      } catch {
      }
    }
    /** Per-window conversation key: two Chrome windows must not share one thread
     *  (their turns would cancel and their tab contexts would bleed together). */
    convKey() {
      return this.windowId !== void 0 ? `vicaro.conversationId.${this.windowId}` : "vicaro.conversationId";
    }
    rememberConversation() {
      if (!this.conversationId) return;
      void chrome.storage.local.set({ [this.convKey()]: this.conversationId }).catch(() => {
      });
    }
    async hasEverConnected() {
      const bag = await chrome.storage.local.get("vicaro.everConnected");
      return !!bag["vicaro.everConnected"];
    }
    // ---- page access (optional host permission) ----
    // The extension ships without install-time <all_urls>; access is requested at the
    // first task submit (a user gesture) and can be re-granted from Settings either way.
    async refreshPageAccess() {
      try {
        const granted = await chrome.permissions.contains({ origins: PAGE_ORIGINS });
        this.setState({ pageAccess: granted });
      } catch {
      }
    }
    /** Tab context for the welcome screen and composer strip. Best-effort only. */
    async refreshTabContext() {
      try {
        const tabs = await chrome.tabs.query(this.windowId !== void 0 ? { windowId: this.windowId } : {});
        const active = tabs.find((t) => t.active && !/^chrome-extension:/i.test(t.url ?? "")) ?? tabs.find((t) => !/^chrome-extension:/i.test(t.url ?? "")) ?? tabs.find((t) => t.active) ?? tabs[0];
        if (tabs.length) this.noTabsError = "";
        this.setState({
          tabContext: {
            count: tabs.length,
            title: active?.title ? String(active.title) : void 0,
            url: active?.url ? String(active.url) : void 0
          }
        });
      } catch {
      }
    }
    /** One-click fix for the empty conversation window: create a tab in THIS
     *  window (never another one), then refresh the composer context. */
    async openTabInWindow() {
      this.noTabsError = "";
      try {
        const tab = await chrome.tabs.create({
          url: "about:blank",
          active: true,
          ...this.windowId !== void 0 ? { windowId: this.windowId } : {}
        });
        if (tab?.windowId !== void 0) await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {
        });
        await this.refreshTabContext();
      } catch {
        this.noTabsError = "This window can't take a tab. Move the panel to a normal Chrome window.";
      }
      this.scheduleRender();
    }
    tabContextLabel() {
      const c = this.state.tabContext;
      if (!c) return "This window";
      if (c.url && !/^https?:/i.test(c.url)) return truncate(c.title || "This window", 46);
      let host = "";
      try {
        host = c.url ? new URL(c.url).host.replace(/^www\./, "") : "";
      } catch {
      }
      const title = c.title && c.title !== host ? c.title : "";
      return truncate([title, host].filter(Boolean).join(" \xB7 ") || "This window", 46);
    }
    /** Must be called synchronously from a user gesture. Failures (tests, headless,
     *  user dismissal) are swallowed — the task itself is never blocked on this. */
    requestPageAccess() {
      try {
        void chrome.permissions.request({ origins: PAGE_ORIGINS }).then((granted) => {
          this.setState({ pageAccess: !!granted });
        }).catch(() => {
        });
      } catch {
      }
    }
    isLive() {
      const s = this.state.rail.status;
      return s === "running" || s === "planning" || s === "paused" || s === "waiting_user";
    }
    // ---- connection ----
    async connect() {
      this.setConnection("connecting");
      const previous = this.ws;
      let client;
      client = new WsClient({
        role: "sidepanel",
        onFrame: (f) => {
          if (this.ws === client) this.onFrame(f);
        },
        onState: (s, info) => {
          if (this.ws !== client) return;
          if (s === "open") {
            void chrome.storage.local.set({ "vicaro.everConnected": true });
            this.setState({ conn: "open", everConnected: true, firstRun: false, connSince: Date.now() });
            void this.flushQueued();
          } else {
            this.setConnection(s, info);
          }
        }
      });
      this.ws = client;
      try {
        previous?.disconnect();
      } catch {
      }
      await client.connect();
    }
    setConnection(s, info) {
      const bump = s === "connecting" && this.state.everConnected && this.state.conn !== "connecting";
      this.setState({
        conn: s,
        connSince: Date.now(),
        connCode: info?.code,
        reconnects: bump ? this.state.reconnects + 1 : this.state.reconnects
      });
      if (this.connBannerTimer !== null) window.clearTimeout(this.connBannerTimer);
      this.connBannerTimer = s === "open" ? null : window.setTimeout(() => {
        this.connBannerTimer = null;
        this.scheduleRender();
      }, 1200);
    }
    async flushQueued() {
      const snapshot = await this.ws?.request("snapshot_request", this.conversationId ? { conversationId: this.conversationId } : {}) ?? null;
      if (snapshot?.type === "snapshot") this.onFrame(snapshot);
      if (this.state.queuedTask) {
        const text = this.state.queuedTask;
        this.setState({ queuedTask: null });
        this.submitTask(text);
      }
      const answers = this.state.queuedAnswers.slice();
      const unsent = [];
      for (const answer of answers) {
        const ok = this.ws?.emit("confirm_response", answer) ?? false;
        if (!ok) unsent.push(answer);
      }
      this.setState({ queuedAnswers: unsent });
    }
    // ---- frame handling ----
    onFrame(frame) {
      switch (frame.type) {
        case "snapshot":
          return this.onSnapshot(frame.payload);
        case "task_status":
          return this.onTaskStatus(frame.payload);
        case "task_ack":
          return this.onTaskAck(frame.payload);
        case "plan":
        case "plan_update":
          return this.onPlan(frame.payload);
        case "step_event":
          return this.onStepEvent(frame.payload);
        case "action_log":
          return this.onActionLog(frame.payload);
        case "buffer_compressed":
          return this.setState({ compressedCount: Math.max(0, Number(frame.payload?.compressedCount) || 0) });
        case "confirm_request":
          return this.onConfirmRequest(frame.payload);
        case "health":
          return this.setState({ health: frame.payload });
        case "chat_state":
          return this.onChatState(frame.payload);
        case "chat_perf":
          return this.onChatPerf(frame.payload);
        case "chat_paused":
          return this.onChatPaused(frame.payload);
        case "chat_delta":
          return this.onChatDelta(frame.payload);
        case "chat_commit":
          return this.onChatCommit(frame.payload);
        case "chat_reset":
          return this.onChatReset(frame.payload);
        case "chat_reasoning":
          return this.onChatReasoning(frame.payload);
        case "chat_tool":
          return this.onChatTool(frame.payload);
        case "chat_done":
          return this.onChatDone(frame.payload);
        case "chat_error":
          return this.onChatError(frame.payload);
        case "qa_verdict":
          return;
        // eval traffic, not panel-facing
        default:
          return;
      }
    }
    // ---- chat-first assistant frames ----
    viewedConversation(p) {
      return !p?.conversationId || p.conversationId === this.conversationId;
    }
    /** A frame from a turn the user replaced by sending a newer message. */
    staleTurn(p) {
      const id = typeof p?.turnId === "string" ? p.turnId : "";
      return !!id && this.staleTurns.has(id);
    }
    onChatState(p) {
      if (!this.viewedConversation(p) || this.staleTurn(p)) return;
      if (p.running) {
        const turnId = this.state.chatTurnId ?? p.turnId;
        this.setState({
          chatRunning: true,
          chatPaused: null,
          chatActivity: p.activity ?? this.state.chatActivity,
          chatTurnId: turnId,
          chatStartedAt: this.state.chatStartedAt ?? Date.now(),
          // Create the live bubble at turn start so the first tool call or
          // token lands in place instead of popping the row in late.
          live: this.state.live ?? { text: "", tools: [], reasoning: "", parts: [] }
        });
      } else if (!this.state.chatTurnId || this.state.chatTurnId === p.turnId) {
        this.setState({ chatRunning: false, chatActivity: void 0, chatStartedAt: void 0, chatPerf: void 0 });
      }
    }
    onChatPerf(p) {
      if (!this.viewedConversation(p) || this.staleTurn(p)) return;
      if (this.state.chatTurnId && p.turnId !== this.state.chatTurnId) return;
      const perf = p?.perf;
      if (!perf || typeof perf !== "object") return;
      this.setState({ chatPerf: perf });
    }
    onChatPaused(p) {
      if (!p?.conversationId) return;
      if (this.conversationId && p.conversationId !== this.conversationId) return;
      this.setState({
        chatPaused: {
          conversationId: String(p.conversationId),
          turnId: String(p.turnId ?? ""),
          goal: String(p.goal ?? ""),
          reason: typeof p.reason === "string" ? p.reason : void 0
        },
        chatRunning: false,
        chatActivity: void 0,
        chatPerf: void 0
      });
    }
    onChatDelta(p) {
      if (!this.viewedConversation(p) || this.staleTurn(p)) return;
      if (this.state.chatTurnId && p.turnId !== this.state.chatTurnId) return;
      const delta = String(p.text ?? "");
      if (!delta) return;
      const live = this.state.live ?? { text: "", tools: [], reasoning: "", parts: [] };
      const parts = [...live.parts];
      if (delta) {
        const last = parts[parts.length - 1];
        if (last && last.type === "text") last.text += delta;
        else parts.push({ type: "text", text: delta });
      }
      const provisional = !!p.provisional;
      this.setState({
        chatTurnId: this.state.chatTurnId ?? p.turnId,
        chatActivity: provisional ? "writing\u2026" : this.state.chatActivity === "thinking\u2026" ? "responding\u2026" : this.state.chatActivity,
        live: {
          ...live,
          text: live.text + delta,
          parts,
          draft: provisional ? (live.draft ?? "") + delta : live.draft
        }
      });
    }
    /** Provisional answer text passed verification: keep it, drop the unverified mark. */
    onChatCommit(p) {
      if (!this.viewedConversation(p) || this.staleTurn(p)) return;
      if (this.state.chatTurnId && p.turnId !== this.state.chatTurnId) return;
      const live = this.state.live;
      if (!live) return;
      this.setState({ live: { ...live, draft: void 0 }, chatActivity: "responding\u2026" });
    }
    /** Verification rejected the provisional text: drop exactly those characters,
     *  keep the tool/reasoning trace so the user can still see what was attempted. */
    onChatReset(p) {
      if (!this.viewedConversation(p) || this.staleTurn(p)) return;
      if (this.state.chatTurnId && p.turnId !== this.state.chatTurnId) return;
      const live = this.state.live;
      if (!live) return;
      const draft = live.draft ?? "";
      if (!draft) return;
      let text = live.text;
      if (text.endsWith(draft)) text = text.slice(0, -draft.length);
      const parts = [...live.parts];
      const last = parts[parts.length - 1];
      if (last && last.type === "text") {
        const trimmed = last.text.slice(0, Math.max(0, last.text.length - draft.length));
        if (trimmed) last.text = trimmed;
        else parts.pop();
      }
      this.setState({ live: { ...live, text, parts, draft: void 0 } });
    }
    /** The model's thoughts, streamed while it works — shown in the live bubble. */
    onChatReasoning(p) {
      if (!this.viewedConversation(p) || this.staleTurn(p)) return;
      if (this.state.chatTurnId && p.turnId !== this.state.chatTurnId) return;
      const delta = String(p.text ?? "");
      if (!delta) return;
      const live = this.state.live ?? { text: "", tools: [], reasoning: "", parts: [] };
      const parts = [...live.parts];
      if (delta) {
        const last = parts[parts.length - 1];
        if (last && last.type === "reasoning") last.text += delta;
        else parts.push({ type: "reasoning", text: delta });
      }
      this.setState({
        chatTurnId: this.state.chatTurnId ?? p.turnId,
        // "reasoning…" is internal: it distinguishes an actual thinking stream
        // from the generic pre-token wait that also reports as "thinking…".
        chatActivity: "reasoning\u2026",
        live: { ...live, reasoning: (live.reasoning ?? "") + delta, parts }
      });
    }
    onChatTool(p) {
      if (!this.viewedConversation(p) || this.staleTurn(p)) return;
      if (this.state.chatTurnId && p.turnId !== this.state.chatTurnId) return;
      const live = this.state.live ?? { text: "", tools: [], reasoning: "", parts: [] };
      const tools = [...live.tools];
      const i = tools.findIndex((t) => t.callId === p.callId);
      const parts = [...live.parts];
      if (p.phase === "start") {
        const chip = { callId: p.callId, name: p.name, summary: p.summary, args: p.args, tier: p.tier, decision: p.decision };
        if (i >= 0) tools[i] = { ...tools[i], ...chip };
        else tools.push(chip);
        parts.push({ type: "tool", tool: chip });
      } else if (i >= 0) {
        tools[i] = { ...tools[i], summary: p.summary ?? tools[i].summary, ok: p.ok, ms: p.ms, result: p.result, image: p.image ?? tools[i].image, preview: p.preview ?? tools[i].preview, tier: p.tier ?? tools[i].tier, decision: p.decision ?? tools[i].decision };
        const updated = parts.map((pt) => pt.type === "tool" && pt.tool.callId === p.callId ? { ...pt, tool: tools[i] } : pt);
        parts.splice(0, parts.length, ...updated);
      }
      this.setState({
        chatTurnId: this.state.chatTurnId ?? p.turnId,
        chatActivity: p.phase === "start" ? p.summary : this.state.chatActivity,
        chatLastTool: p.summary ? String(p.summary) : this.state.chatLastTool,
        live: { ...live, tools, parts }
      });
    }
    onChatDone(p) {
      if (!this.viewedConversation(p) || this.staleTurn(p)) return;
      if (this.state.chatTurnId && p.turnId !== this.state.chatTurnId) return;
      const live = this.state.live ?? { text: "", tools: [], reasoning: "", parts: [] };
      const text = String(p.text ?? live.text ?? "");
      const reasoning = String(p.reasoning ?? live.reasoning ?? "").trim();
      const parts = Array.isArray(p.parts) && p.parts.length ? p.parts : live.parts;
      const messages = [...this.state.messages];
      if (text.trim() || live.tools.length || parts.length) {
        messages.push({
          id: typeof p.messageId === "number" ? p.messageId : -Date.now(),
          role: "assistant",
          text,
          createdAt: Date.now(),
          tools: live.tools.length ? live.tools : void 0,
          reasoning: reasoning || void 0,
          parts: parts.length ? parts : void 0,
          metrics: p.metrics
        });
      }
      this.setState({ messages, live: null, chatRunning: false, chatPaused: null, chatActivity: void 0, chatLastTool: void 0, chatTurnId: void 0, chatStartedAt: void 0, chatPerf: void 0 });
      if (p.stopped) this.pushFeed("Stopped - your message didn't finish.", "warn");
    }
    onChatError(p) {
      if (!this.viewedConversation(p) || this.staleTurn(p)) return;
      this.pushFeed(`Error: ${String(p?.error ?? "unknown")}`.slice(0, 160), "warn");
      this.setState({ chatRunning: false, chatPaused: null, chatActivity: void 0, chatLastTool: void 0, chatTurnId: void 0, chatStartedAt: void 0, chatPerf: void 0 });
    }
    onSnapshot(s) {
      const active = s.active;
      const rail = active ? {
        status: active.task.status,
        detail: void 0,
        step: active.task.step,
        totalSteps: active.task.stepsTotal || active.plan?.steps.length,
        taskText: active.task.task,
        startedAt: active.task.createdAt,
        finishedAt: active.task.status === "done" ? active.task.updatedAt : void 0,
        result: active.result
      } : { status: "idle" };
      if (active) this.lastTaskId = active.task.taskId;
      if (!this.conversationId && s.conversation?.id) {
        this.conversationId = s.conversation.id;
        this.rememberConversation();
      }
      const runningNow = !!s.chatRunning && (!s.chatRunning.conversationId || s.chatRunning.conversationId === this.conversationId);
      void this.refreshTabContext();
      this.setState({
        health: s.health,
        lastSnapshotAt: Date.now(),
        rail,
        plan: active?.plan ?? null,
        scratch: active?.scratchpad ?? [],
        compressedCount: active?.compressedCount ?? 0,
        // Clear stale dialogs: a snapshot without a pending confirm means no confirm.
        confirm: active?.pendingConfirm ?? null,
        conversation: s.conversation ?? null,
        conversations: s.conversations ?? [],
        // Chat transcript: the store is the source of truth — but never clobber an
        // in-flight turn (its optimistic message and live text aren't stored yet).
        // On a fresh load (no in-memory messages yet) always hydrate from the store.
        messages: runningNow && this.state.messages.length ? this.state.messages : (s.messages ?? []).map((m) => ({ ...m })),
        chatRunning: runningNow,
        chatPaused: !s.chatRunning && s.chatPaused && (!s.chatPaused.conversationId || s.chatPaused.conversationId === this.conversationId) ? s.chatPaused : null,
        chatActivity: runningNow ? s.chatRunning?.activity ?? this.state.chatActivity : void 0,
        chatPerf: runningNow ? s.chatRunning?.perf ?? this.state.chatPerf : void 0,
        chatTurnId: runningNow ? this.state.chatTurnId ?? s.chatRunning?.turnId : void 0,
        live: runningNow ? this.state.live ?? (s.chatRunning && ((s.chatRunning.text ?? "").trim() || (s.chatRunning.tools?.length ?? 0) > 0 || (s.chatRunning.parts?.length ?? 0) > 0) ? { text: s.chatRunning.text ?? "", tools: s.chatRunning.tools ?? [], reasoning: s.chatRunning.reasoning, parts: s.chatRunning.parts ?? [] } : null) : null,
        resumedNotice: !this.noticeDismissed && this.shouldShowResumeNotice(active?.task.status)
      });
      if (active?.plan) {
        this.setState({ rail: { ...this.state.rail, totalSteps: active.plan.steps.length } });
      }
    }
    shouldShowResumeNotice(status) {
      if (!status) return false;
      if (!["running", "paused", "waiting_user", "awaiting_resume"].includes(status)) return false;
      return this.state.everConnected && this.state.reconnects > 0;
    }
    onTaskStatus(p) {
      if (!p) return;
      if (p.taskId) this.lastTaskId = p.taskId;
      const rail = {
        ...this.state.rail,
        status: p.status ?? this.state.rail.status,
        detail: p.detail,
        step: p.step ?? this.state.rail.step,
        totalSteps: p.totalSteps ?? this.state.rail.totalSteps,
        tier: p.tier ?? this.state.rail.tier,
        latencyMs: p.latencyMs,
        result: p.result ?? this.state.rail.result,
        finishedAt: p.status === "done" ? Date.now() : this.state.rail.finishedAt,
        startedAt: this.state.rail.startedAt
      };
      if (p.status === "running" && !this.state.rail.startedAt) rail.startedAt = Date.now();
      if (p.status === "done" || p.status === "failed") {
        this.pushFeed(p.status === "done" ? `Finished${p.detail ? `: ${p.detail}` : ""}` : `Couldn't finish: ${p.error ?? p.detail ?? p.status}`, p.status === "done" ? "ok" : "warn");
      }
      if (p.status === "awaiting_resume") this.pushFeed("I lost the browser for a moment - I'll pick up where I left off", "warn");
      if (typeof p.detail === "string" && /working in|opened a new tab|switched to|closed the tab/i.test(p.detail)) this.pushFeed(p.detail, "info");
      else if (typeof p.detail === "string" && /stuck|replanning|conservative|denied/i.test(p.detail)) this.pushFeed(p.detail, "warn");
      this.setState({ rail });
    }
    onTaskAck(p) {
      if (!p) return;
      if (p.taskId) this.lastTaskId = p.taskId;
      if (typeof p.conversationId === "string" && p.conversationId && p.conversationId !== this.conversationId) {
        this.conversationId = p.conversationId.slice(0, 64);
        this.rememberConversation();
      }
      if (p.accepted === false) {
        this.setState({ rail: { status: "failed", detail: p.error ?? "I couldn't take that task - try wording it differently" } });
      }
    }
    /** New chat: forget this thread and start fresh (the old chat stays in history). */
    startNewChat() {
      if (this.isLive()) {
        this.setChatNavError("Finish or stop this task before starting a new chat.");
        return;
      }
      this.toggleHistory(false, false);
      this.conversationId = `c_${crypto.randomUUID().slice(0, 8)}`;
      this.rememberConversation();
      this.sentTaskText = null;
      this.composerText = "";
      this.planCollapsed = false;
      this.scratchExpanded = false;
      this.renamingId = null;
      this.deletingId = null;
      this.setState({
        rail: { status: "idle" },
        plan: null,
        scratch: [],
        stepStates: {},
        compressedCount: 0,
        planAnnotation: void 0,
        planReplaceFrom: void 0,
        approvals: 0,
        feed: [],
        resumedNotice: false,
        sheetError: void 0,
        sheetNotice: void 0,
        historyError: void 0,
        confirm: null,
        confirmQueue: [],
        messages: [],
        live: null,
        chatRunning: false,
        chatActivity: void 0,
        chatTurnId: void 0,
        chatPerf: void 0,
        conversation: { id: this.conversationId, turns: [] }
      });
      this.rebuildStream();
      this.render();
      this.focusComposerSoon();
    }
    /** Open a chat from history: view its thread, continue it on send. */
    viewConversation(id) {
      if (id === this.conversationId) {
        this.toggleHistory(false);
        return;
      }
      if (this.isLive()) {
        this.setHistoryError("Finish or stop this task before opening another chat.");
        return;
      }
      this.setHistoryError(void 0);
      this.renamingId = null;
      this.deletingId = null;
      this.conversationId = id;
      void chrome.storage.local.set({ [this.convKey()]: id }).catch(() => {
      });
      this.toggleHistory(false, false);
      this.sentTaskText = null;
      this.setState({
        rail: { status: "idle" },
        plan: null,
        scratch: [],
        stepStates: {},
        compressedCount: 0,
        planAnnotation: void 0,
        planReplaceFrom: void 0,
        approvals: 0,
        feed: [],
        resumedNotice: false,
        confirm: null,
        confirmQueue: [],
        messages: [],
        live: null,
        chatRunning: false,
        chatActivity: void 0,
        chatTurnId: void 0,
        chatPerf: void 0,
        conversation: { id, turns: [] }
      });
      this.rebuildStream();
      this.render();
      this.focusComposerSoon();
      void this.ws?.request("snapshot_request", { conversationId: id }, 8e3).then((f) => {
        if (f?.type === "snapshot") this.onFrame(f);
      }).catch(() => {
      });
    }
    /** After leaving history for a chat, put the caret where the user will type. */
    focusComposerSoon() {
      window.setTimeout(() => {
        if (!this.el.history.hidden || !this.el.sheet.hidden) return;
        this.el.stream.querySelector("#composer-input")?.focus({ preventScroll: true });
      }, 40);
    }
    onPlan(p) {
      if (!p?.plan) return;
      this.setState({
        plan: p.plan,
        planReplaceFrom: p.replaceFromStep,
        planAnnotation: p.annotation
      });
      if (p.annotation) this.pushFeed(`I changed the plan - ${p.annotation}`, "info");
      if (this.state.rail.totalSteps !== p.plan.steps.length) {
        this.setState({ rail: { ...this.state.rail, totalSteps: p.plan.steps.length } });
      }
    }
    onStepEvent(p) {
      if (!p) return;
      const idx = Number(p.step) || 0;
      this.setState({
        stepStates: {
          ...this.state.stepStates,
          [idx]: { description: p.description, summary: p.actionSummary, ok: p.ok, error: p.error, latencyMs: p.latencyMs, tier: p.tier }
        }
      });
      if (p.phase === "failed" && p.error) this.pushFeed(`${p.actionSummary ?? "step"} - ${p.error}`, "warn");
    }
    onActionLog(p) {
      if (!p?.row) return;
      const scratch = [...this.state.scratch, p.row].slice(-200);
      this.setState({ scratch });
    }
    confirmAnswered = null;
    /** Images pasted into the composer, waiting to be sent with the next message. */
    pendingImages = [];
    /** Downscale pasted images (max 4) and show them above the composer. */
    async attachImages(files) {
      for (const f of files) {
        if (this.pendingImages.length >= 4) break;
        try {
          const dataUrl = await downscaleImageFile(f, 1400, 0.82);
          this.pendingImages.push(dataUrl);
        } catch {
        }
      }
      this.updateAttachmentsRow();
    }
    buildAttachRow() {
      const row = el("div", { class: "attach-row" });
      this.pendingImages.forEach((src, i) => {
        const chip = el("div", { class: "attach-chip" });
        chip.append(el("img", { src, alt: "pasted image" }));
        const rm = el("button", { class: "attach-remove", title: "Remove this image", "aria-label": "Remove image" }, "\u2715");
        rm.onclick = (ev) => {
          ev.preventDefault();
          this.pendingImages.splice(i, 1);
          this.updateAttachmentsRow();
        };
        chip.append(rm);
        row.append(chip);
      });
      return row;
    }
    updateAttachmentsRow() {
      const dock = this.el.stream.querySelector(".dock");
      if (!dock) return;
      dock.querySelector(".attach-row")?.remove();
      if (this.pendingImages.length) dock.prepend(this.buildAttachRow());
    }
    onConfirmRequest(p) {
      if (!p?.requestId) return;
      if (String(p.taskId ?? "").startsWith("chat:") && this.conversationId && p.taskId !== `chat:${this.conversationId}`) return;
      const cur = this.state.confirm;
      if (cur && cur.requestId !== p.requestId && this.confirmAnswered !== cur.requestId) {
        this.setState({ confirmQueue: [...this.state.confirmQueue, p] });
        return;
      }
      if (cur && cur.requestId === p.requestId && cur.requestedAt === p.requestedAt) {
        this.setState({ confirm: p });
        return;
      }
      this.setState({ confirm: p });
    }
    // ---- actions ----
    /** Composer submit: one chat turn. Sending while a turn runs steers it (the
     *  orchestrator stops the old turn and starts the new message). */
    submitTask(rawText) {
      const text = (rawText ?? this.composerText).trim();
      const images = this.pendingImages.length ? [...this.pendingImages] : void 0;
      if (!text && !images) return;
      if (this.state.pageAccess !== true && !this.pageAccessAsked) {
        this.pageAccessAsked = true;
        this.requestPageAccess();
      }
      if (this.state.conn !== "open") {
        this.setState({ queuedTask: text });
        return;
      }
      if (!this.conversationId) {
        this.conversationId = `c_${crypto.randomUUID().slice(0, 8)}`;
        this.rememberConversation();
      }
      if (this.state.chatRunning && this.state.chatTurnId) this.staleTurns.add(this.state.chatTurnId);
      const ok = this.ws?.emit("chat_send", { conversationId: this.conversationId, text, images, windowId: this.windowId }) ?? false;
      if (!ok) {
        this.setState({ queuedTask: text });
        return;
      }
      this.lastTaskId = null;
      this.sentTaskText = text;
      this.composerText = "";
      this.pendingImages = [];
      this.planCollapsed = false;
      this.scratchExpanded = false;
      const localUser = { id: -Date.now(), role: "user", text, createdAt: Date.now(), images };
      this.setState({
        messages: [...this.state.messages, localUser],
        live: null,
        chatRunning: true,
        chatActivity: "thinking\u2026",
        chatLastTool: void 0,
        chatTurnId: void 0,
        rail: { status: "idle", taskText: text, startedAt: Date.now() },
        feed: []
      });
      this.rebuildStream();
      this.render();
    }
    /** Edit a previous user message in place (Save re-runs from that point). */
    startEdit(m) {
      if (this.state.chatRunning) return;
      this.editingId = m.id;
      this.editingDraft = m.text;
      this.rebuildStream();
      this.render();
    }
    cancelEdit() {
      this.editingId = null;
      this.editingDraft = "";
      this.rebuildStream();
      this.render();
    }
    /** Save the inline edit: discard this message and every later one, then re-send. */
    saveEdit(m) {
      const text = (this.editingDraft || "").trim();
      const images = [...m.images ?? []];
      if (!text && !images.length) return;
      if (!this.conversationId) return;
      const idx = this.state.messages.findIndex((x) => x.id === m.id);
      if (idx < 0) return;
      const ok = this.ws?.emit("chat_edit", {
        conversationId: this.conversationId,
        messageId: m.id,
        text,
        images: images.length ? images : void 0,
        windowId: this.windowId
      }) ?? false;
      if (!ok) return;
      const kept = this.state.messages.slice(0, idx);
      const localUser = { id: -Date.now(), role: "user", text, createdAt: Date.now(), images: images.length ? images : void 0 };
      this.editingId = null;
      this.editingDraft = "";
      this.setState({
        messages: [...kept, localUser],
        live: null,
        chatRunning: true,
        chatActivity: "thinking\u2026",
        chatLastTool: void 0,
        chatTurnId: void 0,
        feed: []
      });
      this.rebuildStream();
      this.render();
    }
    /** Send a previous user message again, preserving its attachments. */
    resendMessage(m) {
      this.pendingImages = [...m.images ?? []];
      this.submitTask(m.text);
    }
    cancelChat() {
      if (!this.conversationId) return;
      this.ws?.emit("chat_cancel", { conversationId: this.conversationId });
    }
    sendControl(action) {
      const taskId = this.lastTaskId ?? this.state.confirm?.taskId;
      if (!taskId) return;
      const ok = this.ws?.emit("task_control", { taskId, action }) ?? false;
      if (!ok) return;
      if (action === "pause") this.setState({ paused: true });
      if (action === "resume") this.setState({ paused: false });
    }
    lastTaskId = null;
    activeTaskId() {
      return this.lastTaskId ?? this.state.confirm?.taskId ?? null;
    }
    answerConfirm(response) {
      const c = this.state.confirm;
      if (!c) return;
      const requestId = c.requestId;
      const answer = {
        taskId: c.taskId,
        requestId,
        decision: response.decision ?? "deny",
        choiceIndex: response.choiceIndex,
        text: response.text
      };
      if (!this.ws || !this.ws.isOpen) {
        this.setState({ queuedAnswers: [...this.state.queuedAnswers, answer] });
        return;
      }
      void (async () => {
        const ack = await this.ws?.request("confirm_response", answer, 8e3).catch(() => null);
        if (!ack) {
          this.setState({ queuedAnswers: [...this.state.queuedAnswers, answer] });
          return;
        }
        if (!ack.payload?.ok) {
          const snap = await this.ws?.request("snapshot_request", {}, 8e3).catch(() => null);
          if (snap?.type === "snapshot") this.onFrame(snap);
          return;
        }
        if (this.state.confirm?.requestId !== requestId) return;
        this.confirmAnswered = requestId;
        if (answer.decision === "allow") this.setState({ approvals: this.state.approvals + 1 });
        const receipt = answer.decision === "allow" ? "OK - doing it now" : answer.decision === "deny" ? "Got it - I'll find another way" : answer.decision === "done" ? "Thanks - carrying on" : answer.decision === "skip" ? "Skipped - moving on" : "Answer sent";
        this.showReceipt(receipt, () => {
          this.confirmAnswered = null;
          if (this.state.confirm?.requestId !== requestId) return;
          const queue = [...this.state.confirmQueue];
          const next = queue.shift() ?? null;
          this.setState({ confirm: next, confirmQueue: queue });
          this.renderOverlay();
          if (this.state.queuedTask && this.state.conn === "open") {
            const t = this.state.queuedTask;
            this.setState({ queuedTask: null });
            this.submitTask(t);
          }
        }, c.kind === "ask_user" ? 0 : 1500);
      })();
    }
    showReceipt(text, done, ms = 1500) {
      const box = this.el.overlay.querySelector(".receipt");
      if (box) box.textContent = text;
      if (ms <= 0) {
        done();
        return;
      }
      window.setTimeout(done, ms);
    }
    showElement() {
      const c = this.state.confirm;
      if (!c || c.elementIdx === void 0) return;
      this.ws?.emit("highlight", { taskId: c.taskId, idx: c.elementIdx });
    }
    // ---- render scheduling ----
    setState(patch) {
      this.state = { ...this.state, ...patch };
      this.scheduleRender();
    }
    scheduleRender() {
      if (this.renderQueued) return;
      this.renderQueued = true;
      let fired = false;
      const run = () => {
        if (fired) return;
        fired = true;
        if (this.renderFallback !== null) {
          clearTimeout(this.renderFallback);
          this.renderFallback = null;
        }
        this.renderQueued = false;
        this.render();
      };
      requestAnimationFrame(run);
      this.renderFallback = window.setTimeout(run, 250);
    }
    render() {
      this.renderRail();
      this.renderBanners();
      this.renderStream();
      this.renderWorkingRow();
      this.updateJumpButton();
      this.renderOverlay();
      this.renderSheet();
      this.renderHistory();
    }
    applyTheme() {
      document.documentElement.dataset.theme = this.state.settings.theme;
    }
    pushFeed(text, kind = "info") {
      if (!text) return;
      const feed = [...this.state.feed, { ts: Date.now(), text, kind }].slice(-100);
      this.setState({ feed });
    }
    /**
     * Focus the dialog's default button only when the user hasn't put focus
     * anywhere themselves (fresh dialog, focus still on <body>). Never yank focus
     * out of a field the user is typing in, or back from the tab, on a rebuild.
     */
    focusDialogDefault(focus) {
      window.setTimeout(() => {
        if (document.activeElement === document.body) focus();
      }, 30);
    }
    /**
     * Run a DOM rebuild without destroying what the user is doing: snapshot every
     * input/textarea/select value by stable id plus the focused element and its
     * cursor, rebuild, then restore. Callers must give their inputs stable ids.
     */
    preserveInputs(container, build) {
      const active = document.activeElement;
      const activeId = active && active.id && container.contains(active) ? active.id : null;
      const sel = active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement ? { s: active.selectionStart ?? active.value.length, e: active.selectionEnd ?? active.value.length } : null;
      const vals = /* @__PURE__ */ new Map();
      const checks = /* @__PURE__ */ new Map();
      container.querySelectorAll("input, textarea, select").forEach((n) => {
        const e = n;
        if (!e.id || e.dataset.live === "1") return;
        vals.set(e.id, e.value);
        if (e instanceof HTMLInputElement && e.type === "checkbox") checks.set(e.id, e.checked);
      });
      const out = build();
      vals.forEach((v, id) => {
        const n = container.querySelector(`#${CSS.escape(id)}`);
        if (n && n.value !== v) n.value = v;
      });
      checks.forEach((v, id) => {
        const n = container.querySelector(`#${CSS.escape(id)}`);
        if (n && n.type === "checkbox" && n.checked !== v) n.checked = v;
      });
      if (activeId) {
        const n = container.querySelector(`#${CSS.escape(activeId)}`);
        if (n && document.activeElement !== n) {
          n.focus({ preventScroll: true });
          if (sel && (n instanceof HTMLInputElement || n instanceof HTMLTextAreaElement)) {
            try {
              n.setSelectionRange(Math.min(sel.s, n.value.length), Math.min(sel.e, n.value.length));
            } catch {
            }
          }
        }
      }
      return out;
    }
    setSheetError(text) {
      this.setState(text ? { sheetError: text, sheetNotice: void 0 } : { sheetError: void 0 });
      if (!this.el.sheet.hidden) this.renderSheet();
    }
    setHistoryError(text) {
      this.setState({ historyError: text });
      if (!this.el.history.hidden) this.renderHistory();
    }
    /** "Finish or stop this task" errors belong to whichever page is in front. */
    setChatNavError(text) {
      if (!this.el.history.hidden) this.setHistoryError(text);
      else this.setSheetError(text);
    }
    // ================================================================
    //  Shell
    // ================================================================
    buildShell() {
      const rail = this.el.rail;
      rail.innerHTML = "";
      const row = el("div", { class: "rail-row" });
      const brand = el("div", { class: "brand" });
      brand.append(reticle(18));
      const word = el("div", { class: "brand-word" });
      word.append(el("span", { class: "brand-name" }, "Vicaro"));
      brand.append(word);
      const status = el("div", { class: "rail-status", id: "railStatus" });
      status.setAttribute("aria-live", "polite");
      const controls = el("div", { class: "rail-controls", id: "railControls" });
      row.append(brand, status, controls);
      rail.append(row);
      this.el.banners.innerHTML = "";
      this.el.stream.innerHTML = "";
      this.el.overlay.hidden = true;
      this.el.sheet.hidden = true;
      this.el.history.hidden = true;
    }
    renderRail() {
      const st = this.state;
      const box = this.el.rail.querySelector("#railStatus");
      const controls = this.el.rail.querySelector("#railControls");
      if (!box || !controls) return;
      let label = "Ready";
      let cls = "idle";
      let kind = "ready";
      if (st.conn !== "open") {
        label = st.everConnected ? "Reconnecting" : "Connecting";
        cls = "warn";
        kind = "warn";
      } else if (st.chatRunning) {
        const activity = this.workingActivity();
        label = activity === "waiting\u2026" ? "Waiting" : /writ/i.test(activity) ? "Writing" : /verif/i.test(activity) ? "Checking" : /think|respond/i.test(activity) ? "Thinking" : "Acting";
        cls = "running";
        kind = "acting";
      } else if (st.chatPaused) {
        label = "Needs you";
        cls = "amber";
        kind = "needs";
      } else {
        const r = st.rail;
        switch (r.status) {
          case "running":
          case "planning":
          case "queued":
            label = "Running";
            cls = "running";
            kind = "acting";
            break;
          case "waiting_user":
          case "paused":
            label = "Needs you";
            cls = "amber";
            kind = "needs";
            break;
          case "done":
            label = "Done";
            cls = "done";
            kind = "done";
            break;
          case "failed":
            label = "Failed";
            cls = "error";
            kind = "error";
            break;
          case "cancelled":
            label = "Stopped";
            cls = "idle";
            kind = "idle";
            break;
          default:
            label = "Ready";
            cls = "idle";
            kind = "ready";
        }
      }
      box.innerHTML = "";
      const chip = el("span", { class: `state-chip ${kind}` });
      chip.append(el("span", { class: `dot ${cls}` }));
      chip.append(el("span", { class: "status-lead" }, label));
      if (st.chatRunning) chip.title = this.workingActivity();
      box.append(chip);
      const h = st.health;
      box.title = h ? `AI ${h.decision?.healthy ? "ready" : "offline"} \xB7 planner ${h.planner?.healthy ? "ready" : "offline"} \xB7 browser ${h.bridge?.connected ? "ready" : "offline"}${h.planner?.contextWindow ? ` \xB7 ${tokenCount(h.planner.contextWindow)} ctx` : ""}${h.superMode ? " \xB7 super mode on" : h.fullAuto ? " \xB7 full auto on" : ""}` : "Status";
      const controlsKey = [st.conn, st.chatRunning, st.rail.status, st.messages.length, this.conversationId ?? ""].join("|");
      if (controlsKey !== this.railControlsKey) {
        this.railControlsKey = controlsKey;
        controls.innerHTML = "";
        if (st.conn === "open" && st.chatRunning) {
          controls.append(iconBtn("\u25A0", "Stop", () => this.cancelChat(), "danger"));
        } else if (st.conn === "open" && !this.isLive() && (this.state.messages.length > 0 || this.conversationId)) {
          const fresh = el("button", { class: "newchat-btn", title: "Start a new chat (forgets this thread)", "aria-label": "Start a new chat" }, "New chat");
          fresh.onclick = () => this.startNewChat();
          controls.append(fresh);
        }
        controls.append(railAction("\u25F7", "Chats", "Chat history", () => this.openHistory()));
        controls.append(railAction("\u2699", "Settings", "Settings", () => this.toggleSheet(true)));
      }
    }
    openHistory() {
      this.toggleHistory(true);
    }
    async saveRename(conversationId) {
      const title = this.renamingDraft.replace(/\s+/g, " ").trim();
      if (!title) {
        this.setHistoryError("Give the chat a name first.");
        return;
      }
      const ack = await this.ws?.request("chat_rename", { conversationId, title }, 8e3).catch(() => null);
      if (!ack?.payload?.ok) {
        this.setHistoryError(String(ack?.payload?.error ?? "Couldn't rename that chat - reconnecting\u2026"));
        return;
      }
      this.setHistoryError(void 0);
      this.renamingId = null;
      await this.refreshSnapshot();
      this.renderHistory();
    }
    async deleteChat(conversationId) {
      if (conversationId === this.conversationId) {
        this.setHistoryError("Start a new chat before deleting this one.");
        return;
      }
      const ack = await this.ws?.request("chat_delete", { conversationId }, 8e3).catch(() => null);
      if (!ack?.payload?.ok) {
        this.setHistoryError(String(ack?.payload?.error ?? "Couldn't delete that chat - reconnecting\u2026"));
        return;
      }
      this.setHistoryError(void 0);
      this.deletingId = null;
      await this.refreshSnapshot();
      this.renderHistory();
    }
    // ================================================================
    //  Banners
    // ================================================================
    renderBanners() {
      const h = this.state.health;
      const key = [
        this.state.conn,
        h?.halted ? 1 : 0,
        this.state.chatPaused?.turnId ?? "",
        this.state.resumedNotice && !this.noticeDismissed ? 1 : 0,
        this.noticeDismissed ? 1 : 0
      ].join("|");
      if (key === this.bannersKey) return;
      this.bannersKey = key;
      const wrap = this.el.banners;
      wrap.innerHTML = "";
      if (h?.halted) {
        wrap.append(tape("I've paused - my planning helper is offline. Your task is saved and I'll pick it up when it's back.", "amber"));
      }
      if (this.state.conn !== "open" && Date.now() - this.state.connSince >= 1e3) {
        const url = this.state.settings.orchestratorUrl || "ws://127.0.0.1:8790/chrome";
        const why = this.state.connCode === 4409 ? "another window took over this connection" : "the helper app isn't answering";
        const box = tape(`Trying to reach the helper app at ${url} - ${why}.`, "amber");
        const retry = el("button", { class: "btn tiny ghost", type: "button" }, "Retry now");
        retry.onclick = () => void this.reconnect();
        box.append(" ", retry);
        wrap.append(box);
      }
      if (this.state.chatPaused && (!this.conversationId || this.state.chatPaused.conversationId === this.conversationId)) {
        const p = this.state.chatPaused;
        const card = el("div", { class: "notice" });
        card.append(el("div", { class: "notice-title" }, "Turn paused after restart"));
        card.append(el(
          "div",
          { class: "notice-body" },
          `I stopped mid-task${p.goal ? ` (\u201C${truncate(p.goal, 80)}\u201D)` : ""}. Resume only if you want me to continue; otherwise stop it.`
        ));
        const resume = el("button", { class: "btn tiny primary", type: "button" }, "Resume");
        resume.onclick = async () => {
          const ack = await this.ws?.request("chat_resume", { conversationId: p.conversationId }, 8e3).catch(() => null);
          if (ack?.payload?.ok) this.setState({ chatPaused: null });
        };
        const stop = el("button", { class: "btn tiny ghost", type: "button" }, "Stop");
        stop.onclick = () => {
          this.ws?.emit("chat_cancel", { conversationId: p.conversationId });
          this.setState({ chatPaused: null });
        };
        card.append(resume, stop);
        wrap.append(card);
      }
      if (this.state.resumedNotice && !this.noticeDismissed) {
        const card = el("div", { class: "notice" });
        card.append(el("div", { class: "notice-title" }, "Session restarted - task resumed."));
        card.append(el("div", { class: "notice-body" }, "I stopped briefly and picked up where I left off."));
        const dismiss = el("button", { class: "btn tiny ghost" }, "Dismiss");
        dismiss.onclick = () => {
          this.noticeDismissed = true;
          this.setState({ resumedNotice: false });
        };
        card.append(dismiss);
        wrap.append(card);
      }
    }
    // ================================================================
    //  Stream
    // ================================================================
    rebuildStream() {
      this.preserveInputs(this.el.stream, () => {
        this.el.stream.innerHTML = "";
        if (this.state.firstRun) {
          this.el.stream.classList.remove("empty");
          this.el.stream.append(this.buildFirstRun());
          return;
        }
        const hasMessages = this.state.messages.length > 0;
        const idleRail = this.state.rail.status === "idle";
        const empty = !hasMessages && !this.state.live && !this.state.chatRunning && this.state.feed.length === 0 && idleRail;
        this.el.stream.classList.toggle("empty", empty);
        if (empty) {
          this.el.stream.append(this.buildHero());
          this.el.stream.append(this.buildConsole());
          return;
        }
        if (!hasMessages && !this.state.live && !this.state.chatRunning && this.state.feed.length === 0 && !idleRail) {
          this.el.stream.append(this.buildTaskStatusCard());
          this.el.stream.append(this.buildConsole());
          this.scrollChatToBottom();
          return;
        }
        for (const m of this.state.messages) this.el.stream.append(this.buildMessageRow(m));
        if (this.state.live) this.el.stream.append(this.buildLiveTurn());
        if (this.state.feed.length > 0) this.el.stream.append(this.buildFeedBox());
        if (this.state.queuedTask) this.el.stream.append(this.systemRow("I'll send this as soon as we're reconnected."));
        this.el.stream.append(this.buildConsole());
        this.scrollChatToBottom();
      });
    }
    /** One stored transcript message: user bubble or assistant bubble (+ tool chips). */
    buildMessageRow(m) {
      if (m.role === "user") {
        const row2 = this.chatRow("user");
        const wrap = el("div", { class: "user-msg" });
        const meta2 = el("div", { class: "user-meta" });
        meta2.append(el("span", { class: "you" }, "You"));
        if (m.createdAt) {
          meta2.append(el("span", { class: "dot-sep" }, "\xB7"));
          meta2.append(el("span", {}, new Date(m.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })));
        }
        wrap.append(meta2);
        if (this.editingId === m.id) {
          const box = el("div", { class: "inline-edit" });
          const ta = el("textarea", { class: "inline-edit-input", rows: "2" });
          ta.value = this.editingDraft || m.text;
          ta.addEventListener("input", () => {
            this.editingDraft = ta.value;
          });
          ta.addEventListener("keydown", (ev) => {
            if (ev.key === "Enter" && !ev.shiftKey) {
              ev.preventDefault();
              this.saveEdit(m);
            } else if (ev.key === "Escape") {
              ev.preventDefault();
              this.cancelEdit();
            }
          });
          box.append(ta);
          const actions = el("div", { class: "inline-edit-actions" });
          const cancel = el("button", { class: "btn tiny ghost" }, "Cancel");
          cancel.onclick = () => this.cancelEdit();
          const save = el("button", { class: "btn tiny primary" }, "Save & send");
          save.onclick = () => this.saveEdit(m);
          actions.append(cancel, save);
          box.append(actions);
          wrap.append(box);
          row2.append(wrap);
          window.setTimeout(() => {
            ta.focus();
            ta.setSelectionRange(ta.value.length, ta.value.length);
          }, 20);
          return row2;
        }
        const bubble2 = el("div", { class: "bubble bubble-user" });
        if (m.images?.length) {
          const box = el("div", { class: "bubble-images" });
          for (const src of m.images) box.append(el("img", { src, alt: "attached image" }));
          bubble2.append(box);
        }
        if (m.text) bubble2.append(el("span", {}, m.text));
        wrap.append(bubble2);
        if (!this.state.chatRunning) {
          const actions = el("div", { class: "msg-actions" });
          const edit = el("button", { class: "msg-action", title: "Edit this message and resend", "aria-label": "Edit message" }, "\u270E");
          edit.onclick = () => this.startEdit(m);
          const again = el("button", { class: "msg-action", title: "Send this message again", "aria-label": "Resend message" }, "\u21BB");
          again.onclick = () => this.resendMessage(m);
          actions.append(edit, again);
          wrap.append(actions);
        }
        row2.append(wrap);
        return row2;
      }
      const row = this.chatRow("agent");
      const bubble = el("div", { class: "bubble bubble-agent assistant" });
      const meta = el("div", { class: "assistant-meta" });
      meta.append(el("span", { class: "rule" }), el("span", {}, "Vicaro"));
      if (m.createdAt) {
        meta.append(el("span", { class: "dot-sep" }, "\xB7"));
        meta.append(el("span", {}, new Date(m.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })));
      }
      bubble.append(meta);
      if (m.parts && m.parts.length) {
        bubble.append(this.buildParts(m.parts, false));
      } else {
        if (m.reasoning) bubble.append(this.buildThinkBox(m.reasoning, false));
        if (m.text) {
          const text = el("div", { class: "msg-text" });
          text.append(renderMarkdown(m.text));
          bubble.append(text);
        }
        const fallbackTools = (m.tools ?? []).filter((t) => t.name !== "finish");
        if (fallbackTools.length) bubble.append(this.buildToolGroup(fallbackTools));
      }
      const perf = m.metrics?.perf;
      const bits = [];
      let ctx = null;
      if (perf) {
        const mark = perf.live ? "~" : "";
        if (perf.decodeTps) bits.push(`${mark}${tps(perf.decodeTps)} tok/s`);
        if (perf.prefillTps) bits.push(`prefill ${mark}${tps(perf.prefillTps)} tok/s`);
        ctx = this.contextPct(perf);
        if (ctx !== null) bits.push(`ctx ${mark}${percent(ctx)}`);
        if (perf.turnTokens) bits.push(`${tokenCount(perf.turnTokens)} tok`);
      }
      const stop = m.metrics?.stopReason;
      const stopNote = stop === "stopped" ? "stopped early" : stop === "blocker" ? "blocked" : stop === "error" ? "error" : "";
      const isLast = this.state.messages[this.state.messages.length - 1]?.id === m.id;
      const hasFeed = isLast && this.state.feed.length > 0;
      if (bits.length || hasFeed || stopNote) {
        const footer = el("div", { class: "msg-footer" });
        if (hasFeed) {
          const details = el("button", { class: "msg-details", type: "button" }, "Details");
          details.onclick = () => {
            this.feedCollapsed = false;
            this.rebuildStream();
            this.render();
          };
          footer.append(details);
        }
        footer.append(el("span", { class: "spacer" }));
        if (stopNote) {
          footer.append(el("span", {
            class: `stop-badge ${stop}`,
            title: stop === "stopped" ? "The turn was cancelled before it finished (Stop, a newer message, or a dropped model stream)." : stop === "blocker" ? "The agent hit a blocker and could not continue." : "The model call failed."
          }, stopNote));
        }
        if (bits.length) {
          const metrics = el("span", { class: "metrics mono", title: perf ? this.perfTitle(perf, m.metrics?.contextChars) : void 0 }, bits.join(" \xB7 "));
          if (ctx !== null && ctx >= 80) metrics.classList.add("near-limit");
          footer.append(metrics);
        }
        bubble.append(footer);
      }
      row.append(bubble);
      return row;
    }
    /** Ordered transcript: text, thinking, and grouped tool runs. Consecutive tool
     *  calls become one collapsible row instead of a wall of chips. */
    buildParts(parts, live) {
      const frag = document.createDocumentFragment();
      const ordered = parts;
      let run = [];
      const flush = () => {
        if (!run.length) return;
        frag.append(run.length === 1 ? this.buildToolChip(run[0]) : this.buildToolGroup(run));
        run = [];
      };
      for (let i = 0; i < ordered.length; i++) {
        const part = ordered[i];
        if (part.type === "tool" && part.tool) {
          if (part.tool.name === "finish") {
            flush();
            continue;
          }
          run.push(part.tool);
          continue;
        }
        flush();
        const isLast = i === ordered.length - 1;
        if (part.type === "text" && part.text) {
          const text = el("div", { class: "msg-text", "data-part-index": String(i) });
          text.append(renderMarkdown(part.text));
          if (live && isLast && this.state.chatRunning) appendStreamCaret(text);
          frag.append(text);
        } else if (part.type === "reasoning" && part.text) {
          const think = this.buildThinkBox(part.text, live, live && isLast && this.state.chatRunning);
          think.dataset.partIndex = String(i);
          frag.append(think);
        }
      }
      flush();
      return frag;
    }
    /**
     * The model's thoughts: expanded and streaming while the turn is live, a
     * collapsed "Thoughts" toggle on stored messages. Rendered as markdown.
     */
    buildThinkBox(text, live, streaming = false) {
      const box = el("details", { class: `think-box${live ? " live" : ""}` });
      box.open = streaming;
      const words = wordCount(text);
      const label = words >= 1e3 ? `${(words / 1e3).toFixed(1)}k words` : `${words} word${words === 1 ? "" : "s"}`;
      box.append(el("summary", {}, streaming ? "Thinking\u2026" : `Thoughts \xB7 ${label}`));
      const body = el("div", { class: "think-text" });
      body.append(renderMarkdown(text));
      if (streaming) appendStreamCaret(body);
      box.append(body);
      return box;
    }
    /** The streaming turn: thoughts + text fill in as deltas arrive; chips per tool call. */
    buildLiveTurn() {
      const row = this.chatRow("agent");
      const bubble = el("div", { class: "bubble bubble-agent assistant live" });
      const meta = el("div", { class: "assistant-meta" });
      meta.append(el("span", { class: "rule" }), el("span", {}, "Vicaro"), el("span", { class: "dot-sep" }, "\xB7"), el("span", {}, "now"));
      bubble.append(meta);
      bubble.append(el("div", { class: "live-parts" }));
      row.append(bubble);
      return row;
    }
    buildToolGroup(tools) {
      const key = tools[0]?.callId ?? "group";
      const box = el("details", { class: "tool-group trace" });
      box.open = this.openToolGroups.has(key);
      box.addEventListener("toggle", () => {
        if (box.open) this.openToolGroups.add(key);
        else this.openToolGroups.delete(key);
      });
      const totalMs = tools.reduce((sum, t) => sum + (t.ms ?? 0), 0);
      const duration = totalMs >= 1e3 ? `${(totalMs / 1e3).toFixed(1)}s` : `${Math.round(totalMs)}ms`;
      const head = el("summary", { class: "trace-head" });
      head.append(el("span", { class: "chev" }, "\u25B8"));
      head.append(el("span", { class: "trace-title" }, `Trace \xB7 ${tools.length} action${tools.length === 1 ? "" : "s"} \xB7 ${duration}`));
      box.append(head);
      const body = el("div", { class: "trace-body" });
      for (const t of tools) body.append(this.buildToolChip(t));
      box.append(body);
      return box;
    }
    buildToolChip(t, count = 1) {
      const state = t.ok === void 0 ? "running" : t.ok ? "ok" : "failed";
      const row = el("div", { class: `tool-chip trace-row ${state}` });
      row.append(el("span", { class: "trace-mark mono" }, state === "ok" ? "\u2713" : state === "failed" ? "\u2715" : "\u2192"));
      const body = el("span", { class: "trace-copy" });
      body.append(el("span", { class: "trace-name" }, t.name.replace(/_/g, " ")));
      body.append(el("span", { class: "trace-summary" }, truncate(t.summary, 64)));
      row.append(body);
      if (count > 1) row.append(el("span", { class: "tool-count mono" }, `\xD7${count}`));
      if (t.ms !== void 0) row.append(el("span", { class: "trace-ms mono" }, `${Math.round(t.ms)}ms`));
      if (t.image) {
        const thumbSrc = `data:image/jpeg;base64,${t.image}`;
        const previewSrc = t.preview ? `data:image/jpeg;base64,${t.preview}` : thumbSrc;
        const img = el("img", { class: "tool-thumb", src: thumbSrc, alt: "screenshot" });
        img.onclick = (ev) => {
          ev.stopPropagation();
          const expanded = img.classList.toggle("expanded");
          img.src = expanded ? previewSrc : thumbSrc;
        };
        row.append(img);
      }
      if (t.result || t.args) {
        row.classList.add("has-detail");
        row.onclick = () => {
          const existing = row.querySelector(".tool-detail");
          if (existing) {
            existing.remove();
            row.classList.remove("expanded");
            return;
          }
          row.classList.add("expanded");
          row.append(this.buildToolDetail(t, state));
        };
      }
      return row;
    }
    /** Human-readable expanded body for one tool call. */
    buildToolDetail(t, state) {
      const box = el("div", { class: `tool-detail ${state}` });
      box.onclick = (ev) => ev.stopPropagation();
      const head = el("div", { class: "tool-detail-head" });
      head.append(el("span", { class: "tool-detail-title" }, t.name.replace(/_/g, " ")));
      const status = el(
        "span",
        { class: `tool-detail-state ${state}` },
        state === "ok" ? "completed" : state === "failed" ? "failed" : "running"
      );
      head.append(status);
      if (t.ms !== void 0) head.append(el("span", { class: "tool-detail-ms" }, `${Math.round(t.ms)}ms`));
      box.append(head);
      const args = t.args && typeof t.args === "object" && !Array.isArray(t.args) ? t.args : null;
      if (args && Object.keys(args).length) {
        box.append(el("div", { class: "tool-detail-section" }, "Input"));
        const list = el("div", { class: "tool-kv-list" });
        for (const [key, value] of Object.entries(args)) {
          const kv = el("div", { class: "tool-kv" });
          kv.append(el("span", { class: "tool-k" }, key));
          const text = typeof value === "string" ? value : JSON.stringify(value);
          kv.append(el("span", { class: "tool-v" }, truncate(text ?? "", 420)));
          list.append(kv);
        }
        box.append(list);
      }
      if (t.result) {
        box.append(el("div", { class: "tool-detail-section" }, "Output"));
        const pre = el("pre", { class: "tool-output" });
        pre.textContent = prettyDetailText(t.result);
        box.append(pre);
      } else if (!args) {
        box.append(el("div", { class: "tool-detail-empty" }, "No captured input or output."));
      }
      return box;
    }
    renderStream() {
      if (!this.el.stream.dataset.built || this.streamStructureChanged()) {
        this.rebuildStream();
        this.el.stream.dataset.built = "1";
        this.el.stream.dataset.signature = this.streamSignature();
        this.applyComposerText();
      }
      this.renderLive();
      this.renderFeed();
    }
    /** In-place streaming update: no rebuild on text deltas, so typing, clicks on
     *  tool chips, open groups and text selection all survive the stream. */
    renderLive() {
      const live = this.state.live;
      const bubble = this.el.stream.querySelector(".bubble-agent.live");
      if (!bubble) return;
      bubble.classList.toggle("provisional", !!live?.draft);
      const partsBox = bubble.querySelector(".live-parts");
      if (partsBox && live) {
        const parts = live.parts ?? [];
        const sig = parts.map((p, i) => p.type === "tool" ? `tool:${p.tool.callId}:${p.tool.ok}:${p.tool.ms ?? ""}:${p.tool.image ? 1 : 0}` : `${p.type}:${i}`).join("|") + (this.state.chatRunning ? "|run" : "|idle");
        if (partsBox.dataset.struct !== sig) {
          partsBox.dataset.struct = sig;
          partsBox.innerHTML = "";
          partsBox.append(this.buildParts(parts, true));
          partsBox.dataset.textSig = parts.map((p) => p.type === "text" || p.type === "reasoning" ? p.text?.length ?? 0 : 0).join(",");
        } else {
          this.syncLiveParts(partsBox, parts);
        }
        partsBox.querySelectorAll(".think-text").forEach((n) => {
          n.scrollTop = n.scrollHeight;
        });
      }
      if (live || this.state.chatRunning) this.scrollChatToBottom();
    }
    /** Update only the changed text/thinking nodes inside the live bubble. */
    syncLiveParts(partsBox, parts) {
      const textSig = parts.map((p) => p.type === "text" || p.type === "reasoning" ? p.text?.length ?? 0 : 0).join(",");
      if (partsBox.dataset.textSig === textSig) return;
      partsBox.dataset.textSig = textSig;
      for (let i = 0; i < parts.length; i++) {
        const part = parts[i];
        if (part.type !== "text" && part.type !== "reasoning") continue;
        if (!part.text) continue;
        const node = partsBox.querySelector(`[data-part-index="${i}"]`);
        if (!node) continue;
        const target = part.type === "text" ? node : node.querySelector(".think-text");
        if (!target) continue;
        target.innerHTML = "";
        target.append(renderMarkdown(part.text));
        if (this.state.chatRunning && i === parts.length - 1) appendStreamCaret(target);
      }
    }
    streamSignature() {
      return [
        this.state.firstRun,
        this.state.rail.status,
        this.state.rail.taskText ?? "",
        this.state.messages.length,
        this.state.messages.at(-1)?.id ?? 0,
        this.state.live ? 1 : 0,
        this.state.chatRunning,
        this.state.queuedTask ? 1 : 0,
        this.state.feed.length > 0 ? 1 : 0,
        this.conversationId ?? "",
        this.editingId ?? "",
        // Context percentages are derived from the effective budget (provider
        // window or the pinned setting), which can arrive/change after the
        // transcript was first painted.
        this.state.health?.planner?.contextWindow ?? 0,
        this.state.health?.chat?.contextTokens ?? 0,
        this.state.health?.chat?.followProviderWindow ? 1 : 0
      ].join("|");
    }
    streamStructureChanged() {
      return this.el.stream.dataset.signature !== this.streamSignature();
    }
    // ---- chat transcript helpers ----
    // Rows are plain divs (chat-row user|agent|system); cards inside keep their
    // legacy classes/ids (planBox, scratchBox, task-chip, result-card …) so the
    // e2e harnesses keep working — only the arrangement is chat-like.
    chatRow(kind) {
      return el("div", { class: `chat-row ${kind}` });
    }
    agentRow(...kids) {
      const row = this.chatRow("agent");
      const bubble = el("div", { class: "bubble bubble-agent" });
      bubble.append(...kids);
      row.append(bubble);
      return row;
    }
    systemRow(text) {
      const row = this.chatRow("system");
      row.append(el("div", { class: "bubble bubble-system mono" }, text));
      return row;
    }
    /** A short assistant aside in the transcript ("On it — making a plan…"). */
    narrationRow(text) {
      const row = this.chatRow("agent");
      row.append(el("div", { class: "narration" }, text));
      return row;
    }
    scrollChatToBottom(force = false) {
      if (force) this.chatPinned = true;
      if (!this.chatPinned) return;
      if (this.scrollTimer !== null) return;
      this.scrollTimer = window.setTimeout(() => {
        this.scrollTimer = null;
        try {
          this.el.stream.scrollTop = this.el.stream.scrollHeight;
        } catch {
        }
        this.updateJumpButton();
      }, 30);
    }
    updateJumpButton() {
      const b = this.el.stream.querySelector(".jump-latest");
      if (!b) return;
      const s = this.el.stream;
      const overflow = s.scrollHeight > s.clientHeight + 60;
      b.hidden = !overflow || this.chatPinned;
    }
    /** One status at a time: the running tool, the phase, or the last tool while
     *  the model thinks. "thinking…" is only a fallback when nothing else is known;
     *  the pulsing dot already signals that work is in progress. */
    workingActivity() {
      const activity = String(this.state.chatActivity ?? "").trim();
      const last = String(this.state.chatLastTool ?? "").trim();
      if (activity === "reasoning\u2026") return "thinking\u2026";
      if (!activity || /^thinking…?$/i.test(activity)) return last || "waiting\u2026";
      return activity;
    }
    renderWorkingRow() {
      const line = this.el.stream.querySelector("#workingLine");
      if (!line) return;
      const text = this.el.stream.querySelector("#workingText");
      if (!text) return;
      text.textContent = truncate(this.workingActivity(), 64);
      const elapsed2 = this.el.stream.querySelector("#workingElapsed");
      if (elapsed2) elapsed2.textContent = this.state.chatStartedAt ? elapsedCompact(this.state.chatStartedAt) : "";
      const perfEl = this.el.stream.querySelector("#workingPerf");
      if (!perfEl) return;
      const perf = this.state.chatPerf;
      const bits = [];
      const mark = perf?.live ? "~" : "";
      if (perf?.decodeTps) bits.push(`${mark}${tps(perf.decodeTps)} tok/s`);
      if (perf?.prefillTps) bits.push(`prefill ${mark}${tps(perf.prefillTps)} tok/s`);
      const ctx = this.contextPct(perf);
      if (ctx !== null) bits.push(`ctx ${mark}${percent(ctx)}`);
      perfEl.textContent = bits.join(" \xB7 ");
      perfEl.hidden = bits.length === 0;
      perfEl.classList.toggle("near-limit", ctx !== null && ctx >= 80);
      if (perf) {
        perfEl.title = this.perfTitle(perf);
        perfEl.classList.toggle("live", !!perf.live);
      }
    }
    /** Context percentages use the budget this turn actually runs with: the
     *  provider window when followed, otherwise the pinned Settings → Context size.
     *  Older messages were measured against a different denominator; the live
     *  setting must win so a 6.7k-token prompt cannot look like 33% of 256k when
     *  the user pinned 20k. */
    contextLimit(perf) {
      const chat = this.state.health?.chat;
      const provider = this.state.health?.planner?.contextWindow;
      if (chat) {
        if (typeof chat.effectiveTokens === "number" && chat.effectiveTokens > 0) return chat.effectiveTokens;
        if (chat.followProviderWindow && provider && provider > 0) return provider;
        if (chat.contextTokens > 0) return chat.contextTokens;
      }
      if (provider && provider > 0) return provider;
      const fallback = perf?.contextLimit;
      return typeof fallback === "number" && fallback > 0 ? fallback : void 0;
    }
    /** Share of the current model context window used by this model round. */
    contextPct(perf) {
      const limit = this.contextLimit(perf);
      if (!perf?.promptTokens || !limit) return null;
      return perf.promptTokens / limit * 100;
    }
    /** Hover detail for throughput chips: token counts, TTFT, cache hits, model time. */
    perfTitle(perf, contextChars) {
      const detail = [];
      if (perf.ttftMs) detail.push(`TTFT ${(perf.ttftMs / 1e3).toFixed(2)}s`);
      if (perf.prefillTokens) detail.push(`prefill ${tokenCount(perf.prefillTokens)} tok`);
      if (perf.promptTokens) detail.push(`prompt ${tokenCount(perf.promptTokens)} tok`);
      if (perf.promptTokens && contextChars) {
        const messageTokens = Math.ceil(contextChars / 4);
        const toolTokens = Math.max(0, perf.promptTokens - messageTokens);
        if (toolTokens > 150) detail.push(`tool schemas \u2248${tokenCount(toolTokens)} tok`);
      }
      if (perf.completionTokens) detail.push(`generated ${tokenCount(perf.completionTokens)} tok`);
      if (perf.cachedTokens) detail.push(`${tokenCount(perf.cachedTokens)} cached`);
      const limit = this.contextLimit(perf);
      if (limit && perf.promptTokens) {
        detail.push(`context ${tokenCount(perf.promptTokens)} / ${tokenCount(limit)} tok (${percent(this.contextPct(perf))})`);
      }
      if (perf.contextBudget && perf.contextBudget !== limit) detail.push(`turn budget ${tokenCount(perf.contextBudget)} tok`);
      const source = this.state.health?.planner?.contextSource ?? perf.contextSource;
      if (source) detail.push(source);
      if (perf.turnTokens) detail.push(`turn ${tokenCount(perf.turnTokens)} tok`);
      if (perf.turnMs) detail.push(`${(perf.turnMs / 1e3).toFixed(1)}s model time`);
      return detail.join(" \xB7 ") || "Model speed";
    }
    buildUserRow(taskText) {
      const row = this.chatRow("user");
      const live = this.isLive();
      if (live) {
        const chip = el("div", { class: "task-chip" });
        const state_ = this.state.rail.status === "waiting_user" ? "needs-you" : this.state.rail.status === "paused" ? "paused" : "live";
        chip.append(el("span", { class: `chip-dot ${state_}` }));
        chip.append(el("span", { class: "chip-text" }, `"${truncate(taskText, 120)}"`));
        row.append(chip);
      } else {
        const bubble = el("div", { class: "bubble bubble-user" });
        bubble.append(el("span", {}, taskText));
        row.append(bubble);
      }
      return row;
    }
    /** One remembered turn: past user message + what came of it. Plain bubbles —
     *  deliberately NOT .task-chip/.ledger/.tl-step (those belong to the live task). */
    buildTurnRow(t) {
      const frag = el("div", { class: "turn" });
      const urow = this.chatRow("user");
      const ub = el("div", { class: "bubble bubble-user past" });
      ub.append(el("span", {}, t.task));
      urow.append(ub);
      frag.append(urow);
      const arow = this.chatRow("agent");
      const ab = el("div", { class: "bubble bubble-agent past" });
      if (t.status === "done" && t.resultSummary) {
        ab.append(el("span", {}, t.resultSummary));
      } else if (t.status === "done") {
        ab.append(el("span", { class: "dim" }, "Done."));
      } else if (t.status === "failed") {
        ab.append(el("span", { class: "dim" }, t.resultSummary ? `Couldn't finish - ${t.resultSummary}` : "Couldn't finish that one."));
      } else if (t.status === "cancelled") {
        ab.append(el("span", { class: "dim" }, "Stopped."));
      } else {
        ab.append(el("span", { class: "dim" }, "In progress\u2026"));
      }
      arow.append(ab);
      frag.append(arow);
      return frag;
    }
    buildFailedCard() {
      const card = el("div", { class: "failed-card" });
      card.append(el("div", { class: "card-label", style: "margin:0 0 4px" }, "SORRY ABOUT THAT"));
      card.append(el("div", {}, "I couldn't finish that one."));
      if (this.state.rail.detail) card.append(el("div", { class: "hint tight" }, this.state.rail.detail));
      card.append(el("div", { class: "hint tight" }, "Try describing it a little differently, then send it again below."));
      return card;
    }
    buildTaskStatusCard() {
      const r = this.state.rail;
      const card = el("section", { class: "task-status-card live-task" });
      const task = el("div", { class: "task-head" });
      const label = r.status === "done" ? "DONE" : r.status === "failed" ? "FAILED" : r.status === "cancelled" ? "STOPPED" : "CURRENT TASK";
      task.append(el("div", { class: "eyebrow" }, label));
      task.append(el("h2", { class: "task-title" }, r.taskText ? truncate(r.taskText, 180) : "Working on your request\u2026"));
      const meta = [];
      if (r.step !== void 0) meta.push(`Step ${r.step}${r.totalSteps ? ` of ${r.totalSteps}` : ""}`);
      if (r.startedAt) meta.push(elapsedCompact(r.startedAt, r.finishedAt ?? Date.now()));
      if (r.status === "paused") meta.push("Paused");
      if (r.status === "waiting_user") meta.push("Waiting on you");
      if (r.detail) meta.push(truncate(r.detail, 52));
      if (meta.length) {
        const line = el("div", { class: "task-meta" });
        meta.forEach((bit, i) => {
          if (i) line.append(el("span", { class: "sep" }));
          line.append(el("span", {}, bit));
        });
        task.append(line);
      }
      const total = r.totalSteps ?? this.state.plan?.steps.length ?? 0;
      const step = r.step ?? 0;
      if (total > 0 || step > 0) {
        const segments = Math.min(Math.max(total || 5, 1), 8);
        const progress = el("div", { class: "progress" });
        const current = Math.max(0, Math.min(segments - 1, (step || 1) - 1));
        for (let i = 0; i < segments; i++) {
          const seg = el("i");
          if (i < current) seg.classList.add("done");
          else if (i === current && (r.status === "running" || r.status === "planning")) seg.classList.add("now");
          progress.append(seg);
        }
        task.append(progress);
      }
      card.append(task);
      const nowText = r.status === "waiting_user" || r.status === "paused" ? "Waiting for you" : r.detail ? truncate(r.detail, 80) : r.status === "done" ? "Task complete" : "Working on the next action\u2026";
      const now = el("div", { class: "now-line" });
      now.append(el("span", { class: "pulse" }));
      now.append(el("span", {}, nowText));
      if (r.startedAt) now.append(el("span", { class: "mono" }, elapsedCompact(r.startedAt, r.finishedAt ?? Date.now())));
      card.append(now);
      const rows = this.state.scratch.slice(-4);
      const trace = el("div", { class: "live-trace" });
      rows.forEach((row) => {
        const item = el("div", { class: `live-step ${row.ok ? "done" : "failed"}` });
        item.append(el("span", { class: "node" }, row.ok ? "\u2713" : "\u2715"));
        const body = el("span", { class: "body" });
        body.append(el("span", { class: "cmd" }, truncate(row.summary || row.action, 80)));
        const sub = row.reason ? truncate(row.reason, 80) : row.tier ? `${row.tier} tier` : "";
        if (sub) body.append(el("span", { class: "sub" }, sub));
        item.append(body, el("span", { class: "time" }, `${Math.round(row.latencyMs)}ms`));
        trace.append(item);
      });
      if (!rows.length && r.status !== "done" && r.status !== "failed" && r.status !== "cancelled") {
        const item = el("div", { class: "live-step now" });
        item.append(el("span", { class: "node" }, "\u2192"));
        const body = el("span", { class: "body" });
        body.append(el("span", { class: "cmd" }, "Preparing the first action\u2026"));
        body.append(el("span", { class: "sub" }, "Reading the page and checking what is available"));
        item.append(body, el("span", { class: "time" }, "now"));
        trace.append(item);
      }
      if (trace.childElementCount) card.append(trace);
      return card;
    }
    buildHero() {
      const hero = el("section", { class: "hero" });
      hero.append(el("div", { class: "eyebrow" }, "Your browser, in good hands"));
      const title = el("h2", { class: "hero-title" });
      title.append("Ask me");
      title.append(el("br"));
      title.append("anything");
      title.append(el("span", { class: "stop" }, "."));
      hero.append(title);
      hero.append(el("p", { class: "hero-sub" }, "I can see your tabs and act on them. Ask about this page, or tell me what to do."));
      const context = el("div", { class: "context-line" });
      const count = this.state.tabContext?.count;
      context.append(el("span", {}, count !== void 0 ? `${count} tab${count === 1 ? "" : "s"} open` : "Tabs ready"));
      context.append(el("span", { class: "sep" }));
      const access = this.state.pageAccess === false ? "Page access off" : "Page access on";
      context.append(el("span", { class: this.state.pageAccess === false ? "warn" : "ok" }, access));
      context.append(el("span", { class: "sep" }));
      context.append(el("span", {}, `This tab: ${this.tabContextLabel()}`));
      hero.append(context);
      const suggestions = el("div", { class: "suggestions" });
      SUGGESTIONS.forEach((s, i) => {
        const row = el("button", { class: "suggestion", type: "button", title: s.title });
        row.append(el("span", { class: "idx" }, String(i + 1).padStart(2, "0")));
        const copy = el("span", { class: "suggestion-copy" });
        copy.append(el("span", { class: "label" }, s.title));
        copy.append(el("span", { class: "hint" }, s.hint));
        row.append(copy, el("span", { class: "go" }, "\u203A"));
        row.onclick = () => {
          this.composerText = s.title;
          const ta = document.querySelector(".composer");
          if (ta) {
            ta.value = s.title;
            ta.focus();
          } else {
            this.submitTask(s.title);
          }
        };
        suggestions.append(row);
      });
      hero.append(suggestions);
      const foot = el("div", { class: "hero-foot" });
      foot.append(el("span", {}, "Recent"), el("span", { class: "line" }));
      const recent = this.state.conversations?.[0];
      if (recent) {
        const chip = el("button", { class: "recent-chat", type: "button" }, truncate(recent.title ?? recent.lastTask ?? "Open past chats", 48));
        chip.onclick = () => this.openHistory();
        foot.append(chip);
      } else {
        foot.append(el("span", {}, "Ready when you are"));
      }
      hero.append(foot);
      return hero;
    }
    buildFirstRun() {
      const card = el("section", { class: "card first-run" });
      const head = el("div", { class: "first-run-head" });
      head.append(reticle(26));
      const ht = el("div", {});
      ht.append(el("h2", {}, "Let's get you connected"));
      ht.append(el("p", { class: "hint tight" }, "Your helper runs on this computer. Click Connect below and you're off."));
      head.append(ht);
      card.append(head);
      const label = el("label", { class: "field-label" }, "Helper address");
      const input = el("input", { class: "input mono", id: "firstrun-url", value: this.state.settings.orchestratorUrl, spellcheck: "false" });
      const err = el("div", { class: "error-line" });
      const btn = el("button", { class: "btn primary wide" }, "Connect");
      btn.onclick = async () => {
        const url = input.value.trim();
        if (!/^wss?:\/\//.test(url)) {
          err.textContent = "That address doesn't look right - it should start with ws://.";
          return;
        }
        await setSettings({ orchestratorUrl: url });
        await this.reconnect();
      };
      card.append(label, input, btn, err);
      card.append(el("p", { class: "hint" }, "Not working? First start the helper app on your Mac, then press Connect."));
      return card;
    }
    buildConsole() {
      const dock = el("section", { class: "card console dock" });
      const running = this.state.chatRunning;
      const busy = running || this.isLive();
      if (running) {
        const line = el("div", { class: "working-line", id: "workingLine" });
        const main = el("div", { class: "working-main" });
        main.append(el("span", { class: "status-dot running" }));
        main.append(el("span", { class: "working-text", id: "workingText" }, truncate(this.workingActivity(), 64)));
        main.append(el("span", { class: "working-elapsed mono", id: "workingElapsed" }, ""));
        const perf = el("div", { class: "working-perf mono", id: "workingPerf", hidden: "" }, "");
        line.append(main, perf);
        dock.append(line);
      }
      if (this.state.pageAccess === false && !this.accessDismissed) dock.append(this.buildAccessNotice());
      const noTabs = this.state.tabContext?.count === 0;
      const context = el("div", { class: "composer-context" });
      context.append(el("span", { class: noTabs || this.state.pageAccess === false ? "dot warn" : "dot" }));
      if (noTabs) {
        context.append(el("span", { class: "tab warn" }, this.noTabsError || "No tabs in this window"));
        if (!this.noTabsError) {
          const openTab = el("button", {
            class: "open-tab",
            type: "button",
            title: "Open a tab in this Chrome window so the assistant can work here"
          }, "Open a tab");
          openTab.onclick = () => {
            void this.openTabInWindow();
          };
          context.append(openTab);
        }
      } else {
        context.append(el("span", { class: "tab" }, this.tabContextLabel()));
      }
      context.append(el("span", { class: "spacer" }));
      context.append(el("span", { class: "kbd" }, "\u21B5"));
      dock.append(context);
      const ta = el("textarea", {
        class: "composer",
        id: "composer-input",
        rows: "1",
        placeholder: busy ? "Steer or interrupt\u2026" : "Ask anything\u2026",
        "aria-label": "Message Vicaro",
        title: "Enter to send \xB7 Shift+Enter for a new line"
      });
      ta.value = this.composerText;
      ta.addEventListener("input", () => {
        this.composerText = ta.value;
        ta.style.height = "auto";
        ta.style.height = Math.min(ta.scrollHeight, 130) + "px";
      });
      ta.addEventListener("keydown", (ev) => {
        if (ev.key === "Enter" && !ev.shiftKey) {
          ev.preventDefault();
          this.submitTask(ta.value);
        }
      });
      ta.addEventListener("paste", (ev) => {
        const items = ev.clipboardData?.items;
        if (!items) return;
        const files = [];
        for (const it of Array.from(items)) {
          if (it.kind === "file" && it.type.startsWith("image/")) {
            const f = it.getAsFile();
            if (f) files.push(f);
          }
        }
        if (!files.length) return;
        ev.preventDefault();
        void this.attachImages(files);
      });
      if (this.pendingImages.length) dock.append(this.buildAttachRow());
      const fileInput = el("input", { type: "file", accept: "image/*", multiple: "true", style: "display:none" });
      fileInput.onchange = () => {
        const files = Array.from(fileInput.files ?? []);
        fileInput.value = "";
        if (files.length) void this.attachImages(files);
      };
      const attach = el("button", { class: "attach-btn", type: "button", title: "Add attachment", "aria-label": "Add attachment" }, "\u{1F4CE}");
      attach.onclick = () => fileInput.click();
      dock.append(fileInput);
      const row = el("div", { class: "dock-row" });
      const submit = el("button", {
        class: `btn primary dock-send ${running ? "stop" : ""}`,
        "aria-label": running ? "Stop" : "Send message"
      }, running ? "\u25A0" : "\u2191");
      submit.title = running ? "Stop the current turn" : "Send (Enter)";
      submit.onclick = running ? () => this.cancelChat() : () => this.submitTask(ta.value);
      row.append(attach, ta, submit);
      dock.append(row);
      dock.addEventListener("dragover", (ev) => {
        ev.preventDefault();
        dock.classList.add("drop-target");
      });
      dock.addEventListener("dragleave", () => dock.classList.remove("drop-target"));
      dock.addEventListener("drop", (ev) => {
        ev.preventDefault();
        dock.classList.remove("drop-target");
        const files = Array.from(ev.dataTransfer?.files ?? []).filter((f) => f.type.startsWith("image/"));
        if (files.length) void this.attachImages(files);
      });
      const jump = el("button", { class: "jump-latest", type: "button", hidden: "" }, "Jump to latest \u2193");
      jump.onclick = () => {
        this.chatPinned = true;
        this.scrollChatToBottom(true);
        this.updateJumpButton();
      };
      dock.append(jump);
      if (document.activeElement === document.body) window.setTimeout(() => {
        if (document.activeElement === document.body) ta.focus();
      }, 50);
      if (this.state.queuedTask) dock.append(el("div", { class: "queued-chip" }, "I'll send this as soon as we're reconnected"));
      if (this.state.conn === "closed") dock.append(el("div", { class: "error-line" }, "I can't reach the helper app - start it on your Mac and I'll retry."));
      return dock;
    }
    /** One-time, non-alarming page-access prompt (never styled as an error). */
    buildAccessNotice() {
      const row = el("div", { class: "permission-row" });
      row.append(el("span", { class: "permission-dot" }));
      row.append(el("span", { class: "permission-text" }, "Page access is off."));
      const allow = el("button", { class: "btn tiny primary", type: "button", title: "Let Vicaro read and act on the sites you open" }, "Allow");
      allow.onclick = () => this.requestPageAccess();
      const later = el("button", { class: "btn tiny ghost", type: "button" }, "Later");
      later.onclick = () => {
        this.accessDismissed = true;
        this.scheduleRender();
      };
      row.append(allow, later);
      return row;
    }
    buildResultCard() {
      const card = el("div", { class: "result-card" });
      const head = el("div", { class: "result-head" });
      head.append(el("span", { class: "card-label", style: "margin:0" }, "HERE'S WHAT I FOUND"));
      const again = el("button", { class: "btn tiny ghost" }, "Run again");
      again.onclick = () => {
        const text = this.state.rail.taskText ?? this.sentTaskText ?? "";
        this.composerText = text;
        const ta = this.el.stream.querySelector(".composer");
        if (ta) {
          ta.value = text;
          ta.style.height = "auto";
          ta.style.height = Math.min(ta.scrollHeight, 130) + "px";
          ta.focus();
        } else {
          this.scheduleRender();
          window.setTimeout(() => {
            const retry = this.el.stream.querySelector(".composer");
            if (retry) {
              retry.value = text;
              retry.focus();
            }
          }, 60);
        }
      };
      head.append(again);
      card.append(head);
      card.append(this.buildResultBody(this.state.rail.result));
      const stats = el("div", { class: "result-stats" });
      const elapsed2 = this.state.rail.startedAt ? elapsed(this.state.rail.startedAt, this.state.rail.finishedAt ?? Date.now()) : "-";
      const steps = this.state.scratch.filter((r) => r.action !== "plan").length;
      stats.append(el("span", {}, `Took ${elapsed2} \xB7 ${steps} steps`));
      if (this.state.approvals > 0) stats.append(el("span", { class: "dim" }, "\xB7"), el("span", {}, `you confirmed ${this.state.approvals} thing${this.state.approvals === 1 ? "" : "s"}`));
      card.append(stats);
      return card;
    }
    /** Friendly result readout: key facts as readable rows, links as buttons. */
    buildResultBody(result) {
      const wrap = el("div", { class: "result-body" });
      if (result === null || result === void 0 || result === "") {
        wrap.append(el("div", { class: "hint tight" }, "All done - nothing extra to show."));
        return wrap;
      }
      if (typeof result === "string") {
        wrap.append(el("div", { class: "result-text" }, result.slice(0, 1200)));
        return wrap;
      }
      if (typeof result === "object") {
        const entries = Object.entries(result).slice(0, 12);
        for (const [k, v] of entries) {
          const row = el("div", { class: "result-row" });
          row.append(el("span", { class: "result-key" }, friendlyKey(k)));
          if (typeof v === "string" && /^https?:\/\//.test(v)) {
            const a = el("a", { class: "result-link", href: v, target: "_blank", rel: "noreferrer" }, "Open link");
            row.append(a);
            row.title = v;
          } else if (typeof v === "object") {
            row.append(el("span", { class: "result-val" }, truncate(JSON.stringify(v), 120)));
          } else {
            row.append(el("span", { class: "result-val" }, truncate(String(v), 140)));
          }
          wrap.append(row);
        }
        const details = el("details", { class: "result-raw" });
        details.append(el("summary", {}, "Show all details"));
        let pretty;
        try {
          pretty = JSON.stringify(result, null, 2);
        } catch {
          pretty = String(result);
        }
        details.append(el("pre", { class: "result-json mono" }, pretty.slice(0, 1200)));
        wrap.append(details);
        return wrap;
      }
      wrap.append(el("div", { class: "result-text" }, truncate(String(result), 600)));
      return wrap;
    }
    applyComposerText() {
      const ta = this.el.stream.querySelector(".composer");
      if (!ta) return;
      if (this.composerText) {
        ta.value = this.composerText;
        ta.style.height = "auto";
        ta.style.height = Math.min(ta.scrollHeight, 130) + "px";
      } else if (ta.value) {
        ta.value = "";
        ta.style.height = "auto";
      }
    }
    buildPlanBox() {
      const box = el("section", { class: "card plan-box chat-card", id: "planBox" });
      const head = el("div", { class: "chat-card-head" });
      const total = this.state.plan?.steps.length ?? this.state.rail.totalSteps;
      const step = this.state.rail.step;
      const progress = total && step && this.isLive() ? ` \xB7 step ${step} of ${total}` : total ? ` \xB7 ${total} steps` : "";
      const title = el("div", { class: "card-label", style: "margin:0" });
      title.append(el("span", {}, "MY PLAN"));
      if (progress) title.append(el("span", { class: "dim" }, progress));
      head.append(title);
      const toggle = el("button", { class: "btn tiny ghost" }, this.planCollapsed ? "show" : "hide");
      toggle.onclick = () => {
        this.planCollapsed = !this.planCollapsed;
        toggle.textContent = this.planCollapsed ? "show" : "hide";
        const body2 = box.querySelector("#planBody");
        if (body2) body2.hidden = this.planCollapsed;
      };
      head.append(toggle);
      box.append(head);
      const body = el("div", { class: "plan-body", id: "planBody" });
      body.hidden = !!this.planCollapsed && this.state.rail.status === "done";
      box.append(body);
      return box;
    }
    renderPlan() {
      const body = this.el.stream.querySelector("#planBody");
      if (!body) return;
      body.innerHTML = "";
      const st = this.state;
      if (!st.plan) {
        if (st.rail.status === "planning" || st.rail.status === "queued") {
          body.append(el("div", { class: "planning" }, "Making your plan\u2026 one moment."));
          for (let i = 0; i < 4; i++) body.append(el("div", { class: "skeleton" }));
        }
        return;
      }
      if (st.planAnnotation) body.append(el("div", { class: "annotation" }, `I changed the plan - ${st.planAnnotation}`));
      const current = Number(st.rail.step ?? 1);
      const list = el("ol", { class: "timeline" });
      st.plan.steps.forEach((s, i) => {
        const idx = i + 1;
        const done = idx < current || st.rail.status === "done";
        const isCurrent = idx === current && st.rail.status !== "done";
        const failedState = isCurrent ? st.stepStates[current] && st.stepStates[current].ok === false ? st.stepStates[current] : void 0 : void 0;
        const li = el("li", { class: "tl-step" });
        if (done) li.classList.add("done");
        if (isCurrent) {
          li.classList.add("current");
          li.setAttribute("aria-current", "step");
        }
        if (failedState && isCurrent) li.classList.add("failed");
        if (st.planReplaceFrom !== void 0 && i >= st.planReplaceFrom) li.classList.add("replanned");
        const node = el("span", { class: "tl-node mono" }, done ? "\u2713" : failedState && isCurrent ? "\u2715" : String(idx));
        const desc = el("div", { class: "tl-desc" }, s.description);
        li.append(node, desc);
        li.title = `Done when: ${s.successCriterion}`;
        if (failedState && isCurrent && failedState.error) {
          li.append(el("div", { class: "tl-error mono" }, `Hmm - ${failedState.error} (I'll try another way)`));
        }
        li.onclick = () => {
          li.classList.toggle("expanded");
          let detail = li.querySelector(".tl-detail");
          if (!detail) {
            detail = el("div", { class: "tl-detail" }, `Done when: ${s.successCriterion}`);
            li.append(detail);
          } else detail.remove();
        };
        list.append(li);
      });
      body.append(list);
    }
    buildScratchBox() {
      const box = el("section", { class: "card scratch-box chat-card", id: "scratchBox" });
      const head = el("div", { class: "scratch-head chat-card-head" });
      head.append(el("div", { class: "card-label", style: "margin:0" }, "WHAT I'M DOING"));
      const actions = el("div", { class: "scratch-actions" });
      const toggle = el("button", { class: "btn tiny ghost" }, this.scratchExpanded ? "less" : "more");
      toggle.onclick = () => {
        this.scratchExpanded = !this.scratchExpanded;
        this.renderScratch();
        toggle.textContent = this.scratchExpanded ? "less" : "more";
      };
      actions.append(toggle);
      head.append(actions);
      box.append(head);
      const now = this.currentStepText();
      if (now) box.append(el("div", { class: "activity-now" }, now));
      box.append(el("div", { class: "scratch-body", id: "scratchBody" }));
      return box;
    }
    /** "Now looking at the cheapest listing…" — plan step or last action, plain. */
    currentStepText() {
      const st = this.state;
      if (!this.isLive()) return null;
      const idx = Number(st.rail.step ?? 1);
      const desc = st.plan?.steps[idx - 1]?.description;
      if (desc) return `Now: ${desc.charAt(0).toLowerCase()}${desc.slice(1)}\u2026`;
      const last = st.scratch[st.scratch.length - 1];
      if (last?.summary) return `Working on it\u2026 ${truncate(last.summary, 80)}`;
      return "Working on it\u2026";
    }
    renderScratch() {
      const body = this.el.stream.querySelector("#scratchBody");
      if (!body) return;
      body.innerHTML = "";
      const st = this.state;
      if (st.scratch.length === 0) {
        if (this.isLive()) for (let i = 0; i < 3; i++) body.append(el("div", { class: "skeleton thin" }));
        return;
      }
      const rows = this.scratchExpanded ? st.scratch.slice(-100) : st.scratch.slice(-5);
      if (st.compressedCount > 0) {
        body.append(el("div", { class: "compress-line" }, `\u2026 plus ${st.compressedCount} earlier steps`));
      }
      for (const r of rows) {
        if (r.action === "plan") {
          const row2 = el("div", { class: "ledger plan-row" });
          row2.append(el("span", { class: "lg-step mono" }, "\u2713"), el("span", { class: "lg-summary" }, truncate(r.summary.replace(/^✓ /, ""), 60)));
          body.append(row2);
          continue;
        }
        const row = el("div", { class: "ledger" });
        if (!r.ok) row.classList.add("failed");
        row.append(
          el("span", { class: "lg-step mono" }, String(r.step)),
          el("span", { class: `lg-tier mono t-${r.tier === "L3" ? "l3" : "l1"}` }, r.tier ?? "L1"),
          el("span", { class: "lg-summary" }, truncate(r.summary, 52)),
          el("span", { class: "lg-margin mono", title: "page-kind classifier margin" }, margin(r.margin)),
          el("span", { class: "lg-latency mono" }, r.latencyMs ? `${Math.round(r.latencyMs)}ms` : "-")
        );
        row.onclick = () => {
          row.classList.toggle("expanded");
          let detail = row.querySelector(".lg-detail");
          if (!detail) {
            const what = `${r.action}${r.reason ? ` - ${r.reason}` : ""}`;
            detail = el("div", { class: "lg-detail mono" }, what);
            row.append(detail);
          } else detail.remove();
        };
        body.append(row);
      }
    }
    buildFeedBox() {
      const box = el("details", { class: "feed-box chat-log", id: "feedBox" });
      box.open = !this.feedCollapsed;
      box.addEventListener("toggle", () => {
        this.feedCollapsed = !box.open;
      });
      const head = el("summary", { class: "feed-head" });
      head.append(el("span", {}, "Details"));
      head.append(el("span", { class: "feed-count mono" }, `${this.state.feed.length} entr${this.state.feed.length === 1 ? "y" : "ies"}`));
      box.append(head);
      box.append(el("div", { class: "feed-body", id: "feedBody" }));
      return box;
    }
    renderFeed() {
      const body = this.el.stream.querySelector("#feedBody");
      if (!body) return;
      body.innerHTML = "";
      for (const f of this.state.feed.slice(-20)) {
        const line = el("div", { class: `feed-item ${f.kind} mono` });
        line.append(el("span", { class: "feed-time" }, new Date(f.ts).toLocaleTimeString([], { hour12: false })), el("span", { class: "feed-text" }, f.text));
        body.append(line);
      }
    }
    // ================================================================
    //  Confirm overlay
    // ================================================================
    renderOverlay() {
      const c = this.state.confirm;
      const box = this.el.overlay;
      if (!c) {
        box.hidden = true;
        box.innerHTML = "";
        this.lastOverlayKey = null;
        this.syncConfirmSpace();
        return;
      }
      const key = JSON.stringify([c.requestId, c.kind, c.question, c.target, c.note, c.pageChanged, c.choices, c.action, c.elementIdx, (c.evidence ?? []).length]);
      if (key === this.lastOverlayKey && box.querySelector(".confirm")) {
        const w = box.querySelector(".confirm-waiting");
        const waiting = c.waitingSec && c.waitingSec > 0 ? `still waiting - asked ${Math.floor(c.waitingSec / 60)}m ${c.waitingSec % 60}s ago` : null;
        if (w && waiting) w.textContent = waiting;
        else if (!w && waiting) box.querySelector(".confirm")?.append(el("div", { class: "confirm-waiting mono" }, waiting));
        else if (w && !waiting) w.remove();
        this.syncConfirmSpace();
        return;
      }
      this.lastOverlayKey = key;
      this.preserveInputs(box, () => this.buildOverlayDialog(c));
      this.syncConfirmSpace();
    }
    /** The sheet covers the dock, so reserve its measured height at the bottom of
     *  the transcript. The answer the dialog is asking about must stay readable
     *  above it instead of sliding behind it, and the composer (which the sheet
     *  replaces) is hidden while it waits. */
    syncConfirmSpace() {
      const open = !this.el.overlay.hidden;
      const wasOpen = this.el.app.classList.contains("confirm-open");
      this.el.app.classList.toggle("confirm-open", open);
      if (!open) {
        this.el.app.style.removeProperty("--confirm-space");
        if (wasOpen) this.scrollChatToBottom();
        return;
      }
      const h = Math.ceil(this.el.overlay.getBoundingClientRect().height);
      if (h > 0) this.el.app.style.setProperty("--confirm-space", `${h}px`);
      if (!wasOpen) this.chatPinned = true;
      this.scrollChatToBottom();
    }
    /** Human-facing verb for the confirmation dialog. */
    confirmVerb(c) {
      const s = `${c.action?.name ?? ""} ${c.action?.summary ?? ""} ${c.target ?? ""}`.toLowerCase();
      if (/delete|remove|trash/.test(s)) return { title: "Delete this?", allow: "Delete", destructive: true };
      if (/send|reply|email|message/.test(s)) return { title: "Send this?", allow: "Send", destructive: true };
      if (/pay|purchase|buy|order|checkout/.test(s)) return { title: "Complete this purchase?", allow: "Pay", destructive: true };
      if (/submit|confirm|post|publish|apply/.test(s)) return { title: "Submit this?", allow: "Continue", destructive: true };
      if (/^shell_run/.test(s)) return { title: "Run this command?", allow: "Run", destructive: false };
      if (/^fs_write/.test(s)) return { title: "Write this file?", allow: "Write", destructive: false };
      return { title: c.question ?? "Do this action?", allow: "Continue", destructive: false };
    }
    buildOverlayDialog(c) {
      const box = this.el.overlay;
      box.hidden = false;
      box.innerHTML = "";
      const dialog = el("div", { class: "confirm", role: "alertdialog", "aria-modal": "true", "aria-live": "assertive" });
      dialog.dataset.requestId = c.requestId;
      const waiting = c.waitingSec && c.waitingSec > 0 ? `${Math.floor(c.waitingSec / 60)}m ${c.waitingSec % 60}s` : null;
      if (c.kind === "confirm") {
        const plannerAsk = !c.action?.name;
        const verb = this.confirmVerb(c);
        if (verb.destructive) dialog.classList.add("destructive");
        dialog.append(el("div", { class: `confirm-stripe ${c.pageChanged ? "changed" : ""}` }));
        dialog.append(el("div", { class: "confirm-kicker" }, plannerAsk ? "QUICK CHECK" : "CONFIRM ACTION"));
        const head = el("div", { class: "confirm-head" });
        head.append(el("span", { class: "confirm-obj" }, plannerAsk ? c.question ?? "Go ahead with the next step?" : verb.title));
        dialog.append(head);
        if (!plannerAsk && c.action?.summary) dialog.append(el("div", { class: "confirm-action-summary" }, c.action.summary));
        if (c.target) dialog.append(el("div", { class: "confirm-target" }, `Target: ${c.target}`));
        const localNote = c.action?.name === "shell_run" ? "This runs on your computer with your user permissions. Nothing has started yet." : c.action?.name === "fs_write" ? "This writes to a file on your computer. Nothing has been written yet." : "This can't be undone. Nothing has happened yet.";
        dialog.append(el(
          "div",
          { class: "confirm-note" },
          plannerAsk ? "I paused so you can decide - nothing is running while I wait." : localNote
        ));
        if (c.pageChanged) dialog.append(el("div", { class: "confirm-warning" }, "The page changed since I asked - I'm double-checking before anything happens."));
        if (c.note) dialog.append(el("div", { class: "confirm-note" }, c.note));
        const chips = el("div", { class: "chips" });
        for (const e of c.evidence ?? []) {
          if (/pre[_\s-]?filter/i.test(e.label)) continue;
          const chip = el("span", { class: "chip" });
          chip.append(el("span", { class: "chip-k mono" }, friendlyEvidence(e.label)));
          chip.append(el("span", { class: "chip-v mono" }, friendlyEvidenceValue(e.label, e.value)));
          if (e.detail) chip.title = e.detail;
          chips.append(chip);
        }
        if (chips.childElementCount) dialog.append(chips);
        const row = el("div", { class: "confirm-actions" });
        const deny = el("button", { class: "btn big deny" }, "Cancel");
        deny.onclick = () => this.answerConfirm({ decision: "deny" });
        const allow = el("button", { class: "btn big allow" }, verb.allow);
        allow.onclick = () => this.answerConfirm({ decision: "allow" });
        row.append(deny, allow);
        dialog.append(row);
        const sub = el("div", { class: "confirm-sub" });
        sub.append(el("span", {}, "Nothing happens until you choose."));
        if (c.elementIdx !== void 0) {
          const show = el("button", { class: "btn tiny" }, "Show me where");
          show.onclick = () => this.showElement();
          sub.append(show);
        }
        dialog.append(sub);
        dialog.append(el("div", { class: "receipt" }));
        window.setTimeout(() => {
          if (this.state.confirm?.requestId === c.requestId) deny.focus();
        }, 30);
      } else if (c.kind === "handoff") {
        dialog.append(el("div", { class: "confirm-stripe handoff" }));
        dialog.append(el("div", { class: "confirm-kicker" }, "I NEED YOUR HELP"));
        dialog.append(el("div", { class: "confirm-head" }, `${c.question?.startsWith("A CAPTCHA") ? "A quick check needs you" : "A sign-in needs you"}`));
        dialog.append(el("div", { class: "confirm-body" }, c.question ?? "Please do this part on the page - I'll wait right here."));
        const row = el("div", { class: "confirm-actions" });
        const done = el("button", { class: "btn big allow" }, "I've done it - continue");
        done.onclick = () => this.answerConfirm({ decision: "done" });
        const skip = el("button", { class: "btn big" }, "Skip this step");
        skip.onclick = () => this.answerConfirm({ decision: "skip" });
        row.append(done, skip);
        dialog.append(row);
        this.focusDialogDefault(() => done.focus());
      } else {
        dialog.append(el("div", { class: "confirm-stripe ask" }));
        dialog.append(el("div", { class: "confirm-kicker" }, "QUICK QUESTION"));
        dialog.append(el("div", { class: "confirm-head" }, c.question ?? "How should I continue?"));
        if (c.note) dialog.append(el("div", { class: "confirm-note" }, c.note));
        const row = el("div", { class: "confirm-actions col" });
        (c.choices ?? []).forEach((choice, i) => {
          const b = el("button", { class: "btn choice" }, choice);
          b.onclick = () => this.answerConfirm({ decision: "choice", choiceIndex: i });
          row.append(b);
        });
        const free = el("div", { class: "free-row" });
        const input = el("input", { class: "input", id: "ask-free", placeholder: "Or type your own answer" });
        const send = el("button", { class: "btn" }, "Send");
        send.onclick = () => {
          if (input.value.trim()) this.answerConfirm({ decision: "choice", text: input.value.trim() });
        };
        input.addEventListener("keydown", (ev) => {
          if (ev.key === "Enter") send.click();
        });
        free.append(input, send);
        dialog.append(row, free);
        const abort = el("button", { class: "btn tiny danger" }, "Stop the whole task");
        abort.onclick = () => this.answerConfirm({ decision: "abort" });
        dialog.append(abort);
        this.focusDialogDefault(() => row.querySelector("button")?.focus());
      }
      if (waiting) dialog.append(el("div", { class: "confirm-waiting mono" }, `still waiting - asked ${waiting} ago`));
      dialog.addEventListener("keydown", (ev) => {
        if (ev.key === "Escape" && this.state.confirm?.kind === "confirm") {
          ev.preventDefault();
          this.answerConfirm({ decision: "deny" });
          return;
        }
        if (ev.key !== "Tab") return;
        const focusable = Array.from(dialog.querySelectorAll("button, input, textarea, select, [tabindex]:not([tabindex='-1'])")).filter((n) => !n.hasAttribute("disabled") && n.offsetParent !== null);
        if (!focusable.length) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (ev.shiftKey && document.activeElement === first) {
          ev.preventDefault();
          last.focus();
        } else if (!ev.shiftKey && document.activeElement === last) {
          ev.preventDefault();
          first.focus();
        }
      });
      box.append(dialog);
    }
    // ================================================================
    //  Chat history page
    // ================================================================
    /** Full-page history view. Settings and history are mutually exclusive so the
     *  rail never stacks two full-height surfaces. */
    toggleHistory(open, returnFocus = true) {
      if (open) {
        if (!this.el.sheet.hidden) this.toggleSheet(false);
        this.renamingId = null;
        this.deletingId = null;
        this.el.history.hidden = false;
        this.setState({ historyError: void 0 });
        this.renderHistory(true);
        void this.refreshSnapshot();
        window.setTimeout(() => {
          if (this.el.history.hidden) return;
          this.el.history.querySelector("#chat-search")?.focus({ preventScroll: true });
        }, 40);
        return;
      }
      const hadFocus = !this.el.history.hidden && this.el.history.contains(document.activeElement);
      this.el.history.hidden = true;
      this.lastHistorySig = null;
      if (hadFocus && returnFocus) {
        window.setTimeout(() => {
          this.el.rail.querySelector('button[title="Chat history"]')?.focus({ preventScroll: true });
        }, 0);
      }
    }
    renderHistory(force = false) {
      if (this.el.history.hidden) {
        this.lastHistorySig = null;
        return;
      }
      const sig = JSON.stringify([
        this.historyQuery,
        this.renamingId ?? "",
        this.deletingId ?? "",
        this.state.historyError ?? "",
        this.conversationId ?? "",
        (this.state.conversations ?? []).map((c) => `${c.id}:${c.turnCount}:${c.updatedAt}:${c.title ?? ""}:${c.lastSnippet ?? ""}`)
      ]);
      if (!force && sig === this.lastHistorySig) return;
      this.lastHistorySig = sig;
      this.preserveInputs(this.el.history, () => this.buildHistory());
    }
    buildHistory() {
      const page = this.el.history;
      page.innerHTML = "";
      const all = this.state.conversations ?? [];
      const head = el("div", { class: "history-head" });
      const back = iconBtn("\u2190", "Back to chat", () => this.toggleHistory(false), "history-back");
      const heading = el("div", { class: "history-heading" });
      heading.append(el("h3", {}, "Chat history"));
      heading.append(el(
        "div",
        { class: "history-count mono" },
        all.length ? `${all.length} recent chat${all.length === 1 ? "" : "s"}` : "Nothing saved yet"
      ));
      head.append(back, heading);
      const newBtn = el("button", { class: "btn tiny primary history-new" }, "New chat");
      newBtn.onclick = () => this.startNewChat();
      head.append(newBtn);
      page.append(head);
      const q = this.historyQuery.trim().toLowerCase();
      const filtered = q ? all.filter((c) => `${c.title ?? c.lastTask} ${c.lastSnippet ?? ""} ${c.lastTask}`.toLowerCase().includes(q)) : all;
      const searchbar = el("div", { class: "history-searchbar" });
      searchbar.append(magnifier(14, "history-search-icon"));
      const search = el("input", {
        class: "input history-search",
        id: "chat-search",
        type: "search",
        placeholder: "Search chats",
        "aria-label": "Search chats",
        value: this.historyQuery,
        autocomplete: "off",
        spellcheck: "false"
      });
      search.addEventListener("input", () => {
        this.historyQuery = search.value;
        this.renderHistory();
      });
      searchbar.append(search);
      if (this.historyQuery) {
        const clear = iconBtn("\xD7", "Clear search", () => this.clearHistorySearch(), "history-search-clear");
        searchbar.append(clear);
      }
      page.append(searchbar);
      if (this.state.historyError) page.append(el("div", { class: "error-line history-error", role: "status" }, this.state.historyError));
      const scroll = el("div", { class: "history-scroll" });
      if (!all.length) {
        scroll.append(this.buildHistoryEmpty());
      } else if (!filtered.length) {
        const empty = el("div", { class: "history-empty search-empty" });
        const mark = el("div", { class: "history-empty-mark" });
        mark.append(magnifier(15));
        empty.append(mark);
        empty.append(el("h4", { class: "history-empty-title" }, "No chats match that search"));
        empty.append(el("p", { class: "hint" }, `Nothing here matches "${truncate(this.historyQuery.trim(), 40)}".`));
        const clear = el("button", { class: "btn tiny ghost" }, "Clear search");
        clear.onclick = () => this.clearHistorySearch();
        empty.append(clear);
        scroll.append(empty);
      } else {
        if (q) scroll.append(el(
          "div",
          { class: "history-result-count mono" },
          `${filtered.length} match${filtered.length === 1 ? "" : "es"} in ${all.length} recent chat${all.length === 1 ? "" : "s"}`
        ));
        const now = /* @__PURE__ */ new Date();
        const startOfDay = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
        const today = startOfDay(now);
        const yesterday = startOfDay(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1));
        const week = startOfDay(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6));
        const groups = [
          ["Today", filtered.filter((c) => c.updatedAt >= today)],
          ["Yesterday", filtered.filter((c) => c.updatedAt >= yesterday && c.updatedAt < today)],
          ["Previous 7 days", filtered.filter((c) => c.updatedAt >= week && c.updatedAt < yesterday)],
          ["Earlier", filtered.filter((c) => c.updatedAt < week)]
        ];
        for (const [label, items] of groups) {
          if (!items.length) continue;
          const group = el("section", { class: "history-group" });
          const groupHead = el("div", { class: "history-group-head" });
          groupHead.append(el("span", { class: "history-group-label mono" }, label));
          groupHead.append(el("span", { class: "history-group-rule" }));
          groupHead.append(el("span", { class: "history-group-count mono" }, String(items.length)));
          group.append(groupHead);
          for (const c of items) group.append(this.buildHistoryRow(c));
          scroll.append(group);
        }
      }
      scroll.append(el("div", { class: "history-foot mono" }, "Chats are saved by your helper."));
      page.append(scroll);
    }
    /** Clear the search field without preserveInputs restoring the old value. */
    clearHistorySearch() {
      const input = this.el.history.querySelector("#chat-search");
      if (input) input.value = "";
      this.historyQuery = "";
      this.renderHistory();
      this.el.history.querySelector("#chat-search")?.focus({ preventScroll: true });
    }
    buildHistoryEmpty() {
      const box = el("div", { class: "history-empty" });
      box.append(el("div", { class: "history-empty-mark mono" }, "\u25F7"));
      box.append(el("h4", { class: "history-empty-title" }, "No chats yet"));
      box.append(el("p", { class: "hint" }, "Start a conversation and it will be saved here."));
      const start = el("button", { class: "btn primary" }, "Start a chat");
      start.onclick = () => this.startNewChat();
      box.append(start);
      return box;
    }
    buildHistoryRow(c) {
      const title = (c.title ?? c.lastTask ?? "Untitled chat").replace(/\s+/g, " ").trim() || "Untitled chat";
      const snippet = (c.lastSnippet ?? "").replace(/\s+/g, " ").trim();
      const isCurrent = c.id === this.conversationId;
      const wrap = el("div", { class: `chat-pick-wrap history-item${isCurrent ? " current" : ""}` });
      if (this.renamingId === c.id) {
        const input = el("input", { class: "input chat-rename-input", id: `rename-${c.id}`, value: this.renamingDraft, maxlength: "80" });
        input.addEventListener("input", () => {
          this.renamingDraft = input.value;
        });
        input.addEventListener("keydown", (ev) => {
          if (ev.key === "Enter") {
            ev.preventDefault();
            void this.saveRename(c.id);
          } else if (ev.key === "Escape") {
            ev.preventDefault();
            ev.stopPropagation();
            this.renamingId = null;
            this.renderHistory();
          }
        });
        const save = el("button", { class: "btn tiny primary" }, "Save");
        save.onclick = () => void this.saveRename(c.id);
        const cancel = el("button", { class: "btn tiny ghost" }, "Cancel");
        cancel.onclick = () => {
          this.renamingId = null;
          this.renderHistory();
        };
        wrap.append(input, save, cancel);
        window.setTimeout(() => {
          input.focus();
          input.select();
        }, 20);
        return wrap;
      }
      if (this.deletingId === c.id) {
        const ask = el("div", { class: "chat-delete-confirm" });
        ask.append(el("span", { class: "chat-delete-text" }, `Delete "${truncate(title, 34)}"?`));
        const cancel = el("button", { class: "btn tiny ghost" }, "Cancel");
        cancel.onclick = () => {
          this.deletingId = null;
          this.renderHistory();
        };
        const del = el("button", { class: "btn tiny danger" }, "Delete");
        del.onclick = () => void this.deleteChat(c.id);
        ask.append(cancel, del);
        wrap.append(ask);
        return wrap;
      }
      const row = el("button", {
        class: "chat-pick",
        title: isCurrent ? "Return to this chat" : `Open this chat (${c.turnCount} request${c.turnCount === 1 ? "" : "s"})`
      });
      const top = el("span", { class: "chat-pick-top" });
      top.append(el("span", { class: "chat-pick-text" }, truncate(title, 72)));
      if (isCurrent) top.append(el("span", { class: "chat-current mono" }, "Current"));
      top.append(el("span", { class: "chat-pick-arrow" }, isCurrent ? "\u21A9" : "\u2197"));
      row.append(top);
      if (snippet && snippet !== title) row.append(el("span", { class: "chat-pick-snippet" }, truncate(snippet, 96)));
      const meta = el("span", { class: "chat-pick-meta mono" });
      meta.append(`${c.turnCount} request${c.turnCount === 1 ? "" : "s"}`);
      meta.append(el("span", { class: "chat-pick-sep" }, "\xB7"));
      meta.append(shortWhen(c.updatedAt));
      row.append(meta);
      row.onclick = () => this.viewConversation(c.id);
      const actions = el("div", { class: "chat-pick-actions" });
      const rename = iconBtn("\u270E", "Rename chat", () => {
        this.renamingId = c.id;
        this.renamingDraft = title;
        this.deletingId = null;
        this.renderHistory();
      });
      actions.append(rename);
      if (!isCurrent) {
        const del = iconBtn("\xD7", "Delete chat", () => {
          this.deletingId = c.id;
          this.renamingId = null;
          this.renderHistory();
        }, "danger");
        actions.append(del);
      }
      wrap.append(row, actions);
      return wrap;
    }
    // ================================================================
    //  Settings sheet
    // ================================================================
    toggleSheet(open) {
      const hadFocus = !open && !this.el.sheet.hidden && this.el.sheet.contains(document.activeElement);
      if (open) {
        this.el.history.hidden = true;
        this.lastHistorySig = null;
        this.showApiKey = false;
        this.advancedOpen = false;
        void this.loadMcpHosts();
        void this.loadCapabilities();
      }
      this.el.sheet.hidden = !open;
      this.el.sheetBackdrop.hidden = !open;
      if (open) {
        this.el.sheet.scrollTop = 0;
        this.setState({ sheetError: void 0, sheetNotice: void 0 });
        void this.refreshSnapshot();
        this.renderSheet();
        window.setTimeout(() => {
          if (this.el.sheet.hidden) return;
          this.el.sheet.querySelector("#settings-back")?.focus({ preventScroll: true });
        }, 30);
      } else {
        this.showApiKey = false;
        if (hadFocus) {
          window.setTimeout(() => {
            this.el.rail.querySelector('button[title="Settings"]')?.focus({ preventScroll: true });
          }, 0);
        }
      }
    }
    /** Pull a fresh snapshot (chat list, pending confirm, health) on demand. */
    async refreshSnapshot() {
      const snap = await this.ws?.request("snapshot_request", this.conversationId ? { conversationId: this.conversationId } : {}, 8e3).catch(() => null);
      if (snap?.type === "snapshot") this.onFrame(snap);
    }
    renderSheet() {
      if (this.el.sheet.hidden) {
        this.lastSheetSig = null;
        return;
      }
      const h = this.state.health;
      const sig = JSON.stringify([
        this.state.settings.orchestratorUrl,
        this.state.settings.bearer ?? "",
        this.state.settings.theme,
        this.state.conn,
        this.state.everConnected,
        h?.decision?.healthy ?? null,
        h?.planner?.healthy ?? null,
        h?.bridge?.connected ?? null,
        h?.fullAuto ?? null,
        h?.superMode ?? null,
        h?.localAccess ?? null,
        h?.skills ?? null,
        h?.chat ?? null,
        h?.llm?.baseUrl ?? null,
        h?.llm?.apiKey ?? null,
        h?.llm?.mainModel ?? null,
        h?.llm?.decisionModel ?? null,
        h?.planner?.contextWindow ?? null,
        h?.planner?.contextSource ?? null,
        this.llmModels.join(""),
        this.mcpHosts ? this.mcpHosts.map((h2) => `${h2.id}:${h2.exists}:${h2.installed}`).join(",") : "none",
        this.mcpError ?? "",
        this.state.pageAccess,
        `${this.caps.cdp}:${this.caps.history}`,
        this.state.sheetError ?? "",
        this.state.sheetNotice ?? "",
        this.showApiKey ? 1 : 0,
        this.advancedOpen ? 1 : 0
      ]);
      if (sig === this.lastSheetSig) return;
      this.lastSheetSig = sig;
      const scrollTop = this.el.sheet.scrollTop;
      this.preserveInputs(this.el.sheet, () => this.buildSheet());
      this.el.sheet.scrollTop = scrollTop;
    }
    healthLine() {
      const h = this.state.health;
      if (!h) return "Checking the helper\u2026";
      const ok = [h.decision?.healthy, h.planner?.healthy, h.bridge?.connected];
      if (ok.every(Boolean)) return "Everything's working";
      const bad = [];
      if (!h.decision?.healthy) bad.push("decision helper");
      if (!h.planner?.healthy) bad.push("planning helper");
      if (!h.bridge?.connected) bad.push("browser link");
      if (!bad.length) return "Everything's working";
      return `Waiting on ${bad.length > 1 ? `${bad.slice(0, -1).join(", ")} and ${bad[bad.length - 1]}` : bad[0]}`;
    }
    buildSheet() {
      const sheet = this.el.sheet;
      sheet.innerHTML = "";
      const top = el("div", { class: "settings-top" });
      const topRow = el("div", { class: "settings-top-row" });
      const back = iconBtn("\u2190", "Back to chat", () => this.toggleSheet(false), "settings-back");
      back.id = "settings-back";
      topRow.append(back);
      topRow.append(el("span", { class: "settings-top-label mono" }, "Settings"));
      topRow.append(el("span", { class: "settings-top-rule" }));
      top.append(topRow);
      const feedback = this.settingsFeedback();
      if (feedback) top.append(feedback);
      sheet.append(top);
      const body = el("div", { class: "settings-body" });
      const hero = el("section", { class: "settings-hero" });
      hero.append(el("div", { class: "settings-eyebrow mono" }, "CALIBRATION"));
      const title = el("h2", { class: "settings-title" });
      title.append("Tune the");
      title.append(el("br"));
      title.append("instrument");
      title.append(el("span", { class: "stop" }, "."));
      hero.append(title);
      hero.append(el("p", { class: "settings-sub" }, "Permissions, appearance, and the model behind the panel. Changes apply as you save them."));
      hero.append(this.buildSettingsContext());
      body.append(hero);
      body.append(this.buildAccessCard());
      body.append(this.buildAppearanceCard());
      body.append(this.buildAutonomyCard());
      body.append(this.buildLocalCard());
      body.append(this.buildMcpCard());
      body.append(this.buildSkillsCard());
      body.append(this.buildModelsCard());
      body.append(this.buildContextCard());
      body.append(this.buildHelperCard());
      const foot = el("div", { class: "settings-foot mono" });
      foot.append(el("span", {}, "Vicaro"), el("span", { class: "settings-foot-rule" }), el("span", {}, "Settings are saved by your helper"));
      body.append(foot);
      sheet.append(body);
    }
    settingsCard(index, kicker, title, pill, id) {
      const card = el("section", { class: "settings-card", id });
      const head = el("div", { class: "settings-card-head" });
      head.append(el("span", { class: "settings-index mono" }, index));
      head.append(el("span", { class: "settings-kicker mono" }, kicker));
      head.append(el("span", { class: "settings-head-rule" }));
      head.append(pill);
      card.append(head);
      card.append(el("h3", { class: "settings-card-title" }, title));
      const body = el("div", { class: "settings-card-body" });
      card.append(body);
      return { card, body };
    }
    settingsPill(text, kind = "muted") {
      const pill = el("span", { class: "settings-pill " + kind });
      pill.append(el("span", { class: "settings-dot" }), el("span", {}, text));
      return pill;
    }
    settingsDot(kind = "muted") {
      return el("span", { class: "settings-dot " + kind });
    }
    settingsField(label, control, forId, hint) {
      const field = el("div", { class: "settings-field" });
      const labelAttrs = { class: "settings-label mono" };
      if (forId) labelAttrs.for = forId;
      field.append(el("label", labelAttrs, label), control);
      if (hint) field.append(el("div", { class: "settings-hint" }, hint));
      return field;
    }
    settingsFeedback() {
      if (this.state.sheetError) {
        const box = el("div", { class: "settings-feedback error", role: "alert" });
        box.append(el("span", { class: "settings-feedback-mark mono", "aria-hidden": "true" }, "!"), el("span", {}, this.state.sheetError));
        return box;
      }
      if (this.state.sheetNotice) {
        const box = el("div", { class: "settings-feedback ok", role: "status" });
        box.append(el("span", { class: "settings-feedback-mark mono", "aria-hidden": "true" }, "\u2713"), el("span", {}, this.state.sheetNotice));
        return box;
      }
      return null;
    }
    buildSettingsContext() {
      const line = el("div", { class: "settings-context mono" });
      const item = (kind, text) => {
        const span = el("span", { class: "settings-context-item" });
        span.append(this.settingsDot(kind), el("span", {}, text));
        return span;
      };
      const helperKind = this.state.conn === "open" ? "ok" : this.state.everConnected ? "warn" : "muted";
      const helperText = this.state.conn === "open" ? "Helper online" : this.state.everConnected ? "Helper reconnecting" : "Helper connecting";
      line.append(item(helperKind, helperText));
      if (this.state.pageAccess === true) line.append(item("ok", "Page access on"));
      else if (this.state.pageAccess === false) line.append(item("warn", "Page access off"));
      else line.append(item("muted", "Checking access"));
      line.append(item("muted", "Theme " + this.state.settings.theme));
      if (this.state.health?.localAccess?.enabled) line.append(item("warn", "Local on"));
      if (this.state.health?.superMode) line.append(item("warn", "Super on"));
      else if (this.state.health?.fullAuto) line.append(item("warn", "Full auto on"));
      return line;
    }
    /** Optional permissions are user-granted, so their state is queried, never assumed. */
    async loadCapabilities() {
      try {
        this.caps = {
          cdp: await chrome.permissions.contains({ permissions: ["debugger"] }),
          history: await chrome.permissions.contains({ permissions: ["history"] })
        };
      } catch {
        this.caps = { cdp: false, history: false };
      }
      if (!this.el.sheet.hidden) this.renderSheet();
    }
    async requestCapability(kind) {
      const permissions = kind === "cdp" ? ["debugger"] : ["history", "sessions"];
      let granted = false;
      try {
        granted = await chrome.permissions.request({ permissions });
      } catch {
      }
      if (kind === "cdp") this.caps.cdp = granted;
      else this.caps.history = granted;
      this.setState({
        sheetError: granted ? void 0 : "Chrome didn't grant that permission.",
        sheetNotice: granted ? kind === "cdp" ? "Deep control is on." : "History and closed tabs are on." : void 0
      });
      this.renderSheet();
    }
    /** One optional capability: state, explanation, and an enable button when off. */
    capabilityRow(kind, title, text) {
      const on = this.caps[kind];
      const wrap = el("div", { class: "settings-capability" });
      const row = el("div", { class: "settings-state" });
      row.append(this.settingsDot(on ? "ok" : "muted"));
      const copy = el("div", { class: "settings-state-copy" });
      copy.append(el("div", { class: "settings-state-title" }, title));
      copy.append(el("div", { class: "settings-state-text" }, on ? "On." : text));
      row.append(copy);
      wrap.append(row);
      if (on === false) {
        const btn = el("button", { class: "btn settings-action", type: "button", id: `cap-${kind}` }, `Enable ${kind === "cdp" ? "deep control" : "history"}`);
        btn.onclick = () => void this.requestCapability(kind);
        wrap.append(btn);
      }
      return wrap;
    }
    buildAccessCard() {
      const granted = this.state.pageAccess === true;
      const denied = this.state.pageAccess === false;
      const pill = this.settingsPill(granted ? "Granted" : denied ? "Needs access" : "Checking", granted ? "ok" : denied ? "warn" : "muted");
      const { card, body } = this.settingsCard("01", "ACCESS", "Let me read and act on pages.", pill, "accessCard");
      body.append(el("p", { class: "settings-copy" }, "I only look at a page when you give me a task. Permission lets me read the current tab and act on it."));
      const stateRow = el("div", { class: "settings-state" });
      stateRow.append(this.settingsDot(granted ? "ok" : denied ? "warn" : "muted"));
      const copy = el("div", { class: "settings-state-copy" });
      copy.append(el("div", { class: "settings-state-title" }, granted ? "Access granted" : denied ? "Access is off" : "Checking permission\u2026"));
      copy.append(el("div", { class: "settings-state-text" }, granted ? "I can read and act on the sites you open." : denied ? "Tasks can't read or act on pages until you allow it." : "Chrome is checking what I can access."));
      stateRow.append(copy);
      body.append(stateRow);
      if (this.state.pageAccess !== null) {
        const action = el("button", {
          class: granted ? "btn settings-action" : "btn primary settings-action",
          type: "button",
          id: "access-action"
        }, granted ? "Re-check access" : "Allow page access");
        action.onclick = () => this.requestPageAccess();
        body.append(action);
      }
      body.append(el("div", { class: "settings-hint" }, "You can change this any time in Chrome's extension settings."));
      body.append(el("p", { class: "settings-copy" }, "Two capabilities stay off until you ask for them. Everything else works without them."));
      body.append(this.capabilityRow("cdp", "Deep control (CDP)", "Screenshots, trusted input, DevTools and file upload. Without it I still click and type through the page itself."));
      body.append(this.capabilityRow("history", "History & closed tabs", "Search your browsing history and reopen a tab you closed."));
      return card;
    }
    buildAppearanceCard() {
      const current = this.state.settings.theme;
      const pill = this.settingsPill(current === "auto" ? "Auto" : current === "light" ? "Light" : "Dark", "muted");
      const { card, body } = this.settingsCard("02", "APPEARANCE", "Choose the light.", pill, "appearanceCard");
      body.append(el("p", { class: "settings-copy" }, "The panel follows your system by default. Pick a side if you want it to stay put."));
      const grid = el("div", { class: "theme-grid", role: "group", "aria-label": "Theme" });
      const themes = [
        ["auto", "Auto", "Follows system"],
        ["light", "Light", "Warm paper"],
        ["dark", "Dark", "Low light"]
      ];
      for (const [value, name, hint] of themes) {
        const selected = current === value;
        const tile = el("button", {
          class: "theme-tile" + (selected ? " on" : ""),
          type: "button",
          id: "theme-" + value,
          "aria-pressed": selected ? "true" : "false"
        });
        const preview = el("span", { class: "theme-preview " + value, "aria-hidden": "true" });
        preview.append(el("i"), el("i"), el("i"));
        tile.append(preview);
        tile.append(el("span", { class: "theme-label" }, name));
        tile.append(el("span", { class: "theme-hint" }, hint));
        tile.onclick = async () => {
          if (this.state.settings.theme === value) return;
          const next = await setSettings({ theme: value });
          this.setState({ settings: next });
          this.applyTheme();
          this.renderSheet();
        };
        grid.append(tile);
      }
      body.append(grid);
      return card;
    }
    autonomyMode() {
      if (this.state.health?.superMode) return "super";
      return this.state.health?.fullAuto ? "full" : "ask";
    }
    buildAutonomyCard() {
      const mode = this.autonomyMode();
      const pill = this.settingsPill(mode === "super" ? "Super" : mode === "full" ? "Full auto" : "Ask first", mode === "ask" ? "ok" : "warn");
      const { card, body } = this.settingsCard("03", "AUTONOMY", "Decide when I ask.", pill, "autonomyCard");
      const options = [
        { id: "ask", label: "Ask first", hint: "I pause before clicks, sends, purchases, and other irreversible steps. Questions wait for you." },
        { id: "full", label: "Full auto", hint: "Approvals auto-allow and questions use the first choice. Use this only for trusted runs." },
        { id: "super", label: "Super", hint: "Everything auto-allows, including local shell and file writes when local access is on. The only thing that still asks is a recursive rm (rm -r, rm -rf)." }
      ];
      const group = el("div", { class: "mode-select", role: "radiogroup", id: "autonomy-mode", "aria-label": "Autonomy mode" });
      const buttons = [];
      for (const option of options) {
        const button = el("button", {
          class: "mode-option",
          type: "button",
          role: "radio",
          id: `autonomy-mode-${option.id}`,
          "data-mode": option.id,
          "aria-checked": option.id === mode ? "true" : "false"
        });
        button.textContent = option.label;
        button.onclick = () => {
          if (option.id !== mode) void this.setAutonomyMode(option.id, group);
        };
        buttons.push(button);
        group.append(button);
      }
      group.addEventListener("keydown", (ev) => {
        if (ev.key !== "ArrowLeft" && ev.key !== "ArrowRight") return;
        ev.preventDefault();
        const current = options.findIndex((o) => o.id === mode);
        const next = (current + (ev.key === "ArrowRight" ? 1 : options.length - 1)) % options.length;
        buttons[next].focus();
        if (options[next].id !== mode) void this.setAutonomyMode(options[next].id, group);
      });
      body.append(group);
      body.append(el("p", { class: "settings-hint mode-desc" }, options.find((o) => o.id === mode).hint));
      if (mode !== "ask") {
        const warning = el("div", { class: "settings-warn" });
        warning.append(el("span", { class: "settings-warn-mark mono", "aria-hidden": "true" }, "!"), el("span", {}, mode === "super" ? "Super mode auto-allows every approval except recursive rm (rm -r). If local access is on, shell commands and file writes run without a prompt." : "Approvals auto-allow while full auto is on."));
        body.append(warning);
      }
      return card;
    }
    localCheck(id, label, hint, checked, onChange) {
      const input = el("input", { type: "checkbox", id, name: id });
      input.checked = checked;
      if (onChange) input.onchange = () => onChange(input.checked);
      const copy = el("span", { class: "settings-check-copy" });
      copy.append(el("span", { class: "settings-check-label" }, label));
      copy.append(el("span", { class: "settings-check-hint" }, hint));
      const row = el("label", { class: "settings-check", for: id });
      row.append(input, copy);
      return row;
    }
    buildLocalCard() {
      const la = this.state.health?.localAccess;
      const known = !!la;
      const enabled = !!la?.enabled;
      const shell = la?.shell !== false;
      const requireApproval = la?.requireApproval !== false;
      const roots = (la?.roots ?? []).join(":");
      const pill = this.settingsPill(!known ? "Helper update" : enabled ? "On" : "Off", !known ? "warn" : enabled ? "warn" : "muted");
      const { card, body } = this.settingsCard("04", "LOCAL MACHINE", "Let me touch this computer.", pill, "localCard");
      body.append(el("p", { class: "settings-copy" }, "Off by default. When on, I can read and write files and run commands as you. The folders below confine file access; shell commands are not sandboxed by them."));
      body.append(this.localCheck("local-access-enabled", "Allow local files & shell", "Registers fs_list, fs_read, fs_write and shell_run for this helper.", enabled));
      body.append(this.localCheck("local-shell-enabled", "Allow shell commands", "Runs non-interactive commands as your user account.", shell));
      body.append(this.localCheck("local-require-approval", "Ask before writes and commands", "Keep this on unless you want silent local execution.", requireApproval));
      const rootsInput = el("input", {
        class: "input mono",
        id: "local-roots",
        name: "local-roots",
        type: "text",
        spellcheck: "false",
        placeholder: "~/Projects:~/Downloads",
        value: roots
      });
      body.append(this.settingsField("Allowed folders", rootsInput, "local-roots", "Colon-separated absolute paths. Empty uses your home folder. File tools are confined here; shell is not."));
      const save = el("button", { class: "btn primary settings-save", type: "button", id: "local-save" }, "Save local access");
      save.onclick = () => void this.applyLocalConfig(save);
      body.append(save);
      if (!known) {
        const warning = el("div", { class: "settings-warn" });
        warning.append(el("span", { class: "settings-warn-mark mono", "aria-hidden": "true" }, "!"), el("span", {}, "This helper does not report local-access settings yet. Restart the helper once, then this card can manage it."));
        body.append(warning);
      } else if (enabled && shell && (!requireApproval || this.state.health?.superMode)) {
        const warning = el("div", { class: "settings-warn" });
        warning.append(el("span", { class: "settings-warn-mark mono", "aria-hidden": "true" }, "!"), el("span", {}, this.state.health?.superMode ? "Super mode is on, so local writes and shell commands run without asking. Only recursive rm still prompts." : "Approval is off, so local writes and shell commands run without asking."));
        body.append(warning);
      }
      if (known) body.append(el("div", { class: "settings-hint" }, "Saved by the helper and applied to the next message. No restart needed."));
      return card;
    }
    // ---- Settings -> AI tools (MCP hosts) ----
    /** Show $HOME as ~ so the paths stay readable in a 400px panel. */
    shortHome(p) {
      return p.replace(/^\/(Users|home)\/[^/]+/, "~");
    }
    async loadMcpHosts() {
      try {
        const res = await fetch(`${this.orchHttpBase()}/v1/mcp/hosts`, { signal: AbortSignal.timeout(4e3) });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(String(data?.error ?? `HTTP ${res.status}`));
        this.mcpHosts = Array.isArray(data?.hosts) ? data.hosts : [];
        this.mcpError = null;
      } catch {
        this.mcpError = "Couldn't check which AI tools are installed - is the helper running?";
        if (!this.mcpHosts) this.mcpHosts = [];
      }
      if (!this.el.sheet.hidden) this.renderSheet();
    }
    buildMcpCard() {
      const hosts = this.mcpHosts;
      const connected = hosts?.filter((h) => h.installed).length ?? 0;
      const pill = this.settingsPill(hosts === null ? "Checking" : connected ? `${connected} connected` : "Off", hosts === null ? "muted" : connected ? "ok" : "muted");
      const { card, body } = this.settingsCard("05", "AI TOOLS", "Let my other tools drive this browser.", pill, "mcpCard");
      body.append(el("p", { class: "settings-copy" }, "Vicaro registers itself as an MCP server, so Cursor, Claude Code, Codex and others can open tabs, read pages and click for you. Only the tools you tick are changed, and each config is backed up first."));
      if (hosts === null) {
        body.append(el("div", { class: "settings-hint" }, "Checking which AI tools are installed..."));
        return card;
      }
      if (this.mcpError) {
        const warning = el("div", { class: "settings-warn" });
        warning.append(el("span", { class: "settings-warn-mark mono", "aria-hidden": "true" }, "!"), el("span", {}, this.mcpError));
        body.append(warning);
      }
      if (hosts.length) {
        for (const h of hosts) {
          const id = `mcp-host-${h.id}`;
          const input = el("input", { type: "checkbox", id, name: id });
          input.checked = h.installed;
          input.disabled = !h.exists;
          const copy = el("span", { class: "settings-check-copy" });
          copy.append(el("span", { class: "settings-check-label" }, h.name));
          copy.append(el("span", { class: "settings-check-hint" }, h.exists ? `${this.shortHome(h.path)}${h.note ? ` - ${h.note}` : ""}` : "No config yet - open it once, then come back."));
          const row = el("label", { class: "settings-check", for: id });
          row.append(input, copy);
          body.append(row);
        }
        const save = el("button", { class: "btn primary settings-save", type: "button", id: "mcp-save" }, "Save AI tool connections");
        save.onclick = () => void this.applyMcpHosts(save);
        body.append(save);
        body.append(el("p", { class: "settings-hint" }, "Restart a tool after connecting it. Undo any time by unticking it here, or with vicaro mcp remove."));
      } else if (!this.mcpError) {
        body.append(el("div", { class: "settings-hint" }, "No AI tools found on this machine yet."));
      }
      return card;
    }
    async applyMcpHosts(button) {
      const hosts = this.mcpHosts ?? [];
      const install = [];
      const remove = [];
      for (const h of hosts) {
        const input = document.querySelector(`#mcp-host-${h.id}`);
        if (!input || input.disabled) continue;
        if (input.checked && !h.installed) install.push(h.id);
        if (!input.checked && h.installed) remove.push(h.id);
      }
      if (!install.length && !remove.length) {
        this.setState({ sheetNotice: "No AI tool changes to save.", sheetError: void 0 });
        this.renderSheet();
        return;
      }
      button.disabled = true;
      button.textContent = "Saving...";
      try {
        const res = await fetch(`${this.orchHttpBase()}/v1/mcp/hosts`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ install, remove })
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(String(data?.error ?? `HTTP ${res.status}`));
        const changed = (data?.results ?? []).filter((r) => r.action === "created" || r.action === "updated" || r.action === "removed");
        const names = changed.map((r) => r.name);
        const restart = changed.map((r) => hosts.find((h) => h.id === r.id)?.restart).filter(Boolean)[0];
        this.mcpHosts = Array.isArray(data?.hosts) ? data.hosts : hosts;
        this.setState({
          sheetError: void 0,
          sheetNotice: names.length ? `Updated ${names.join(", ")}.${restart ? ` ${restart}.` : ""}` : "Those tools were already up to date."
        });
      } catch (err) {
        this.setState({ sheetError: `Couldn't update AI tools - ${String(err?.message ?? err)}`, sheetNotice: void 0 });
      }
      this.renderSheet();
    }
    async applyLocalConfig(button) {
      const checked = (id) => document.querySelector(`#${id}`)?.checked ?? false;
      const enabled = checked("local-access-enabled");
      const shell = checked("local-shell-enabled");
      const requireApproval = checked("local-require-approval");
      const roots = (document.querySelector("#local-roots")?.value ?? "").trim();
      if (button) {
        button.disabled = true;
        button.setAttribute("aria-busy", "true");
        button.textContent = "Saving\u2026";
      }
      const ack = await this.ws?.request("settings_update", { local: { enabled, shell, requireApproval, roots } }, 1e4).catch(() => null);
      if (ack?.payload?.ok && ack.payload.local) {
        const health = this.state.health;
        this.setState({
          health: health ? { ...health, localAccess: ack.payload.local } : health,
          sheetError: void 0,
          sheetNotice: enabled ? "Local access saved. It applies to your next message." : "Local access is off."
        });
      } else {
        this.setSheetError(typeof ack?.payload?.error === "string" ? ack.payload.error : "Couldn't save local access - check the helper and try again.");
        return;
      }
      if (!this.el.sheet.hidden) this.renderSheet();
    }
    buildSkillsCard() {
      const skills = this.state.health?.skills;
      const known = Array.isArray(skills);
      const list = skills ?? [];
      const modelSkills = list.filter((s) => s.modelInvocable);
      const pill = this.settingsPill(!known ? "Helper update" : modelSkills.length ? `${modelSkills.length} loaded` : list.length ? "User only" : "None", !known ? "warn" : modelSkills.length ? "ok" : "muted");
      const { card, body } = this.settingsCard("06", "SKILLS", "Saved procedures I can load.", pill, "skillsCard");
      body.append(el("p", { class: "settings-copy" }, "Skills are reusable procedures, not tools. I see their names and short descriptions, then load the full steps with skill(name) only when a task needs them."));
      if (!known) {
        const warning = el("div", { class: "settings-warn" });
        warning.append(el("span", { class: "settings-warn-mark mono", "aria-hidden": "true" }, "!"), el("span", {}, "This helper does not report skills yet. Restart it once, then this card will list the discovered SKILL.md files."));
        body.append(warning);
      } else if (!list.length) {
        const state = el("div", { class: "settings-state" });
        state.append(this.settingsDot("muted"));
        const copy = el("div", { class: "settings-state-copy" });
        copy.append(el("div", { class: "settings-state-title" }, "No skills installed"));
        copy.append(el("div", { class: "settings-state-text" }, "Add a SKILL.md under skills/ in this checkout, or under ~/.vicaro/skills."));
        state.append(copy);
        body.append(state);
      } else {
        const rows = el("div", { class: "skill-list" });
        for (const skill of list.slice(0, 12)) {
          const row = el("div", { class: "skill-row" });
          row.append(el("div", { class: "skill-name" }, skill.name));
          row.append(el("div", { class: "skill-desc" }, skill.description));
          const meta = [
            skill.risk,
            skill.hasContract ? "contract" : skill.contractError ? "contract error" : "",
            ...skill.requires ?? [],
            skill.modelInvocable ? "" : "user only",
            skill.version ? `v${skill.version}` : ""
          ].filter(Boolean).join(" \xB7 ");
          if (meta) row.append(el("div", { class: "skill-meta mono" }, meta));
          rows.append(row);
        }
        body.append(rows);
        if (list.length > 12) body.append(el("div", { class: "settings-hint" }, `+${list.length - 12} more skill${list.length - 12 === 1 ? "" : "s"}.`));
        const broken = list.find((s) => s.contractError);
        if (broken) {
          const warning = el("div", { class: "settings-warn" });
          warning.append(el("span", { class: "settings-warn-mark mono", "aria-hidden": "true" }, "!"), el("span", {}, `Contract error in ${broken.name}: ${broken.contractError}`));
          body.append(warning);
        }
      }
      body.append(el("div", { class: "settings-hint" }, "Author a skill as <name>/SKILL.md with name and description frontmatter. Requires: e.g. page, devtools, local. Loading a skill never bypasses approvals."));
      return card;
    }
    modelCell(key, value, title) {
      const c = el("div", { class: "model-cell" });
      if (title) c.title = title;
      c.append(el("span", { class: "model-k mono" }, key), el("span", { class: "model-v mono" }, value || "-"));
      return c;
    }
    /** Working context budget. Two numbers matter: what the model server
     *  advertises (the ceiling) and what this agent may actually keep per message.
     *  "Follow the model window" makes the ceiling the budget; turning it off pins
     *  the size below so a big window cannot silently become a page dump. */
    buildContextCard() {
      const h = this.state.health;
      const chat = h?.chat;
      const known = !!chat;
      const follow = chat?.followProviderWindow ?? true;
      const provider = h?.planner?.contextWindow;
      const providerKnown = typeof provider === "number" && provider > 0;
      const pinned = chat?.contextTokens ?? 2e4;
      const auto = follow && providerKnown;
      const effective = chat?.effectiveTokens ?? (auto ? provider : pinned);
      const pill = this.settingsPill(!known ? "Helper update" : `${tokenCount(effective)} tok`, !known ? "warn" : "ok");
      const { card, body } = this.settingsCard("08", "CONTEXT", "How much I can hold.", pill, "contextCard");
      body.append(el("p", { class: "settings-copy" }, "The working context is what stays in front of the model for one message: your request, page evidence, tool output and history. By default I use the model's full advertised window; uncheck Follow to pin a smaller size."));
      const readout = el("div", { class: "model-readout" });
      readout.append(this.modelCell("MODEL WINDOW", providerKnown ? tokenCount(provider) : "unknown", h?.planner?.contextSource));
      readout.append(this.modelCell("CONTEXT SIZE", tokenCount(effective), auto ? "the model's advertised maximum" : "the pinned size"));
      body.append(readout);
      const size = el("input", {
        class: "input mono",
        id: "context-size",
        name: "context-size",
        type: "number",
        min: "2000",
        max: "2000000",
        step: "1000",
        inputmode: "numeric",
        "data-live": "1",
        value: String(effective),
        placeholder: "20000"
      });
      size.disabled = auto;
      body.append(this.settingsField("Context size", size, "context-size", "Tokens I may use per message (characters \u2248 tokens \xD7 4). 2,000\u20132,000,000. While Follow is on this is the model's window."));
      body.append(this.localCheck("context-follow", "Follow the model's advertised window", follow ? `On. The budget is the model's advertised maximum${providerKnown ? ` (${tokenCount(provider)} tokens)` : ` (none reported right now; the fallback is ${tokenCount(pinned)})`}; uncheck to pin the size above.` : "Off. The size above is pinned, even when the model advertises a larger window.", follow, (checked) => {
        const input = document.querySelector("#context-size");
        const win = this.state.health?.planner?.contextWindow;
        const hasWindow = typeof win === "number" && win > 0;
        if (!input) return;
        input.disabled = checked && hasWindow;
        if (checked && hasWindow) input.value = String(win);
      }));
      const save = el("button", { class: "btn primary settings-save", type: "button", id: "context-save" }, "Save context budget");
      save.onclick = () => void this.applyContextConfig(save);
      body.append(save);
      if (!known) {
        const warning = el("div", { class: "settings-warn" });
        warning.append(el("span", { class: "settings-warn-mark mono", "aria-hidden": "true" }, "!"), el("span", {}, "This helper does not report context settings yet. Restart the helper once, then this card can manage the budget."));
        body.append(warning);
      } else {
        body.append(el("div", { class: "settings-hint" }, "Saved by the helper and remembered across restarts. A running turn picks it up on its next round; older turns keep the budget they were measured against."));
      }
      return card;
    }
    async applyContextConfig(button) {
      const raw = (document.querySelector("#context-size")?.value ?? "").trim();
      const followProviderWindow = document.querySelector("#context-follow")?.checked ?? true;
      const contextTokens = Math.round(Number(raw));
      if (!Number.isFinite(contextTokens) || contextTokens < 2e3 || contextTokens > 2e6) {
        this.setSheetError("Context size must be between 2,000 and 2,000,000 tokens.");
        return;
      }
      if (button) {
        button.disabled = true;
        button.setAttribute("aria-busy", "true");
        button.textContent = "Saving\u2026";
      }
      const ack = await this.ws?.request("settings_update", { chat: { contextTokens, followProviderWindow } }, 1e4).catch(() => null);
      if (ack?.payload?.ok && ack.payload.chat) {
        const health = this.state.health;
        const chat = ack.payload.chat;
        const provider = health?.planner?.contextWindow;
        const followingModel = chat.followProviderWindow && typeof provider === "number" && provider > 0;
        const effective = chat.effectiveTokens ?? (followingModel ? provider : chat.contextTokens);
        const detail = followingModel ? `${tokenCount(effective)} tokens (the model window).` : `${tokenCount(effective)} tokens (${chat.followProviderWindow ? "fallback; no model window reported" : "pinned"}).`;
        this.setState({
          health: health ? { ...health, chat } : health,
          sheetError: void 0,
          sheetNotice: `Context budget saved: ${detail} It applies from my next round.`
        });
      } else {
        const error = typeof ack?.payload?.error === "string" ? ack.payload.error : "";
        this.setState({ sheetNotice: void 0, sheetError: error || "Couldn't save the context budget - check the helper and try again." });
      }
      if (!this.el.sheet.hidden) this.renderSheet();
    }
    buildModelsCard() {
      const h = this.state.health;
      const mainModel = h?.llm?.mainModel ?? "";
      const decisionModel = h?.llm?.decisionModel ?? "";
      const ctx = h?.planner?.contextWindow;
      const healthy = h?.planner?.healthy;
      const pill = this.settingsPill(healthy ? "Ready" : mainModel ? "Needs attention" : "Not set", healthy ? "ok" : mainModel ? "warn" : "muted");
      const { card, body } = this.settingsCard("07", "MODEL", "The model behind the panel.", pill, "modelsCard");
      body.append(el("p", { class: "settings-copy" }, "Point Vicaro at any OpenAI-compatible server. The main model plans; the decision model handles quick safety checks."));
      const readout = el("div", { class: "model-readout" });
      readout.append(this.modelCell("MAIN", mainModel), this.modelCell("DECISION", decisionModel), this.modelCell("CONTEXT", ctx ? tokenCount(ctx) : "", h?.planner?.contextSource));
      body.append(readout);
      const base = el("input", {
        class: "input mono",
        id: "llm-base-url",
        name: "llm-base-url",
        type: "url",
        inputmode: "url",
        autocomplete: "off",
        spellcheck: "false",
        placeholder: "http://127.0.0.1:11434",
        value: h?.llm?.baseUrl ?? ""
      });
      const urlRow = el("div", { class: "settings-url-row" });
      urlRow.append(base);
      const fetchBtn = el("button", { class: "btn settings-fetch", type: "button", id: "llm-fetch-models", title: "Fetch the server's model list" }, "Fetch models");
      fetchBtn.onclick = () => void this.fetchLlmModels();
      urlRow.append(fetchBtn);
      body.append(this.settingsField("Base URL", urlRow, "llm-base-url", "OpenAI-compatible endpoint. Include /v1 if your server needs it."));
      const keyWrap = el("div", { class: "settings-secret" });
      const key = el("input", {
        class: "input mono",
        id: "llm-api-key",
        name: "llm-api-key",
        type: this.showApiKey ? "text" : "password",
        autocomplete: "off",
        spellcheck: "false",
        placeholder: "Optional",
        value: h?.llm?.apiKey ?? ""
      });
      const eye = el("button", {
        class: "settings-eye mono",
        type: "button",
        id: "llm-api-toggle",
        "aria-label": this.showApiKey ? "Hide API key" : "Show API key",
        title: this.showApiKey ? "Hide API key" : "Show API key"
      }, this.showApiKey ? "HIDE" : "SHOW");
      eye.onclick = () => {
        this.showApiKey = !this.showApiKey;
        this.renderSheet();
      };
      keyWrap.append(key, eye);
      body.append(this.settingsField("API key", keyWrap, "llm-api-key", "Optional. Stored by your helper."));
      const currentModels = [h?.llm?.mainModel, h?.llm?.decisionModel].filter((m) => !!m);
      const modelOpts = [.../* @__PURE__ */ new Set([...this.llmModels, ...currentModels])];
      const makeSelect = (id, selected) => {
        const sel = el("select", { class: "input settings-select", id, name: id });
        if (!modelOpts.length) sel.append(el("option", { value: "" }, "(fetch models first)"));
        for (const m of modelOpts) {
          const opt = el("option", { value: m }, m);
          if (m === selected) opt.selected = true;
          sel.append(opt);
        }
        return sel;
      };
      const mainSel = makeSelect("llm-main-model", mainModel);
      const decSel = makeSelect("llm-decision-model", decisionModel);
      body.append(this.settingsField("Main model", mainSel, "llm-main-model"));
      body.append(this.settingsField("Decision model", decSel, "llm-decision-model", "A smaller, faster model works well for safety checks."));
      const save = el("button", { class: "btn primary settings-save", type: "button", id: "llm-save" }, "Save model settings");
      save.onclick = () => void this.applyLlmConfig(save);
      body.append(save);
      return card;
    }
    buildHelperCard() {
      const connected = this.state.conn === "open";
      const label = connected ? "Connected" : this.state.everConnected ? "Reconnecting" : "Connecting";
      const { card, body } = this.settingsCard("09", "HELPER", "The helper behind the panel.", this.settingsPill(label, connected ? "ok" : "warn"), "helperCard");
      body.append(el("p", { class: "settings-copy" }, "Vicaro runs through a small helper service. It remembers chats, calls the model, and drives the browser."));
      const readout = el("div", { class: "helper-readout" });
      readout.append(el("span", { class: "helper-url mono" }, this.state.settings.orchestratorUrl));
      const health = this.state.health;
      const healthy = !!health && health.decision?.healthy && health.planner?.healthy && health.bridge?.connected;
      const healthRow = el("div", { class: "settings-health mono" });
      healthRow.append(this.settingsDot(health ? healthy ? "ok" : "warn" : "muted"), el("span", {}, this.healthLine()));
      readout.append(healthRow);
      body.append(readout);
      const toggle = el("button", {
        class: "settings-disclosure",
        type: "button",
        id: "conn-toggle",
        "aria-expanded": this.advancedOpen ? "true" : "false",
        "aria-controls": "conn-fields"
      });
      toggle.append(el("span", {}, this.advancedOpen ? "Hide connection details" : "Connection details"));
      toggle.append(el("span", { class: "settings-chev mono", "aria-hidden": "true" }, this.advancedOpen ? "\u25BE" : "\u25B8"));
      toggle.onclick = () => {
        this.advancedOpen = !this.advancedOpen;
        this.renderSheet();
        if (this.advancedOpen) {
          window.setTimeout(() => {
            this.el.sheet.querySelector("#conn-fields")?.scrollIntoView({ block: "nearest" });
          }, 0);
        }
      };
      body.append(toggle);
      if (this.advancedOpen) {
        const fields = el("div", { class: "settings-conn-fields", id: "conn-fields" });
        const url = el("input", {
          class: "input mono",
          id: "conn-url",
          name: "conn-url",
          type: "text",
          inputmode: "url",
          autocomplete: "off",
          spellcheck: "false",
          value: this.state.settings.orchestratorUrl
        });
        fields.append(this.settingsField("Helper address", url, "conn-url", "Use ws:// for a local helper."));
        const bearer = el("input", {
          class: "input mono",
          id: "conn-bearer",
          name: "conn-bearer",
          type: "password",
          autocomplete: "off",
          spellcheck: "false",
          placeholder: "Only if you set one up",
          value: this.state.settings.bearer ?? ""
        });
        fields.append(this.settingsField("Extra password", bearer, "conn-bearer", "Optional. The helper must use the same value."));
        const reconnect = el("button", { class: "btn primary settings-save", type: "button", id: "conn-reconnect" }, "Save & reconnect");
        reconnect.onclick = async () => {
          const nextUrl = url.value.trim();
          const bearerVal = bearer.value.trim() || void 0;
          if (!nextUrl.startsWith("ws://") && !nextUrl.startsWith("wss://")) {
            this.setSheetError("That address should start with ws:// or wss://.");
            return;
          }
          reconnect.disabled = true;
          reconnect.textContent = "Reconnecting\u2026";
          const next = await setSettings({ orchestratorUrl: nextUrl, bearer: bearerVal });
          this.setState({ settings: next, sheetError: void 0, sheetNotice: "Connecting to the new helper address." });
          await this.reconnect();
          this.renderSheet();
        };
        fields.append(reconnect);
        body.append(fields);
      }
      return card;
    }
    async fetchLlmModels() {
      const baseInput = document.querySelector("#llm-base-url")?.value?.trim() ?? "";
      const keyInput = document.querySelector("#llm-api-key")?.value?.trim() ?? "";
      const btn = document.querySelector("#llm-fetch-models");
      if (btn) {
        btn.disabled = true;
        btn.setAttribute("aria-busy", "true");
        btn.textContent = "Fetching\u2026";
      }
      try {
        const res = await fetch(`${this.orchHttpBase()}/v1/llm/models`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ baseUrl: baseInput, apiKey: keyInput })
        });
        const data = await res.json().catch(() => ({}));
        const models = Array.isArray(data?.models) ? data.models.filter((m) => typeof m === "string" && m.trim()).slice(0, 500) : [];
        if (models.length) {
          this.llmModels = models;
          this.setState({ sheetError: void 0, sheetNotice: `Found ${models.length} model${models.length === 1 ? "" : "s"}.` });
        } else {
          this.setState({ sheetError: String(data?.error || "The server returned no models."), sheetNotice: void 0 });
        }
      } catch {
        this.setState({ sheetError: "Couldn't fetch models - check the base URL and that the helper is running.", sheetNotice: void 0 });
      } finally {
        this.renderSheet();
      }
    }
    async applyLlmConfig(button) {
      const base = document.querySelector("#llm-base-url")?.value?.trim() ?? "";
      const key = document.querySelector("#llm-api-key")?.value?.trim() ?? "";
      const main = document.querySelector("#llm-main-model")?.value ?? "";
      const decision = document.querySelector("#llm-decision-model")?.value ?? "";
      if (button) {
        button.disabled = true;
        button.setAttribute("aria-busy", "true");
        button.textContent = "Saving\u2026";
      }
      const ack = await this.ws?.request("settings_update", { llm: { baseUrl: base, apiKey: key, mainModel: main, decisionModel: decision } }, 1e4).catch(() => null);
      if (ack?.payload?.ok) {
        const llm = ack.payload.llm;
        const health = this.state.health;
        const merged = health && llm ? { ...health, llm: { baseUrl: "", mainModel: "", decisionModel: "", ...health.llm ?? {}, ...llm } } : health;
        this.setState({ health: merged, sheetError: void 0, sheetNotice: "Model settings saved." });
      } else {
        const error = typeof ack?.payload?.error === "string" ? ack.payload.error : "";
        this.setState({ sheetNotice: void 0, sheetError: error || "Couldn't save model settings - check the helper and try again." });
      }
      this.renderSheet();
    }
    async setAutonomyMode(mode, group) {
      const flags = mode === "super" ? { fullAuto: true, superMode: true } : mode === "full" ? { fullAuto: true, superMode: false } : { fullAuto: false, superMode: false };
      if (group) {
        group.setAttribute("aria-busy", "true");
        group.classList.add("busy");
        group.querySelectorAll("button").forEach((b) => {
          b.disabled = true;
        });
      }
      const ack = await this.ws?.request("settings_update", flags, 8e3).catch(() => null);
      if (ack?.payload?.ok) {
        const health = this.state.health;
        this.setState({
          health: health ? {
            ...health,
            fullAuto: ack.payload.fullAuto ?? flags.fullAuto,
            superMode: ack.payload.superMode ?? flags.superMode
          } : health,
          sheetError: void 0,
          sheetNotice: mode === "super" ? "Super mode is on. Only recursive rm still asks." : mode === "full" ? "Full auto is on." : "Autonomy is back to asking first."
        });
        this.renderSheet();
        return;
      }
      if (group) {
        group.removeAttribute("aria-busy");
        group.classList.remove("busy");
        group.querySelectorAll("button").forEach((b) => {
          b.disabled = false;
        });
      }
      this.setSheetError("Couldn't change autonomy - check the helper and try again.");
    }
    orchHttpBase() {
      const u = this.state.settings.orchestratorUrl || "http://127.0.0.1:8790/chrome";
      return u.replace(/^wss/i, "https").replace(/^ws/i, "http").replace(/\/chrome\/?$/, "");
    }
    async reconnect() {
      try {
        this.ws?.disconnect();
      } catch {
      }
      this.ws = null;
      await this.connect();
    }
    // ---- debug hook (screenshot harness / devtools) ----
    exposeDebug() {
      globalThis.__vicaro = {
        panel: this,
        feed: (frames) => frames.forEach((f) => this.onFrame(f)),
        state: () => this.state
      };
    }
  };
  function el(tag, attrs = {}, text) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === "class") node.className = v;
      else if (k === "disabled") node.disabled = v;
      else if (k === "style") node.setAttribute("style", v);
      else node.setAttribute(k, String(v));
    }
    if (text !== void 0) node.textContent = text;
    return node;
  }
  function iconBtn(glyph, title, onClick, extra = "") {
    const b = el("button", { class: `icon-btn ${extra}`, type: "button", title, "aria-label": title }, glyph);
    b.onclick = onClick;
    return b;
  }
  function railAction(glyph, label, title, onClick) {
    const b = el("button", { class: "rail-action", type: "button", title, "aria-label": title });
    b.append(el("span", { class: "rail-action-icon mono", "aria-hidden": "true" }, glyph));
    b.append(el("span", { class: "rail-action-label" }, label));
    b.onclick = onClick;
    return b;
  }
  function magnifier(size = 14, className = "") {
    const ns = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", "0 0 16 16");
    svg.setAttribute("width", String(size));
    svg.setAttribute("height", String(size));
    if (className) svg.setAttribute("class", className);
    svg.setAttribute("aria-hidden", "true");
    const circle = document.createElementNS(ns, "circle");
    for (const [k, v] of Object.entries({ cx: "6.8", cy: "6.8", r: "4.4", fill: "none", stroke: "currentColor", "stroke-width": "1.5" })) circle.setAttribute(k, v);
    const handle = document.createElementNS(ns, "line");
    for (const [k, v] of Object.entries({ x1: "10.1", y1: "10.1", x2: "14", y2: "14", stroke: "currentColor", "stroke-width": "1.5", "stroke-linecap": "round" })) handle.setAttribute(k, v);
    svg.append(circle, handle);
    return svg;
  }
  function reticle(size) {
    const ns = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("width", String(size));
    svg.setAttribute("height", String(size));
    svg.setAttribute("class", "reticle");
    const paths = [
      ["circle", { cx: "12", cy: "12", r: "7.1", fill: "none", "stroke-width": "1.5" }],
      ["line", { x1: "12", y1: "2.2", x2: "12", y2: "5.5", "stroke-width": "1.5" }],
      ["line", { x1: "12", y1: "18.5", x2: "12", y2: "21.8", "stroke-width": "1.5" }],
      ["line", { x1: "2.2", y1: "12", x2: "5.5", y2: "12", "stroke-width": "1.5" }],
      ["line", { x1: "18.5", y1: "12", x2: "21.8", y2: "12", "stroke-width": "1.5" }],
      ["circle", { cx: "12", cy: "12", r: "1.25", "stroke": "none" }]
    ];
    for (const [tag, attrs] of paths) {
      const n = document.createElementNS(ns, tag);
      for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
      svg.append(n);
    }
    return svg;
  }
  function tape(text, kind) {
    return el("div", { class: `tape ${kind}` }, text);
  }
  async function downscaleImageFile(file, maxWidth, quality) {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, maxWidth / Math.max(1, bitmap.width));
    const w = Math.max(1, Math.round(bitmap.width * scale));
    const h = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("no 2d context");
    ctx.drawImage(bitmap, 0, 0, w, h);
    try {
      bitmap.close();
    } catch {
    }
    return canvas.toDataURL("image/jpeg", quality);
  }
  function wordCount(text) {
    const t = text.trim();
    if (!t) return 0;
    return t.split(/\s+/).length;
  }
  function appendStreamCaret(container) {
    const caret = document.createElement("span");
    caret.className = "stream-caret";
    caret.textContent = "\u258D";
    const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
    let lastText = null;
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (node.nodeValue && node.nodeValue.trim()) lastText = node;
    }
    if (lastText?.parentNode) lastText.parentNode.insertBefore(caret, lastText.nextSibling);
    else container.append(caret);
  }
  function prettyDetailText(text) {
    const trimmed = String(text ?? "").trim();
    if (!trimmed) return "";
    try {
      const value = JSON.parse(trimmed);
      if (value && typeof value === "object") return JSON.stringify(value, null, 2);
    } catch {
    }
    return text;
  }
  function friendlyKey(k) {
    const words = k.replace(/[_-]+/g, " ").replace(/([a-z])([A-Z])/g, "$1 $2").trim();
    return words.charAt(0).toUpperCase() + words.slice(1);
  }
  function friendlyEvidence(label) {
    const k = label.toLowerCase().replace(/[^a-z]+/g, "_").replace(/^_+|_+$/g, "");
    const map = {
      is_destructive: "Permanent",
      irreversibility: "Risk",
      irreversible: "Risk",
      target_matches_task: "Relevant",
      target_matches_intent: "Relevant",
      pre_filter: "Why",
      prefilter: "Why",
      margin: "Certainty",
      noul: "Risk",
      confidence: "Confidence"
    };
    for (const [key, val] of Object.entries(map)) {
      if (k.includes(key)) return val;
    }
    return friendlyKey(label);
  }
  function friendlyEvidenceValue(label, value) {
    const k = label.toLowerCase();
    if (/risk|irreversib|noul/.test(k)) {
      const n = Number(value);
      if (Number.isFinite(n)) return n >= 0.6 ? "High" : n >= 0.3 ? "Medium" : "Low";
    }
    if (/destructive|undone/.test(k)) return /^(yes|true|1)$/i.test(value) ? "Yes" : "No";
    if (/matches|intent|task/.test(k)) return /^(yes|true|1)$/i.test(value) ? "Yes" : "No";
    return value;
  }
  var panel = new Panel();
  panel.exposeDebug();
  panel.init().catch((err) => {
    console.error("panel init failed", err);
  });
})();
