---
name: page-smoke
description: Verify the current page is reachable and contains expected text, with a deterministic contract.
whenToUse: When the user asks for a quick page smoke check or a repeatable "does this page still say X" test.
version: 1
requires: [page]
risk: read
---

# Page smoke check

Run the attached contract instead of improvising a one-off read.

1. Ask for the expected text if the user did not provide it.
2. Preview the contract with `contract_run {"skill":"page-smoke","dry_run":true,"inputs":{"expected_text":"..."}}`.
3. Run it with `dry_run:false`.
4. Report pass or fail, the URL, and the assertion detail.

The contract is read-only. If the page is a login wall or a blank tab, fix that first;
the contract will fail its URL/text assertions rather than guessing.
