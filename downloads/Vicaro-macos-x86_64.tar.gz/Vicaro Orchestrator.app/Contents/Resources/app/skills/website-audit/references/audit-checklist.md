# Audit checklist

Use this as a compact evidence checklist, not a second procedure.

## Load and errors

- [ ] Page reaches a stable final URL and title.
- [ ] No uncaught console errors on load.
- [ ] No failed document, script, stylesheet, font, or primary fetch.
- [ ] No visible error page, blank state, or endless spinner.

## Navigation and content

- [ ] Primary navigation links resolve.
- [ ] No dead internal links on the sampled pages.
- [ ] One clear H1; heading order is not inverted.
- [ ] Meaningful images have useful alt text.
- [ ] No placeholder copy, lorem ipsum, or stale dates.

## Forms

- [ ] Every field has a visible label.
- [ ] Required fields are marked and validated.
- [ ] Error messages identify the field and the fix.
- [ ] The submit control is reachable and not obscured.
- [ ] No purchase or destructive submission during the audit.

## Performance

- [ ] DOM size is reasonable for the page type.
- [ ] No very large third-party payload on the critical path.
- [ ] No obvious long task or layout instability observed in the counters.
- [ ] Images are not obviously oversized for their rendered box.

## SEO and metadata

- [ ] Title is present and specific.
- [ ] Description is present and useful.
- [ ] Canonical is present and points at the intended URL.
- [ ] No accidental noindex.
- [ ] Open Graph fields are present for shareable pages.

## Trust

- [ ] No mixed content.
- [ ] No broken image or missing brand asset.
- [ ] Contact, pricing, and policy links are present where expected.
- [ ] The page does not ask for sensitive data it does not need.
